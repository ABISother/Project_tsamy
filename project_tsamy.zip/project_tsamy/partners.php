<?php
session_start();
?>
<?php

 if(!isset($_SESSION["giz_supervisor"])){
 echo("<script>location.href='admin-login.php';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
 echo '<label color="red">You are not Authorized</label>';
 }
 else{

    include('connection.php'); 
 $account_key=$_SESSION["giz_supervisor"];
 $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['user_name'];
 $myemail=$fetch_account['email'];
 if($fetch_account['account_type']=='Admin'){
    $itsadmin=1;
 }else{
    $itsadmin=0; 
 }
 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Profile</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">






</head>

































<body class="layout-compact layout-compact">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">

           <!-- Header -->
           <?php
            $page='partner';
            include("admin-header.php");
            ?>
            <!-- // END Header -->



            <div class="pt-32pt">
                <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0">Partners</h2>

                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>

                                <li class="breadcrumb-item active">

                                    Giz Partners

                                </li>

                            </ol>

                        </div>
                    </div>


                   

                </div>
            </div>

            <div class="container page__container page-section">

             


                <div class="page-separator">
                    <div class="page-separator__text">Clients</div>
                </div>

                <div class="card mb-lg-32pt">

                    <div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-date" data-lists-sort-desc="true" data-lists-values='["js-lists-values-name", "js-lists-values-company", "js-lists-values-phone", "js-lists-values-date"]'>




                        <table class="table mb-0 thead-border-top-0 table-nowrap">
                            <thead>
                                <tr>

                                    <th style="width: 18px;" class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#clients" id="customCheckAll_clients">
                                            <label class="custom-control-label" for="customCheckAll_clients"><span class="text-hide">Toggle all</span></label>
                                        </div>
                                    </th>

                                    <th>
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-name">Name</a>
                                    </th>

                                    <th style="width: 150px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-company">Company</a>
                                    </th>


                                    <th style="width: 37px;">Tags</th>


                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-phone">Phone</a>
                                    </th>

                                    <th style="width: 120px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-date">Added</a>
                                    </th>
                                    <th style="width: 24px;"></th>
                                </tr>
                            </thead>
                            <tbody class="list" id="clients">

                                <tr>

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_clients_1">
                                            <label class="custom-control-label" for="customCheck1_clients_1"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">


                                                <span class="avatar-title rounded-circle">BN</span>

                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex flex-column">
                                                    <p class="mb-0"><strong class="js-lists-values-name">Billy Nunez</strong></p>
                                                    <small class="js-lists-values-email text-50">annabell.kris@yahoo.com</small>
                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-warning">FM</span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-company"><strong>Frontend Matter Inc.</strong></small>
                                                    <small class="js-lists-values-location text-50">Leuschkefurt</small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>


                                    <td>


                                        <a href="#" class="chip chip-outline-secondary">User</a>


                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">239-721-3649</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">19 February 2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                                <tr>

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_clients_2">
                                            <label class="custom-control-label" for="customCheck1_clients_2"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">


                                                <span class="avatar-title rounded-circle">TP</span>

                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex flex-column">
                                                    <p class="mb-0"><strong class="js-lists-values-name">Tony Parks</strong></p>
                                                    <small class="js-lists-values-email text-50">vida_glover@gmail.com</small>
                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-accent">HH</span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-company"><strong>Huma Huma Inc.</strong></small>
                                                    <small class="js-lists-values-location text-50">Mayerberg</small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>


                                    <td>


                                        <a href="#" class="chip chip-outline-secondary">Admin</a>


                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">169-769-4821</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">18 February 2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                                <tr class="selected">

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" checked="" id="customCheck1_clients_3">
                                            <label class="custom-control-label" for="customCheck1_clients_3"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">

                                                <img src="assets/images/people/110/guy-1.jpg" alt="Avatar" class="avatar-img rounded-circle">


                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex flex-column">
                                                    <p class="mb-0"><strong class="js-lists-values-name">Gilbert Barrett</strong></p>
                                                    <small class="js-lists-values-email text-50">paolo.zieme@gmail.com</small>
                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                    </td>


                                    <td>


                                        <a href="#" class="chip chip-outline-secondary">Admin</a>


                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">462-060-7408</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">17 February 2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                                <tr class="selected">

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" checked="" id="customCheck1_clients_4">
                                            <label class="custom-control-label" for="customCheck1_clients_4"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">

                                                <img src="assets/images/people/110/guy-2.jpg" alt="Avatar" class="avatar-img rounded-circle">


                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex flex-column">
                                                    <p class="mb-0"><strong class="js-lists-values-name">Ollie Wallace</strong></p>
                                                    <small class="js-lists-values-email text-50">lorna_kirlin@nora.biz</small>
                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                    </td>


                                    <td>


                                        <a href="#" class="chip chip-outline-secondary">Manager</a>


                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">285-626-6050</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">16 February 2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>

                    <div class="card-footer p-8pt">

                        <ul class="pagination justify-content-start pagination-xsm m-0">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true" class="material-icons">chevron_left</span>
                                    <span>Prev</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Page 1">
                                    <span>1</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Page 2">
                                    <span>2</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span>Next</span>
                                    <span aria-hidden="true" class="material-icons">chevron_right</span>
                                </a>
                            </li>
                        </ul>

                    </div>
                    <!-- <div class="card-body bordet-top text-right">
  15 <span class="text-50">of 1,430</span> <a href="#" class="text-50"><i class="material-icons ml-1">arrow_forward</i></a>
</div> -->


                </div>

                <div class="page-separator">
                    <div class="page-separator__text">Employees</div>
                </div>

                <div class="card mb-lg-32pt">

                    <div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-date" data-lists-sort-desc="true" data-lists-values='["js-lists-values-name", "js-lists-values-department", "js-lists-values-status", "js-lists-values-type", "js-lists-values-phone", "js-lists-values-date"]'>




                        <table class="table mb-0 thead-border-top-0 table-nowrap">
                            <thead>
                                <tr>

                                    <th style="width: 18px;" class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#employees" id="customCheckAllemployees">
                                            <label class="custom-control-label" for="customCheckAllemployees"><span class="text-hide">Toggle all</span></label>
                                        </div>
                                    </th>

                                    <th>
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-name">Name</a>
                                    </th>

                                    <th style="width: 150px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-department">Department</a>
                                    </th>



                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-status">Status</a>
                                    </th>


                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-type">Type</a>
                                    </th>


                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-phone">Phone</a>
                                    </th>

                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-date">Hire date</a>
                                    </th>
                                    <th style="width: 24px;"></th>
                                </tr>
                            </thead>
                            <tbody class="list" id="employees">

                                <tr>

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_employees1">
                                            <label class="custom-control-label" for="customCheck1_employees1"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">


                                                <span class="avatar-title rounded-circle">BN</span>

                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex align-items-center">
                                                    <div class="flex d-flex flex-column">
                                                        <p class="mb-0"><strong class="js-lists-values-name">Billy Nunez</strong></p>
                                                        <small class="js-lists-values-email text-50">annabell.kris@yahoo.com</small>
                                                    </div>

                                                    <div class="d-flex align-items-center ml-24pt">
                                                        <i class="material-icons text-20 icon-16pt">link</i>
                                                        <small class="ml-4pt"><strong class="text-50">2</strong></small>
                                                    </div>

                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-light text-black-100">Ds</span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-department"><strong>Design</strong></small>
                                                    <small class="js-lists-values-location text-50">UX Designer</small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>



                                    <td>
                                        <div class="d-flex flex-column">
                                            <small class="js-lists-values-status text-50 mb-4pt">Probation</small>
                                            <span class="indicator-line rounded bg-warning"></span>
                                        </div>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-type text-50">Temporary</small>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">239-721-3649</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">19/02/2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                                <tr>

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_employees2">
                                            <label class="custom-control-label" for="customCheck1_employees2"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">


                                                <span class="avatar-title rounded-circle">TP</span>

                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex align-items-center">
                                                    <div class="flex d-flex flex-column">
                                                        <p class="mb-0"><strong class="js-lists-values-name">Tony Parks</strong></p>
                                                        <small class="js-lists-values-email text-50">vida_glover@gmail.com</small>
                                                    </div>

                                                    <div class="d-flex align-items-center ml-24pt">
                                                        <i class="material-icons text-20 icon-16pt">comment</i>
                                                        <small class="ml-4pt"><strong class="text-50">1</strong></small>
                                                    </div>

                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-light text-black-100">Dv</span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-department"><strong>Development</strong></small>
                                                    <small class="js-lists-values-location text-50">Senior Frontend Developer</small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>



                                    <td>
                                        <div class="d-flex flex-column">
                                            <small class="js-lists-values-status text-50 mb-4pt">Active</small>
                                            <span class="indicator-line rounded bg-primary"></span>
                                        </div>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-type text-50">On Contract</small>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">169-769-4821</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">18/02/2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                                <tr>

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_employees3">
                                            <label class="custom-control-label" for="customCheck1_employees3"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">

                                                <img src="assets/images/people/110/guy-1.jpg" alt="Avatar" class="avatar-img rounded-circle">


                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex align-items-center">
                                                    <div class="flex d-flex flex-column">
                                                        <p class="mb-0"><strong class="js-lists-values-name">Gilbert Barrett</strong></p>
                                                        <small class="js-lists-values-email text-50">paolo.zieme@gmail.com</small>
                                                    </div>

                                                    <div class="d-flex align-items-center ml-24pt">
                                                        <i class="material-icons text-20 icon-16pt">comment</i>
                                                        <small class="ml-4pt"><strong class="text-50">1</strong></small>
                                                    </div>

                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-light text-black-100">CR</span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-department"><strong>Customer Relationship</strong></small>
                                                    <small class="js-lists-values-location text-50">CRM Manager</small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>



                                    <td>
                                        <div class="d-flex flex-column">
                                            <small class="js-lists-values-status text-50 mb-4pt">Active</small>
                                            <span class="indicator-line rounded bg-primary"></span>
                                        </div>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-type text-50">On Contract</small>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">462-060-7408</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">17/02/2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                                <tr>

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_employees4">
                                            <label class="custom-control-label" for="customCheck1_employees4"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">

                                                <img src="assets/images/people/110/guy-2.jpg" alt="Avatar" class="avatar-img rounded-circle">


                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex align-items-center">
                                                    <div class="flex d-flex flex-column">
                                                        <p class="mb-0"><strong class="js-lists-values-name">Ollie Wallace</strong></p>
                                                        <small class="js-lists-values-email text-50">lorna_kirlin@nora.biz</small>
                                                    </div>

                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-light text-black-100">HR</span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-department"><strong>HR</strong></small>
                                                    <small class="js-lists-values-location text-50">HR Manager</small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>



                                    <td>
                                        <div class="d-flex flex-column">
                                            <small class="js-lists-values-status text-50 mb-4pt">Active</small>
                                            <span class="indicator-line rounded bg-primary"></span>
                                        </div>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-type text-50">Full Time</small>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">285-626-6050</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">16/02/2019</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                                <tr class="selected">

                                    <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" checked="" id="customCheck1_employees5">
                                            <label class="custom-control-label" for="customCheck1_employees5"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">

                                                <img src="assets/images/people/110/guy-3.jpg" alt="Avatar" class="avatar-img rounded-circle">


                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex align-items-center">
                                                    <div class="flex d-flex flex-column">
                                                        <p class="mb-0"><strong class="js-lists-values-name">Ricardo Bell</strong></p>
                                                        <small class="js-lists-values-email text-50">smith_winfield@douglas.io</small>
                                                    </div>

                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-light text-black-100">Ds</span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-department"><strong>Design</strong></small>
                                                    <small class="js-lists-values-location text-50">UX Designer</small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>



                                    <td>
                                        <div class="d-flex flex-column">
                                            <small class="js-lists-values-status text-50 mb-4pt">Terminated</small>
                                            <span class="indicator-line rounded bg-danger"></span>
                                        </div>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-type text-50">Temporary</small>
                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50">285-626-6050</small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50">01/12/2018</small>
                                    </td>
                                    <td class="text-right">
                                        <a href="#" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>

                    <div class="card-footer p-8pt">

                        <ul class="pagination justify-content-start pagination-xsm m-0">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true" class="material-icons">chevron_left</span>
                                    <span>Prev</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Page 1">
                                    <span>1</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Page 2">
                                    <span>2</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span>Next</span>
                                    <span aria-hidden="true" class="material-icons">chevron_right</span>
                                </a>
                            </li>
                        </ul>

                    </div>
                    <!-- <div class="card-body bordet-top text-right">
  15 <span class="text-50">of 1,430</span> <a href="#" class="text-50"><i class="material-icons ml-1">arrow_forward</i></a>
</div> -->


                </div>


                <div class="page-separator">
                                <div class="page-separator__text">Rising Stars</div>
                            </div>

                            <div class="row card-group-row">


                                <div class="col-md-6 col-xl-4 card-group-row__col">
                                    <div class="card card-group-row__card">
                                        <div class="card-header d-flex align-items-center">
                                            <a href="fixed-teacher-profile.html" class="card-title flex mr-12pt">Sother ABI.</a>
                                            <a href="fixed-teacher-profile.html" class="btn btn-light btn-sm">Follow</a>
                                        </div>
                                        <div class="card-body flex text-center d-flex flex-column align-items-center justify-content-center">
                                            <a href="fixed-teacher-profile.html" class="avatar avatar-xl overlay overlay--show overlay--primary rounded-circle p-relative o-hidden mb-16pt">
                                                <img src="assets/images/people/110/woman-2.jpg" alt="teacher" class="avatar-img">
                                                <span class="overlay__content"><i class="overlay__action material-icons icon-40pt">face</i></span>
                                            </a>
                                            <div class="flex">
                                                <div class="d-inline-flex align-items-center mb-8pt">
                                                    <div class="rating mr-8pt">

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>


                                                    </div>
                                                    <small class="text-muted">5/5</small>
                                                </div>

                                                <p class="text-70 measure-paragraph">Fueled by my passion for understanding the nuances of cross-cultural advertising, I consider myself a forever student, eager to both build on my academic foundations in psychology and sociology and stay in tune with the latest digital marketing strategies through continued coursework.</p>

                                                <a href="javascript:void()" data-toggle="tooltip" data-title="Browse Topic" data-placement="bottom" class="chip chip-outline-secondary">Web Developer</a>
                                            </div>
                                        </div>
                                        <div class="card-body flex-0">
                                            <div class="d-flex align-items-center">
                                                <a href="fixed-student-course.html" class="avatar avatar-4by3 overlay overlay--primary mr-12pt">
                                                    <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4690.JPG" alt="course" class="avatar-img rounded">
                                                    <span class="overlay__content"></span>
                                                </a>
                                                <div class="flex">
                                                    <a href="fixed-student-course.html" class="card-title">His course</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="col-md-6 col-xl-4 card-group-row__col">
                                    <div class="card card-group-row__card">
                                        <div class="card-header d-flex align-items-center">
                                            <a href="fixed-teacher-profile.html" class="card-title flex mr-12pt">Patrick I.</a>
                                            <a href="fixed-teacher-profile.html" class="btn btn-light btn-sm">Follow</a>
                                        </div>
                                        <div class="card-body flex text-center d-flex flex-column align-items-center justify-content-center">
                                            <a href="fixed-teacher-profile.html" class="avatar avatar-xl overlay js-overlay overlay--primary rounded-circle p-relative o-hidden mb-16pt">
                                                <img src="assets/images/people/110/guy-3.jpg" alt="teacher" class="avatar-img">
                                                <span class="overlay__content"><i class="overlay__action material-icons icon-40pt">face</i></span>
                                            </a>
                                            <div class="flex">
                                                <div class="d-inline-flex align-items-center mb-8pt">
                                                    <div class="rating mr-8pt">

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>


                                                        <span class="rating__item"><span class="material-icons">star_border</span></span>

                                                        <span class="rating__item"><span class="material-icons">star_border</span></span>

                                                    </div>
                                                    <small class="text-muted">3/5</small>
                                                </div>

                                                <p class="text-70 measure-paragraph">Fueled by my passion for understanding the nuances of cross-cultural advertising, I consider myself a forever student, eager to both build on my academic foundations in psychology and sociology and stay in tune with the latest digital marketing strategies through continued coursework.</p>

                                                <a href="javascript:void()" data-toggle="tooltip" data-title="Browse Topic" data-placement="bottom" class="chip chip-outline-secondary">Rwandan Entrepreneur</a>
                                            </div>
                                        </div>
                                        <div class="card-body flex-0">
                                            <div class="d-flex align-items-center">
                                                <a href="fixed-student-course.html" class="avatar avatar-4by3 overlay overlay--primary mr-12pt">
                                                    <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4690.JPG" alt="course" class="avatar-img rounded">
                                                    <span class="overlay__content"></span>
                                                </a>
                                                <div class="flex">
                                                    <a href="fixed-student-course.html" class="card-title">His Course</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div class="col-md-6 col-xl-4 card-group-row__col">
                                    <div class="card card-group-row__card">
                                        <div class="card-header d-flex align-items-center">
                                            <a href="fixed-teacher-profile.html" class="card-title flex mr-12pt">Jane D.</a>
                                            <a href="fixed-teacher-profile.html" class="btn btn-light btn-sm">Follow</a>
                                        </div>
                                        <div class="card-body flex text-center d-flex flex-column align-items-center justify-content-center">
                                            <a href="fixed-teacher-profile.html" class="avatar avatar-xl overlay js-overlay overlay--primary rounded-circle p-relative o-hidden mb-16pt">
                                                <img src="assets/images/people/110/woman-3.jpg" alt="teacher" class="avatar-img">
                                                <span class="overlay__content"><i class="overlay__action material-icons icon-40pt">face</i></span>
                                            </a>
                                            <div class="flex">
                                                <div class="d-inline-flex align-items-center mb-8pt">
                                                    <div class="rating mr-8pt">

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>

                                                        <span class="rating__item"><span class="material-icons">star</span></span>


                                                    </div>
                                                    <small class="text-muted">5/5</small>
                                                </div>

                                                <p class="text-70 measure-paragraph">Fueled by my passion for understanding the nuances of cross-cultural advertising, I consider myself a forever student, eager to both build on my academic foundations in psychology and sociology and stay in tune with the latest digital marketing strategies through continued coursework.</p>

                                                <a href="javascript:void()" data-toggle="tooltip" data-title="Browse Topic" data-placement="bottom" class="chip chip-outline-secondary">An Instructor</a>
                                            </div>
                                        </div>
                                        <div class="card-body flex-0">
                                            <div class="d-flex align-items-center">
                                                <a href="fixed-student-course.html" class="avatar avatar-4by3 overlay overlay--primary mr-12pt">
                                                    <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4690.JPG" alt="course" class="avatar-img rounded">
                                                    <span class="overlay__content"></span>
                                                </a>
                                                <div class="flex">
                                                    <a href="fixed-student-course.html" class="card-title">Her Course</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>

                
                     



            </div>



        <?php

include("admin-footer.php");

?>


    </div>
    <!-- // END drawer-layout -->


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>


    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

</body>

</html>