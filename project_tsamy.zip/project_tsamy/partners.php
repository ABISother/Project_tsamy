<?php
session_start();
?>
<?php

 if(!isset($_SESSION["giz_supervisor"])){
 echo("<script>location.href='admin-login.php';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
 echo '<label color="red">You are not Authorized</label>';
 }
 else{

    include('connection.php'); 
 $account_key=$_SESSION["giz_supervisor"];
 $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['user_name'];
 $myemail=$fetch_account['email'];
 if($fetch_account['account_type']=='Admin'){
    $itsadmin=1;
 }else{
    $itsadmin=0; 
 }
 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Reports </title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">






</head>

































<body class="layout-compact layout-compact">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">

           <!-- Header -->
           <?php
            $page='partner';
            include("admin-header.php");
            ?>
            <!-- // END Header -->



            <div class="pt-32pt">
                <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0">Partners</h2>

                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>

                                <li class="breadcrumb-item active">

                                    Giz Partners

                                </li>

                            </ol>

                        </div>
                    </div>


                   

                </div>
            </div>

            <div class="container page__container page-section">

             


                <div class="page-separator">
                    <div class="page-separator__text">Customers</div>
                </div>

                <div class="card mb-lg-32pt">

                    <div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-date" data-lists-sort-desc="true" data-lists-values='["js-lists-values-name", "js-lists-values-company", "js-lists-values-phone", "js-lists-values-date"]'>




                        <table class="table mb-0 thead-border-top-0 table-nowrap">
                            <thead>
                                <tr>

                                    <!-- <th style="width: 18px;" class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#clients" id="customCheckAll_clients">
                                            <label class="custom-control-label" for="customCheckAll_clients"><span class="text-hide">Toggle all</span></label>
                                        </div> 
                                    </th> -->

                                    <th>
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-name">Name</a>
                                    </th>

                                    <th style="width: 150px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-company">Client to</a>
                                    </th>


                                    <th style="width: 37px;">Email</th>


                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-phone">Phone</a>
                                    </th>

                                    <th style="width: 120px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-date">Address</a>
                                    </th>
                                    <th style="width: 24px;"></th>
                                </tr>
                            </thead>
                            <tbody class="list" id="clients">

                            <?php 
                            //$nowuser=$_GET['user'];
                            $sel_ncustomer=$con->query("SELECT*from customer ORDER BY id DESC")or die($con->error);
                            $count_ncustomer=$sel_ncustomer->num_rows;
                            while($fetch_ncustomer=$sel_ncustomer->fetch_assoc()){
                                $ncustomer=$fetch_ncustomer['id'];

                            $sel_all_project=$con->query("SELECT*from applys where user_id='$ncustomer'  ORDER BY id DESC")or die($con->error);
                            if($count_ava=$sel_all_project->num_rows>0){
                           $fetch_all_project=$sel_all_project->fetch_assoc();
                                $projectn=$fetch_all_project['projectname'];
                            }else{
                                $projectn='0 APPLICATIONs';
                            }
                                
                                
                             
                            ?>
                                <tr>

                                    <!-- <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_clients_1">
                                            <label class="custom-control-label" for="customCheck1_clients_1"><span class="text-hide">Check</span></label>
                                        </div> 
                                    </td> -->

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <!-- <div class="avatar avatar-sm mr-8pt">


                                                <span class="avatar-title rounded-circle">US</span>

                                            </div> -->
                                            <div class="media-body">


                                                <div class="d-flex flex-column">
                                                    <p class="mb-0"><strong class="js-lists-values-name"><?php echo $fetch_ncustomer['username'];  ?></strong></p>
                                                    <small class="js-lists-values-email text-50"><?php echo $fetch_ncustomer['email'];  ?></small>
                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                                <span class="avatar-title rounded bg-warning"><?php echo $count_ava;  ?></span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-company"><strong><?php echo $projectn; ?></strong></small>
                                                    <!-- <small class="js-lists-values-location text-50">Leuschkefurt</small> -->
                                                </div>
                                            </div>
                                        </div>

                                    </td>


                                    <td>


                                        <a href="#" class="chip chip-outline-secondary"><?php echo $fetch_ncustomer['phone'];  ?></a>


                                    </td>


                                    <td>
                                        <small class="js-lists-values-phone text-50"><?php echo $fetch_ncustomer['phone'];  ?></small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50"><?php echo $fetch_ncustomer['address'];  ?></small>
                                    </td>
                                    <td class="text-right">
                                        <!-- <a href="#" class="text-50"><i class="material-icons">more_vert</i></a> -->
                                    </td>
                                </tr>
                                <?php } ?>

                               

                                
                            </tbody>
                        </table>
                    </div>

                    <div class="card-footer p-8pt">


                    </div>
                    <!-- <div class="card-body bordet-top text-right">
  15 <span class="text-50">of 1,430</span> <a href="#" class="text-50"><i class="material-icons ml-1">arrow_forward</i></a>
</div> -->


                </div>

                <div class="page-separator">
                    <div class="page-separator__text">Employees</div>
                </div>

                <div class="card mb-lg-32pt">

                    <div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-date" data-lists-sort-desc="true" data-lists-values='["js-lists-values-name", "js-lists-values-department", "js-lists-values-status", "js-lists-values-type", "js-lists-values-phone", "js-lists-values-date"]'>




                        <table class="table mb-0 thead-border-top-0 table-nowrap">
                            <thead>
                                <tr>

                                    <!-- <th style="width: 18px;" class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-toggle-check-all" data-target="#employees" id="customCheckAllemployees">
                                            <label class="custom-control-label" for="customCheckAllemployees"><span class="text-hide">Toggle all</span></label>
                                        </div>
                                    </th> -->

                                    <th>
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-name">Name</a>
                                    </th>

                                    <th style="width: 150px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-department">Department</a>
                                    </th>



                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-type">Type</a>
                                    </th>


                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-phone">Phone</a>
                                    </th>

                                    <th style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-date">Hire date</a>
                                    </th>
                                    <th style="width: 24px;"></th>
                                </tr>
                            </thead>
                            <tbody class="list" id="employees">

                            <?php  
                          
                          while($fetch_all_users=$sel_all_users->fetch_assoc()){
                              $nowuser=$fetch_all_users['id'];

                              $sel_all_departments=$con->query("SELECT*from departments where manager='$nowuser' ")or die($con->error);
                              $count_all_departments=$sel_all_departments->num_rows;
                              $fetch_all_departments=$sel_all_departments->fetch_assoc();
                     
                         ?>

                                <tr>

                                    <!-- <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" id="customCheck1_employees1">
                                            <label class="custom-control-label" for="customCheck1_employees1"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td> -->

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                                     <div class="avatar avatar-sm mr-8pt">

                                                <img src="assets/images/users/<?php echo $fetch_all_users['profile']; ?>" alt="Avatar" class="avatar-img rounded-circle">


                                            </div>
                                            <div class="media-body">


                                                <div class="d-flex align-items-center">
                                                    <div class="flex d-flex flex-column">
                                                        <p class="mb-0"><strong class="js-lists-values-name"><?php echo $fetch_all_users['fname']." ".$fetch_all_users['lname'] ?></strong></p>
                                                        <small class="js-lists-values-email text-50"><?php echo $fetch_all_users['email']; ?></small>
                                                    </div>

                                                    

                                                </div>


                                            </div>
                                        </div>

                                    </td>

                                    <td>

                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <small class="js-lists-values-department"><strong><?php echo $fetch_all_departments['category_name']; ?></strong></small>
                                                    <small class="js-lists-values-location text-50"><?php echo $fetch_all_departments['partners']; ?></small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>



                                    <td>
                                        <div class="d-flex flex-column">
                                            <small class="js-lists-values-status text-50 mb-4pt"><?php echo $fetch_all_users['account_type']; ?></small>
                                            <span class="indicator-line rounded bg-warning"></span>
                                        </div>
                                    </td>


                                    


                                    <td>
                                        <small class="js-lists-values-phone text-50"><?php echo $fetch_all_users['contacts'] ?></small>
                                    </td>

                                    <td>
                                        <small class="js-lists-values-date text-50"><?php $nowevent_time=$fetch_all_users['Join_date']; 
                                        print date(" d/m/Y",$nowevent_time); ?></small>
                                    </td>
                                    <td class="text-right">
                                        <a href="profile.php" class="text-50"><i class="material-icons">more_vert</i></a>
                                    </td>
                                </tr>
                                <?php } ?>

                                <tr>

                                   
                               
                               
                               

                            </tbody>
                        </table>
                    </div>



                </div>


              

                            <div class="row mb-8pt">
                    <div class="col-lg-8">

                        <div class="page-separator">
                            <div class="page-separator__text">Partners</div>
                        </div>
                        <div class="card">
                             <div data-toggle="lists" data-lists-values='[
                            "js-lists-values-course", 
                            "js-lists-values-document",
                            "js-lists-values-amount",
                            "js-lists-values-date"
                            ]' data-lists-sort-by="js-lists-values-date" data-lists-sort-desc="true" class="table-responsive">
                                <table class="table table-flush table-nowrap">
                                    <thead>
                                        <tr>
                                            <th >
                                                <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-course">Organization<br>Individual</a>
                                            </th>
                                            <th>
                                                <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-document">Names</a>
                                                </th>
                                                <th>
                                                <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-amount">Amount</a>
                                                </th>
                                               
                                                <th>
                                                <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-date">Date</a>
                                                </th>
                                        </tr>
                                    </thead>
                                    <tbody class="list">


                                    <?php 
                                      $sel_all_partners=$con->query("SELECT*from partners ")or die($con->error);
                                      $count_all_partners=$sel_all_partners->num_rows;
                                      while($fetch_all_partners=$sel_all_partners->fetch_assoc()){

                                      

                                      ?>

                                        <tr>
                                            <td>
                                                <div class="d-flex flex-nowrap align-items-center">
                                                <a class="card-title js-lists-values-course" href="#"><?php echo $fetch_all_partners['category'] ?></a>
                                                   
                                                </div>
                                            </td>
                                            <td class="text-right">
                                            <div class="flex">
                                                        <a class="card-title js-lists-values-course" href="compact-instructor-edit-course.html"><?php echo $fetch_all_partners['p_names'] ?></a>
                                                        <!-- <small class="text-muted mr-1">
                                                            Invoice
                                                            <a href="compact-invoice.html" style="color: inherit;" class="js-lists-values-document">#8734</a> -
                                                            &dollar;<span class="js-lists-values-amount">89</span> USD
                                                        </small> -->
                                                    </div>
                                            </td>
                                            <td class="text-right">
                                            <div class="flex">
                                                        <a class="card-title js-lists-values-course" href="compact-instructor-edit-course.html"><?php echo $fetch_all_partners['amount'] ?></a>
                                                       
                                                    </div>
                                            </td>
                                            <td class="text-right">
                                                <small class="text-muted text-uppercase js-lists-values-date"><?php $nowevent_time=$fetch_all_partners['date_of_contribution']; 
                                        print date(" d M Y",$nowevent_time); ?></small>
                                            </td>
                                        </tr>
                                        <?php } ?>



                                      

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-4">

                        <div class="page-separator">
                            <div class="page-separator__text">Add Apartner</div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                            <div class="media">
                                    
                                    <div class="media-body d-flex flex-column">
                                        <div class="d-flex align-items-center">
                                            <a href="#" class="card-title">Partner Category</a>
                                            
                                        </div>
                                        <span class="text-muted"><select class="form-control" name="ptype">
                                            <option>Organization</option>
                                            <option>Individual</option>
                                        </select></span>
                                        <p class="mt-1 mb-0 text-70">Select Category</p>
                                    </div>
                                </div>
                                <div class="media">
                                    
                                    <div class="media-body d-flex flex-column">
                                        <div class="d-flex align-items-center">
                                            <a href="#" class="card-title">Partner Names</a>
                                            <!-- <small class="ml-auto text-muted">27 min ago</small><br> -->
                                        </div>
                                        <span class="text-muted"><input type="text" class="form-control" name="pname"></span>
                                        <p class="mt-1 mb-0 text-70">Whos Is the Partner?</p>
                                    </div>
                                </div>
                                <div class="media">
                                    
                                    <div class="media-body d-flex flex-column">
                                        <div class="d-flex align-items-center">
                                            <a href="#" class="card-title">Amount</a>
                                            <!-- <small class="ml-auto text-muted">27 min ago</small><br> -->
                                        </div>
                                        <span class="text-muted"><input type="number" class="form-control" name="pname"></span>
                                        <p class="mt-1 mb-0 text-70">How Much is the Offer In FRW?</p>
                                    </div>
                                </div>
                                <!-- <div class="media ml-sm-32pt mt-3 border rounded p-3 bg-light d-inline-flex measure-paragraph-max">
                                    <div class="media-left mr-12pt">
                                        <a href="#" class="avatar avatar-sm">
                                            <span class="avatar-title rounded-circle">FM</span>
                                        </a>
                                    </div>
                                    
                                </div> -->
                            </div>
                            <div class="card-footer">
                                <form action="#" id="message-reply">
                                    <div class="input-group input-group-merge">
                                        <input type="text" class="form-control form-control-appended" required="" placeholder="Save Partner">
                                        <div class="input-group-append">
                                            <!-- <div class="input-group-text pr-2">
                                                <button class="btn btn-flush" type="button"><i class="material-icons">tag_faces</i></button>
                                            </div> -->
                                            <div class="input-group-text pl-0">
                                                <div class="custom-file custom-file-naked d-flex" style="width: 24px; overflow: hidden;">
                                                    <input type="file" class="custom-file-input" id="customFile">
                                                    <label class="custom-file-label" style="color: inherit;" for="customFile">
                                                        <i class="material-icons">attach_file</i>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="input-group-text pl-0">
                                                <button class="btn btn-flush" type="button"><i class="material-icons">send</i></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
                
                     



            </div>



        <?php

include("admin-footer.php");

?>


    </div>
    <!-- // END drawer-layout -->


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>


    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

</body>

</html>