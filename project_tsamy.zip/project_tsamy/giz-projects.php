<?php
session_start();
?>
<?php

 if(!isset($_SESSION["giz_supervisor"])){
 echo("<script>location.href='admin-login.php';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
 echo '<label color="red">You are not Authorized</label>';
 }
 else{

    include('connection.php'); 
 $account_key=$_SESSION["giz_supervisor"];
 $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['user_name'];
 $myemail=$fetch_account['email'];
 if($fetch_account['account_type']=='Admin'){
    $itsadmin=1;
 }else{
    $itsadmin=0; 
 }
 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>ADMIN |Projects</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">

 
    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">



    <!-- Quill Theme -->
    <link type="text/css" href="assets/css/quill.css" rel="stylesheet">

    <!-- Select2 -->
    <link type="text/css" href="assets/css/select2.css" rel="stylesheet">

    <link type="text/css" href="assets/vendor/select2/select2.min.css" rel="stylesheet">

    
  <!---==========================Image Crop & Upload============================== -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" />

     <!-- Ajax reasons-->
   <script src="assets/js/jquery.min.js"></script>



</head>



































<body class="layout-compact layout-compact">

     <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div> 

    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">

            <!-- Header -->
            <?php
            $page='projects';
            include("admin-header.php");

            ?>
            <!-- // END Header -->



            <div class="pt-32pt">
                <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center">

                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0">Projects</h2>

                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                                <li class="breadcrumb-item active">

                                   giz Projects

                                </li>

                            </ol>

                        </div>
                    </div>


                </div>
            </div>



<div class="container page__container page-section">




    <div class="row card-group-row">
        <?php 
          if($count_all_project>0){ 
            while($fetch_giz_project=$sel_all_project->fetch_assoc()){ 

                $person=$fetch_giz_project['p_supervisor'];
                $cat_id=$fetch_giz_project['id'];

                $sel_supervisor=$con->query("SELECT*from users where id='$person'")or die($con->error);
                $fetch_supervisor=$sel_supervisor->fetch_assoc();
                ?>
        <div class="card-group-row__col col-md-12">
            <div class="card card-group-row__card card-sm">
                <div class="card-body d-flex align-items-center">
                    <a href="#" class="avatar overlay overlay--primary avatar-4by3 mr-12pt">
                        <img src="assets/images/paths/angular_routing_200x168.png" alt="Angular Routing In-Depth" class="avatar-img rounded">
                        <span class="overlay__content"></span>
                    </a>
                    <div class="flex">
                        <a class="card-title" href="#"><?php echo $fetch_giz_project['p_tittle']; ?></a>
                        <div class="card-subtitle text-50">Supervised by <strong><?php echo $fetch_supervisor['user_name']; ?></strong></div>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="d-flex align-items-center">
                        <div class="flex mr-2">
                            <a href="#" class="btn btn-light btn-sm">
                                <i class="material-icons icon--left">playlist_add_check</i> Review
                                <span class="badge badge-dark badge-notifications ml-2">5</span>
                            </a>
                        </div>

                        <div class="dropdown">
                            <a href="#" data-toggle="dropdown" data-caret="false" class="text-muted"><i class="material-icons">more_horiz</i></a>
                            <!-- <div class="dropdown-menu dropdown-menu-right">
                                <a href="javascript:void(0)" class="dropdown-item">Review</a>
                                <a href="#" class="dropdown-item">Edit</a>
                                <div class="dropdown-divider"></div>
                                <a href="javascript:void(0)" class="dropdown-item text-danger">Delete </a>
                            </div> -->
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <?php } }else{?>

            

                    <div class="col-md-12">
                        <div class="posts-card__content  align-items-center ">
                            
                          
                            <div class="list-group-item">
                                        <a href="#new_Project" class="text-danger"><strong>Currently there is no Project from GIZ staff &amp; ADD Some</strong></a>
                                        
                                    </div>
                          
                        </div>
                    </div>
                    <?php } ?>
        

       

       
        

    </div>
</div>
<!-- aho birangirira!! -->











            <div class="page-section border-bottom-2">
                <div class="container page__container">
                    <div class="row align-items-start">
                        <div class="col-md-8">

                            

                            <div class="page-separator" id="new_Project">
                                <div class="page-separator__text">New Project</div>
                            </div>
                            <form action="" method="post" id="project_form" name="project_form">
                            <div class="card card-body">
                                <div class="form-group">
                                    <label class="form-label">Project Title</label>
                                    <input type="text" class="form-control" name="pname" id="pname" placeholder="New Project Name" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-label" for="p_category">Project category</label>
                                    <select id="p_category"  name="p_category" class="form-control" required="">
                                    <option value="" selected="">
                                            Select a category related to your ideal
                                        </option> 
                                        
                                   
                                     
                                        <?php
                                       if(isset($itsadmin)&&($itsadmin==1)){ 
                                    $sel_all_departments=$con->query("SELECT*from departments  ")or die($con->error);
                                       }else{
                                        $sel_all_departments=$con->query("SELECT*from departments where manager='$account_key' ")or die($con->error);
                                       }
                                    $count_all_departments=$sel_all_departments->num_rows;
                                    while($fetch_all_departments=$sel_all_departments->fetch_assoc()){ 
                                       

                                   ?>
                           
                           <option value="<?php echo $fetch_all_departments['id']; ?>" >
                           <?php echo $fetch_all_departments['category_name']; ?>
                               </option>
                               <?php } ?>
                              
                          
                                    </select>
                                    <div class="invalid-feedback">Please select, This helps to determine who should supervise your case!.</div>
                                            <div class="valid-feedback">Okay, Just make sure the category is related to your Project!</div>
                                    </div>

                                <div class="form-group">
                                    <label class="form-label">Project in Details (Includes Requirements)</label>
                                    <!-- <textarea class="form-control" rows="3" placeholder="Question"></textarea> -->
                                    <div style="height: 150px;" class="mb-0" >
                                      <textarea name="description" class="form-control" type="text" id="description">Hello</textarea> 
                                    </div>
                                    <small class="form-text text-muted">Shortly describe the Project.</small>
                                </div>

                                <div class="form-group">
                                    <label class="form-label" for="dateRangePickerSample01">Pick an Estimated Due Date</label>
                                    <input id="d_date" name="d_date" type="date" class="form-control" placeholder="Date refered to be a Due"  required="" >
                                    </div>

                                <div class="form-group">
                                    <label class="form-label" for="validationSample03">Partner with</label>
                                    <input type="hidden" class="form-control" id="validationSample03" name="companyname" value="giz Rwanda" placeholder="Company" required="" >

                                    <input type="text" class="form-control" id="validationSample03" name="partnername"  placeholder="Company Name" required="" >
                                    <div class="invalid-feedback">Please provide a valid Campany Name,If is unavailable you can LABEL This with your Name.</div>
                                    <div class="valid-feedback">Looks good!</div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="validationSample04">Badget Range</label>
                                        <input type="number" name="budget" class="form-control" id="validationSample04" placeholder="$0 - $12,500" >
                                        <div class="invalid-feedback">You may provide just a maximum amount.</div>
                                        <div class="valid-feedback">Provide if you are aware of how the project stands!</div>
                                    </div>
                                <div>
                                    <a href="#new_Project" class="btn btn-outline-secondary">Go Up</a>
                                </div>
                            </div>

                        </div>
                        <div class="col-md-4">
                            <div class="page-separator">
                                <div class="page-separator__text">Icon</div>
                            </div>
                            <!-- <div class="card">
                                <div class="card-body">
                                    <div class="form-group mb-0">
                                        <label class="form-label">Add Icon</label>
                                        <input type="file"  id="floatingImage" name="file" placeholder="NaImageme" accept="image/*" placeholder="Project image" >
                                    </div>
                                    <div id="uploaded_image"></div>
                                </div>
                            </div> -->

                            <div id="msg" ></div>

                            <div class="card">
                                <div class="card-header text-center">
                                    <button id="projectloader" type="hidden" style="display: none;" class="btn btn-accent is-loading is-loading-sm">Loading..</button>
                                    <button type="submit" id="submit_project_btn" value="subproject" name="submit_project_btn" class="btn btn-accent">Save Project</button>
                                </div>
                                <div class="list-group list-group-flush">
                                    <!-- <div class="list-group-item d-flex">
                                        <button class="btn flex" type="submit" value="draft" name="asdraft" id="asdraft" ><strong>Save Draft</strong><i class="material-icons text-muted">check</i></button>
                                        
                                    </div> -->
                                    <!-- <div class="list-group-item">
                                        <a href="#" class="text-danger"><strong>Delete Project</strong></a>
                                        
                                    </div> -->
                                </div>
                            </div>
                            <script>


                                $(document).ready(function(){
                                
                                    $('#project_form').on('submit', function(event){
                                  event.preventDefault();
                                  if($('#pname').val() != '' && $('#d_date').val() != '')
                                  {
                                   var form_data = $(this).serialize();
                                   $.ajax({
                                    url:"admin-process.php",
                                    method:"POST",
                                    data:form_data,
                                    beforeSend:function(){
                                       $('#projectloader').removeClass("hidden");
                                        $('#submit_project_btn').prop("disabled",true);
                                        $('#projectloader').prop("hidden",false);
                                                              
                                                            },
                                    success:function(data)
                                    {
                                     //$('#project_form')[0].reset();
                                     $('#msg').html(data);
                                     $('#projectloader').prop("hidden",true);
                                     $('#submit_project_btn').prop("disabled",false);
                                    }
                                   })
                                  }
                                  else
                                  {
                                   alert("Both Fields are Required");
                                  }
                                 });

                                              
                                        $image_crop = $('#image_demo').croppie({
                                            enableExif: true,
                                            viewport: {
                                            width:300,
                                            height:260,
                                            type:'rectangle' //circle
                                            },
                                            boundary:{
                                            width:420,
                                            height:400
                                            }
                                        });
                                        
                                        $('#floatingImage').on('change', function(){
                                            var reader = new FileReader();
                                            reader.onload = function (event) {
                                            $image_crop.croppie('bind', {
                                                url: event.target.result
                                            }).then(function(){
                                                console.log('jQuery bind complete');
                                            });
                                            }
                                            reader.readAsDataURL(this.files[0]);
                                            $('#uploadimageModal').modal('show');
                                        });
                                        
                                        $('.crop_image').click(function(event){
                                            $image_crop.croppie('result', {
                                            type: 'canvas',
                                            size: 'viewport'
                                            }).then(function(response){
                                            $.ajax({
                                                url:"upload.php",
                                                type: "POST",
                                                data:{"image": response},
                                                success:function(data)
                                                {
                                                txt = "Preview";
                                                document.getElementById("previewT").innerHTML = txt;
                                                $('#uploadimageModal').modal('hide');
                                                $('#uploaded_image').html(data);

                                                }
                                            });
                                            })
                                        });
                                        
                                        }); 

                            </script>
                        </form>

                                     <!--Crop image modal-->
                            <div id="uploadimageModal" class="modal" role="dialog">
                                <div class="modal-dialog">
                                  <div class="modal-content">
                                        <div class="modal-header">
                                          <button type="button" class="close" data-dismiss="modal">×</button>
                                          <h4 class="modal-title">Upload & Crop Image</h4>
                                        </div>
                                        <div class="modal-body">
                                          <div class="row">
                                      <div class="col-md-8 text-center">
                                        <div id="image_demo" style="width:350px; margin-top:30px"></div>
                                      </div>
                                      
                                    </div>
                                        </div>
                                        <div class="modal-footer">
                                          <button class="btn btn-success crop_image">Crop & Upload Image</button>
                                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                    </div>
                              </div>
                            <!---End Crop image modal----->

                        </div>
                    </div>
                </div>
            </div>



            <?php

include("admin-footer.php");

?>

    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>



    <!-- Quill -->
    <script src="assets/vendor/quill.min.js"></script>
    <script src="assets/js/quill.js"></script>
    <!-- Select2 -->
    <script src="assets/vendor/select2/select2.min.js"></script>
    <script src="assets/js/select2.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- Sidebar Mini JS -->
    <script src="assets/js/sidebar-mini.js"></script>
    <script>
        (function() {
            'use strict';

            // ENABLE sidebar menu tabs
            $('.js-sidebar-mini-tabs [data-toggle="tab"]').on('click', function(e) {
                e.preventDefault()
                $(this).tab('show')
            })

            $('.js-sidebar-mini-tabs').on('show.bs.tab', function(e) {
                $('.js-sidebar-mini-tabs > .active').removeClass('active')
                $(e.target).parent().addClass('active')
            })
        })()
    </script>

</body>


</html>