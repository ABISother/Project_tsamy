<?php
session_start();
?>
<?php

 if(!isset($_SESSION["giz_supervisor"])){
 echo("<script>location.href='admin-login.php';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
 echo '<label color="red">You are not Authorized</label>';
 }
 else{

    include('connection.php'); 
 $account_key=$_SESSION["giz_supervisor"];
 $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['user_name'];
 $myemail=$fetch_account['email'];
 if($fetch_account['account_type']=='Admin'){
    $itsadmin=1;
 }else{
    $itsadmin=0; 
 }
 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin Dashboard</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">






</head>

































<body class="layout-compact layout-compact">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">

            <!-- Header -->
            <?php
            $page='dashboard';
            include("admin-header.php");

            ?>
            <!-- // END Header -->



            <div class="pt-32pt">
                <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0"><?php echo $fetch_account['account_type']; ?> Dashboard</h2>

                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                                <li class="breadcrumb-item">

                                    <a href="admin-dashboard.php"><?php echo $fetch_account['account_type']; ?></a>

                                </li>

                                <li class="breadcrumb-item active">

                                    Dashboard

                                </li>

                            </ol>

                        </div>
                    </div>



                </div>
            </div>






            <div class="container page__container page__container page-section">
                <div class="page-separator">
                    <div class="page-separator__text">Overview</div>
                </div>

                <div class="row card-group-row mb-lg-8pt">
                    <div class="col-lg-7 card-group-row__col">

                        <div class="card card-group-row__card d-flex flex-column">
                            <div class="row no-gutters flex">
                                <div class="col-6">
                                    <div class="card-body">
                                        <h6 class="text-50">Users</h6>

                                        <div class="h2 mb-0"><?php echo $count_all_users; ?></div>
                                        <div class="d-flex flex-column">
                                            <strong>Giz Departments Admin</strong>
                                            <small class="text-50">Including My self</small>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="h2 mb-0"><?php echo $count_all_project; ?></div>
                                        <div class="d-flex flex-column">
                                            <strong>Projects</strong>
                                            <small class="text-50">+<?php echo $count_all_applicants; ?> Submited (From Customers)</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6 border-left">
                                    <div class="card-body">
                                        <h6 class="text-50">Departments</h6>

                                        <div class="h2 mb-0"><?php echo $count_all_depertments; ?></div>
                                        <div class="d-flex flex-column">
                                            <strong><?php echo $count_my_project; ?> Which I manage!</strong>
                                            <small class="text-50">1.3k today</small>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="h2 mb-0"><?php echo $count_all_clients; ?></div>
                                        <strong>Clients</strong>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-5 card-group-row__col">

                        <div class="card card-group-row__card">
                            <div class="card-body">
                                <h6>My Profile</h6>

                                <div class="d-flex align-items-center">
                                    <div class="mr-12pt">
                                        <div class="avatar avatar-xl avatar-4by3">
                                            <img src="assets/images/users/<?php echo $fetch_account['profile']; ?> " alt="Avatar" class="avatar-img rounded">
                                        </div>
                                    </div>
                                    <div class="flex">
                                        <a href="profile.php" class="card-title"><?php echo $names; ?></a>
                                        <small class="text-50"><?php echo $fetch_account['account_type']; ?></small>
                                        <small class="text-50"><?php echo $fetch_account['account_type']; ?></small>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">



 <?php if(isset($itsadmin)&&($itsadmin==1)){ ?>
                                <div class="d-flex align-items-center mb-8pt">
                                    <div class="mr-8pt">
                                    <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">tune</i>
                                    </div>
                                    <div class="flex d-flex flex-column">
                                        <a href="profile.php?New_user" class="card-title">ADD a New User</a>
                                        <small class="text-50">With a new Department</small>
                                    </div>
                                </div>
                                <?php } ?>

                                <div class="d-flex align-items-center">
                                    <div class="mr-8pt">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">edit</i>
                                        
                                    </div>
                                    <div class="flex d-flex flex-column">
                                        <a href="profile.php?update" class="card-title"> My profile</a>
                                        <small class="text-50">View And Edit My profile</small>
                                    </div>
                                </div>


                            </div>
                        </div>

                    </div>
                </div>

                <div class="page-separator">
                    <div class="page-separator__text">Department(s)</div>
                </div>



                <div class="posts-cards mb-24pt">
                <?php if(isset($itsadmin)&&($itsadmin==1)){ 
                      $sel_categories=$con->query("SELECT*from departments  ")or die($con->error);
                }else{
                    $sel_categories=$con->query("SELECT*from departments where manager='$account_key' ")or die($con->error);
                }
                            if($count_categories=$sel_categories->num_rows>0){ 
                                while($fetch_categories=$sel_categories->fetch_assoc()){ 
                                    
                                
                                        $person=$fetch_categories['manager'];
                                        $cat_id=$fetch_categories['id'];
            
                                        $sel_applicantnow=$con->query("SELECT*from users where id='$person'")or die($con->error);
                                        $fetch_applicantnow=$sel_applicantnow->fetch_assoc();
            
                                        $sel_programnow=$con->query("SELECT*from projects where category='$cat_id'")or die($con->error);
                                        $fetch_programnow=$sel_programnow->fetch_assoc();

                                        $sel_applynow=$con->query("SELECT*from applys where supervisor_id=' $person'")or die($con->error);
                                        $count_applynow=$sel_applynow->num_rows;
            
            ?>
                    <div class="card posts-card">
                        <div class="posts-card__content d-flex align-items-center flex-wrap">
                            <div class="avatar avatar-lg mr-3">
                                <a href="#"><img src="assets/images/users/<?php echo $fetch_applicantnow['profile']; ?>" alt="avatar" class="avatar-img rounded"></a>
                            </div>
                            <div class="posts-card__title flex d-flex flex-column">
                                <a href="#" class="card-title mr-3"><?php echo $fetch_categories['category_name']; ?></a>
                                <small class="text-50">By <?php echo $fetch_applicantnow['user_name'];  ?></small>
                                <?php if($fetch_applicantnow['id']==$account_key){   ?><span><?php echo "[Me]"; ?></span><?php } ?>
                            </div>
                            <div class="d-flex align-items-center flex-column flex-sm-row posts-card__meta">
                                <div class="mr-3 text-50 text-uppercase posts-card__tag d-flex align-items-center">
                                    <i class="material-icons text-muted-light mr-1">folder_open</i> <?php echo $fetch_categories['partners']; ?>
                                </div>
                                <div class="mr-3 text-50 posts-card__date">
                                    <small><?php $jointime=$fetch_categories['initial_date'];
                                                print date("(D) d M, Y H:m a",$jointime); ?></small>
                                </div>
                                <div class="media mr-2 ml-sm-auto align-items-center">
                                    <div class="media-left mr-2 avatar-group">

                                        <div class="avatar avatar-xs" data-toggle="tooltip" data-placement="top" title="Janell D.">
                                            <img src="assets/images/256_rsz_1andy-lee-642320-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                                        </div>

                                        <div class="avatar avatar-xs" data-toggle="tooltip" data-placement="top" title="Janell D.">
                                            <img src="assets/images/256_michael-dam-258165-unsplash.jpg" alt="Avatar" class="avatar-img rounded-circle">
                                        </div>

                                       

                                    </div>
                                    <div class="media-body">

                                        <a href="#">+<?php echo $count_applynow; ?> Applicants in this Department</a>

                                    </div>
                                </div>
                            </div>
                            <div class="dropdown ml-auto">
                                <a href="#" data-toggle="dropdown" data-caret="false" class="text-muted"><i class="material-icons">more_vert</i></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="apps.php" class="dropdown-item">Browser applications</a>
                                    <a href="javascript:void(0)" class="dropdown-item">View Account</a>
                                    <div class="dropdown-divider"></div>
                                    <a href="javascript:void(0)" class="dropdown-item">Some Other Action</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } }else{?>

                   

                    <div class="card posts-card">
                        <div class="posts-card__content d-flex align-items-center flex-wrap">
                            
                            <div class="posts-card__title flex d-flex flex-column">
                                <a href="#" class="card-title">Currently Department Table is Empty &amp; Styles</a>
                                
                            </div>
                            
                          
                        </div>
                    </div>
                    <?php } ?>

                </div>

                

            </div>



            <?php

include("admin-footer.php");

?>

    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>





    <!-- Sidebar Mini JS -->
    <script src="assets/js/sidebar-mini.js"></script>
    <script>
        (function() {
            'use strict';

            // ENABLE sidebar menu tabs
            $('.js-sidebar-mini-tabs [data-toggle="tab"]').on('click', function(e) {
                e.preventDefault()
                $(this).tab('show')
            })

            $('.js-sidebar-mini-tabs').on('show.bs.tab', function(e) {
                $('.js-sidebar-mini-tabs > .active').removeClass('active')
                $(e.target).parent().addClass('active')
            })
        })()
    </script>

</body>
</html>