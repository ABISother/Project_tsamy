<?php
session_start();
?>
<?php


 if(!isset($_SESSION["giz_customer"])){
    echo("<script>location.href='login.php?alert=login first!';</script>");
echo '<label color="red">You are not Authorized</label>';
 }
 else{
   include('connection.php'); 
 $account_key=$_SESSION["giz_customer"];
 $sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['username'];
 $myemail=$fetch_account['email'];

 $sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();

 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dashboard | <?php echo  $names  ?></title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">


</head>



<body class="layout-sticky-subnav layout-default ">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <div id="header" class="mdk-header js-mdk-header mb-0" data-fixed data-effects="">
            <div class="mdk-header__content">



            <?php
            include("header.php");
            ?>



            </div>
        </div>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content page-content ">



            <div class="pt-32pt">
                <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0">Dashboard</h2>

                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                                <li class="breadcrumb-item active">

                                    Dashboard

                                </li>

                            </ol>

                        </div>
                    </div>


                    <div class="row" role="tablist">
                        <!-- <div class="col-auto">
                            <a href="fixed-student-my-courses.html" class="btn btn-outline-secondary">My Project</a>
                        </div> -->
                    </div>

                </div>
            </div>
















            <div class="container page__container">
                <div class="page-section">

                    <div class="page-separator">
                        <div class="page-separator__text">Overview</div>
                    </div>

                    <div class="row mb-lg-8pt">
                        <div class="col-lg-6">
                            <?php $sel_my_project=$con->query("SELECT*from projects WHERE p_owner='$account_key' and by_customer='1' ")or die($con->error);
                            $count_my_project=$sel_my_project->num_rows;  
                            if(isset($account_key)){
                                $sel_availables=$con->query("SELECT*from applys where user_id='$account_key' ")or die($con->error);
                                if($count_availables=$sel_availables->num_rows>0){
                                    
                                    $applyied_this=1;
                
                                }else{
                                    $applyied_this=0;
                                }
                            }else{
                                $applyied_this=0;
                            }?>
                            <div class="card">
                                <div class="card-header d-flex align-items-center">
                                    <div class="h2 mb-0 mr-3"><?php echo $count_my_project; ?></div>
                                    <div class="flex">
                                        <p class="card-title">Submitted Project</p>
                                        <p class="card-subtitle text-50">My Projects</p>
                                    </div>
                                    
                                </div>
                                <div class="card-body p-24pt">
                                    <div class="chart" style="height: 344px;">
                                    <?php 
                           
                            if($count_my_project>0){
                            while($fetch_project=$sel_my_project->fetch_assoc()){

                            ?>
                            <div class="card js-overlay card-sm overlay--primary-dodger-blue stack stack--1 mb-16pt" data-toggle="popover" data-trigger="click">

                                <div class="card-body d-flex flex-column">
                                    <div class="d-flex align-items-center">
                                        <div class="flex">
                                            <div class="d-flex align-items-center">
                                                <div class="rounded mr-12pt z-0 o-hidden">
                                                    <div class="overlay">
                                                        <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4685.JPG" width="40" height="40" alt="GIZ" class="rounded">
                                                        <span class="overlay__content overlay__content-transparent">
                                                            <span class="overlay__action d-flex flex-column text-center lh-1">
                                                                <small class="h6 small text-white mb-0" style="font-weight: 500;"><?php echo $fetch_project['progress'];  ?>%</small>
                                                            </span>
                                                        </span> 
                                                    </div>
                                                </div>
                                                <div class="flex">
                                                    <div class="card-title"><?php echo $fetch_project['p_tittle'];  ?></div>
                                                    <p class="flex text-black-50 lh-1 mb-0"><small><?php $nowtime=$fetch_project['created_on'];
                                                     print date("M d, Y",$nowtime); ?></small></p>
                                                </div>
                                            </div>
                                        </div>

                                        <a href="project_view.php?view=<?php echo $fetch_project['id'];  ?>" class="ml-4pt btn btn-sm btn-link text-secondary border-1 border-secondary">View</a>

                                    </div>


                                </div>
                            </div>

                            <div class="popoverContainer d-none">
                                <div class="media">
                                    <div class="media-left mr-12pt">
                                        <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4685.JPG" width="40" height="40" alt="GIZ" class="rounded">
                                    </div>
                                    <div class="media-body">
                                        <div class="card-title"><?php echo $fetch_project['p_tittle'];  ?></div>
                                        <p class="text-black-50 d-flex lh-1 mb-0 small"><?php print date("D, M d, Y",$nowtime); ?></p>
                                    </div>
                                </div>
                                <?php 
                                $status=$fetch_project['status'];
                                if($status=='Submited'){
                                    $color='primary';
                                }elseif($status=='Valid'){
                                    $color='info';
                                }elseif($status=='Pending'){
                                    $color='warning';
                                }elseif($status=='Rejected'){
                                    $color='accent';
                                }elseif($status=='Pending'){
                                    $color='warning';
                                }else{
                                    $color='success';
                                }
                                 ?>
                                <p class="mt-16pt text-black-70">Submition : <span class="badge badge-pill badge-<?php echo $color; ?>"><?php echo $status; ?></span></p>
                               
                                
                            
                       

                                <div class="my-32pt">
                                   
                                    <div class="d-flex align-items-center justify-content-center">
                                        <a href="project_view.php?view=<?php echo $fetch_project['id'];  ?>" class="btn btn-primary mr-8pt">View</a>
                                        <a href="messages.php?super=<?php echo $fetch_project['p_supervisor'];  ?>" class="btn btn-outline-secondary ml-0">Chat with Supervisor</a>
                                    </div>
                                </div>

                              
                            </div>

                            <?php } }elseif($applyied_this==1){?>
                                <div class="page-separator">
                        <div class="page-separator__text">Project I Applied On</div>
                    </div>
                            
                            <?php
                            }else{ ?>

                            

                            <div class="card js-overlay card-sm overlay--primary-dodger-blue stack stack--1 mb-16pt" data-toggle="popover" data-trigger="click">

                                <div class="card-body d-flex flex-column">
                                    <div class="d-flex align-items-center">
                                        <div class="flex">
                                            <div class="d-flex align-items-center">
                                                <div class="rounded mr-12pt z-0 o-hidden">
                                                    <div class="overlay">
                                                        <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4685.JPG" width="40" height="40" alt="GIZ" class="rounded">
                                                        <span class="overlay__content overlay__content-transparent">
                                                            <span class="overlay__action d-flex flex-column text-center lh-1">
                                                                <small class="h6 small text-white mb-0" style="font-weight: 500;">0%</small>
                                                            </span>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="flex">
                                                    <div class="card-title">Your Projects will appear here!</div>
                                                   
                                                </div>
                                            </div>
                                        </div>

                                        <a href="apply.php" class="ml-4pt btn btn-sm btn-link text-secondary">Projects</a>

                                    </div>


                                </div>
                            </div>

                          <?php  } ?> 
                          
                          <div class="page-separator">
                        <div class="page-separator__text">GIZ Projects I Applied On</div>
                    </div>

                          <?php
                             
                            //Projects that I Applyied on
                            if($applyied_this==1){
                                $sel_availables=$con->query("SELECT*from applys where user_id='$account_key' ")or die($con->error);
                                $count_availables=$sel_availables->num_rows;
                                while($fetch_nowstatus=$sel_availables->fetch_assoc()){
    
                                ?>
                                <div class="card js-overlay card-sm overlay--primary-dodger-blue stack stack--1 mb-16pt" data-toggle="popover" data-trigger="click">
    
                                    <div class="card-body d-flex flex-column">
                                        <div class="d-flex align-items-center">
                                            <div class="flex">
                                                <div class="d-flex align-items-center">
                                                    <div class="rounded mr-12pt z-0 o-hidden">
                                                        <div class="overlay">
                                                            <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4685.JPG" width="40" height="40" alt="Angular" class="rounded">
                                                            <span class="overlay__content overlay__content-transparent">
                                                                <span class="overlay__action d-flex flex-column text-center lh-1">
                                                                    <small class="h6 small text-white mb-0" style="font-weight: 500;"><?php echo $fetch_nowstatus['progress'];  ?>%</small>
                                                                </span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="flex">
                                                        <div class="card-title"><?php echo $fetch_nowstatus['projectname'];  ?></div>
                                                        <p class="flex text-black-50 lh-1 mb-0"><small><?php $nowtime=$fetch_nowstatus['applied_on'];
                                                         print date("M d, Y",$nowtime); ?></small></p>
                                                    </div>
                                                </div>
                                            </div>
    
                                            <a href="project_view.php?view=<?php echo $fetch_nowstatus['id'];  ?>" class="ml-4pt btn btn-sm btn-link text-secondary border-1 border-secondary">View</a>
    
                                        </div>
    
    
                                    </div>
                                </div>
    
                                <div class="popoverContainer d-none">
                                    <div class="media">
                                        <div class="media-left mr-12pt">
                                            <img src="assets/images/new_imgs/2020_05_26_13_49_IMG_4685.JPG" width="40" height="40" alt="GIZ" class="rounded">
                                        </div>
                                        <div class="media-body">
                                            <div class="card-title"><?php echo $fetch_nowstatus['projectname'];  ?></div>
                                            <p class="text-black-50 d-flex lh-1 mb-0 small"><?php print date("D, M d, Y",$nowtime); ?></p>
                                        </div>
                                    </div>
                                    <?php 
                                $status=$fetch_nowstatus['status'];
                                if($status=='Submited'){
                                    $color='primary';
                                }elseif($status=='Valid'){
                                    $color='info';
                                }elseif($status=='Pending'){
                                    $color='warning';
                                }elseif($status=='Rejected'){
                                    $color='accent';
                                }elseif($status=='Pending'){
                                    $color='warning';
                                }else{
                                    $color='success';
                                }
                                 ?>
                                <p class="mt-16pt text-black-70">Application : <span class="badge badge-pill badge-<?php echo $color; ?>"><?php echo $status; ?></span></p>
                               
                                
    
                                    <div class="my-32pt">
                                    
                                        <div class="d-flex align-items-center justify-content-center">
                                            <a href="project_view.php?view=<?php echo $fetch_nowstatus['project_id'];  ?>" class="btn btn-primary mr-8pt">View</a>
                                            <a href="messages.php?super=<?php echo $fetch_nowstatus['supervisor_id'];  ?>" class="btn btn-outline-secondary ml-0">Chat with Supervisor</a>
                                        </div>
                                    </div>
    
                                   
                                </div>
    
                                <?php } }
                                ?>
                            </div> 
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-6">

                        <div class="card card-group-row__card">
                            <div class="card-body">
                                <h6>My Profile</h6>

                                <div class="d-flex align-items-center">
                                    <div class="mr-12pt">
                                        <div class="avatar avatar-xl avatar-4by3">
                                            <img src="assets/images/users/avatar2.png" alt="<?php echo $names; ?>'s Image" class="avatar-img rounded">
                                        </div>
                                    </div>
                                    <div class="flex">
                                        <a href="#" class="card-title"><?php echo $names; ?></a>
                                        <small class="text-50">Customer</small>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">




                                <div class="d-flex align-items-center mb-8pt">
                                    <div class="mr-8pt">
                                        <div class="avatar avatar-sm avatar-4by3">
                                            <img src="assets/images/users/avatar2.png" alt="Avatar" class="avatar-img rounded">
                                        </div>
                                    </div>
                                    <div class="flex d-flex flex-column">
                                        <a href="user_profile.php" class="card-title">My Account</a>
                                        <small class="text-50">Review And Update</small>
                                    </div>
                                </div>

                               


                            </div>
                        </div>





                            <div class="page-separator">
                                <div class="page-separator__text">Available Projects You can Join</div>
                            </div>

                            <div id="carouselExampleFade" class="carousel carousel-card slide mb-24pt">
                                <div class="carousel-inner">

                                    
                                    <?php 
                                    $sel_their_project=$con->query("SELECT*from projects where by_supervisor='1' ")or die($con->error);
                                    $countp=0;
                                    if($count_their_project=$sel_their_project->num_rows>0){
                                    while($fetch_their_project=$sel_their_project->fetch_assoc()){
                                        $countp=$countp+1;

                                    ?>

                                    <div class="carousel-item <?php if($countp==1){echo 'active'; } ?>">

                                        <a class="card border-0 mb-0" href="#">
                                            <img src="assets/images/achievements/angular.png" alt="Introduction to E-commerce" class="card-img" style="max-height: 100%; width: initial;">
                                            <div class="fullbleed bg-primary" style="opacity: .5;"></div>
                                            <span class="card-body d-flex flex-column align-items-center justify-content-center fullbleed">
                                                <span class="row flex-nowrap">
                                                    <span class="col-auto text-center d-flex flex-column justify-content-center align-items-center">
                                                        <span class="h5 text-white text-uppercase font-weight-normal m-0 d-block"><?php echo $fetch_their_project['business_modal'];  ?></span>
                                                        <span class="text-white-60 d-block mb-24pt"><?php $nowtime=$fetch_their_project['created_on'];
                                                     print date("M d, Y",$nowtime); ?></span>
                                                    </span>
                                                    <span class="col d-flex flex-column">
                                                        <span class="text-right flex mb-16pt">
                                                            <img src="assets/images/logo/logo.png" width="64" alt="Angular fundamentals" class="rounded">
                                                        </span>
                                                    </span>
                                                </span>
                                                <span class="row flex-nowrap">
                                                    <span class="col-auto text-center d-flex flex-column justify-content-center align-items-center">
                                                        <img src="assets/images/illustration/achievement/128/white.png" width="64" alt="achievement">
                                                    </span>
                                                    <span class="col d-flex flex-column">
                                                        <span>
                                                            <span class="card-title text-white mb-4pt d-block"><?php echo $fetch_their_project['p_tittle'];  ?></span>
                                                            <span class="text-white-60"><?php echo $fetch_their_project['description'];  ?></span>
                                                        </span>
                                                    </span>
                                                </span>
                                            </span>
                                        </a>

                                    </div>
                                    <?php } } ?>

                                </div>
                                <!-- <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
    <span class="carousel-control-icon material-icons" aria-hidden="true">keyboard_arrow_left</span>
    <span class="sr-only">Previous</span>
  </a> -->
                                <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
                                    <span class="carousel-control-icon material-icons" aria-hidden="true">keyboard_arrow_right</span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>


                        </div>
                    </div>

                    <div class="row mb-lg-16pt">
                       
                        <div class="col-lg-6">



                        </div>
                    </div>





                </div>
            </div>




        </div>
        <!-- // END Header Layout Content -->


        <?php
        include("footer.php");
        ?>


    </div>
    <!-- // END Header Layout -->



    <!-- drawer -->
   


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>


    <!-- Global Settings -->
    <script src="assets/js/settings.js"></script>

    <!-- Flatpickr -->
    <script src="assets/vendor/flatpickr/flatpickr.min.js"></script>
    <script src="assets/js/flatpickr.js"></script>

    <!-- Moment.js -->
    <script src="assets/vendor/moment.min.js"></script>
    <script src="assets/vendor/moment-range.min.js"></script>

    <!-- Chart.js -->
    <script src="assets/vendor/Chart.min.js"></script>
    <script src="assets/js/chartjs.js"></script>

    <!-- Chart.js Samples -->
    <script src="assets/js/page.student-dashboard.js"></script>

    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

</body>

</html>