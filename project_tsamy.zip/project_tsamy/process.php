<?php
session_start();
if(!isset($_SESSION["giz_customer"])){
     echo("<script>location.href='start.php?alert=you must Loggin First to perform this task!;</script>");
   // // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
   // //  echo("<script>location.href='lock.php';</script>");
   // echo '<label color="red">You are not Authorized</label>';
    }else{
    include('connection.php'); 
$account_key=$_SESSION["giz_customer"];
$sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['username'];
$customer_names=$fetch_account['username'];
$customeremail=$fetch_account['email'];

    }
   ?>
<?php
//process.php
// if(!isset($_SESSION["DA_user"])){
// echo("<script>location.href='login.html';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
// echo '<label color="red">You are not Authorized</label>';
// }
// else{

//     include('connection.php'); 
// $account_key=$_SESSION["DA_user"];
// $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
// $fetch_account=$sel_account->fetch_assoc();
// $names=$fetch_account['username'];
// $myemail=$fetch_account['email'];



// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

// }

require_once('connection.php');

$todayyear=date("Y");

if(isset($_POST['uname']))
{
  $fname=$_POST['name1'];
  $lname=$_POST['name2'];
  // $location=$_POST['location'];
  // $bday=$_POST['bday'];
  $phone=$_POST['phone'];
  $usermail=$_POST['email'];
  $userid=$_POST['uname'];
  $address=$_POST['address'];
     $pass=$_POST['pass'];
     $security=md5($pass);
   

    // $Gbday=$bday."-".$bMonth."-".$byear;
    $now=time();
    // $userday=strtotime($Gbday);

    $sel_availables=$con->query("SELECT*from customer where phone='$phone' ")or die($con->error);
    if($count_availables=$sel_availables->num_rows>0){
      
      echo '<div class="alert alert-soft-danger">
      <div class="d-flex flex-wrap">
          <div class="mr-8pt">
              <i class="material-icons">close</i>
          </div>
          <div class="flex" style="min-width: 180px">
              <small class="text-black-100">
              <label style="color:red;">Contact: '.$phone.' Are already used in with different user<br />Please Provide Differnt phone </label>
              </small>
          </div>
      </div>
  </div>';
     $alert="Invalid ID: '.$userid.'Are already used in with different user<br />Please Provide Differnt phone";
    }else{
      $sel_availables=$con->query("SELECT*from customer where username='$userid' ")or die($con->error);
      if($count_availables=$sel_availables->num_rows>0){
        echo '<div class="alert alert-soft-danger">
                <div class="d-flex flex-wrap">
                    <div class="mr-8pt">
                        <i class="material-icons">close</i>
                    </div>
                    <div class="flex" style="min-width: 180px">
                        <small class="text-black-100">
                        <label style="color:red;">Invalid ID<br />User ID <b>'.$userid.'</b> is already used in this System <br />Please Providechoose Differnt user name</label>
                        </small>
                    </div>
                </div>
            </div>';
        $alert="User: '.$userid.'Are already used in with different user<br />Please Providechoose Differnt user name";
      }
    }

    

    if(!isset($alert)){
      $savequery=$con->query("INSERT INTO customer(fname,lname,email,username,phone,address,password,joined) VALUES ('$fname',' $lname','$usermail','$userid','$phone','$address','$security','$now')")or die($con->error);
      if ($savequery) {
          $approvo="Your '.$userid.' user account is activated!<br> ";
          // $_SESSION["new_member"] = $sku;
          echo '<label style="color:green;">Success<br />Your '.$userid.' user account is activated</label>';
          $view_p=$con->query("SELECT*from customer where  password='$security' and  username='$userid' ")or die("Connection failed: ".$con->connect_error);
          $view=$view_p->fetch_assoc();
          //$id=$view['store_No'];
          $last_seen=time();
          $_SESSION["giz_customer"] = $view['id'];
          //$_SESSION["access"] = $view['account_type'];
          

    //$content=$_POST['content'];
    $to =$usermail;
    $subject = 'Successfuly Registered in giz Rwanda System';
    $message= '<p style="color:#4c5a7d"> Hello '.$fname.' , </p>';
    $message .= '<p>This is to inform that  </p>';
    $message .= '<p>You are now one of Customers that are Registered in giz System: </p>';
    $message .= '<p> Names:'.$fname." ".$lname.'</p>';
    $message .= '<p> User ID/User name: '.$userid.'</p>';
    
    if(isset($alert)){
      $message .= '<p> Belows are Some Errors Occured:</p>';
    $message .= '<p> Errors:'.$alert.'</p>';
    }else{
      $message .= '<p> Thank you!</p>';
    }
    $message .= '<p> ------------------------------------------------------------------------------</p>';
    $message .= '<p>  If this was you, you don’t need to do anything. If not, we’ll help you secure your account. call Us now
     <a href="tel:+250786193917"> (+250) 786 193 917 </a> or just Reply to <b>fiacrerukundo8@gmail.com</b>!</p>';
    
    $headers = "From: giz Rwanda \r\n";
    $headers .= "Reply-To: fiacrerukundo8@gmail.com\r\n";
    
    $headers .= "Content-type: text/html\r\n";
    
    $send=mail($to, $subject, $message, $headers);
    
    if($send){
      $approvo .="New Member is added in System Please complete all related info!<br> ";
    }else{
      $info="Email sending failed!";
    }
           if(isset($_SESSION["giz_customer"])){
            echo("<script>location.href='apply.php';</script>");
           }
          // sleep(7);
          //echo("<script>location.href='citizen.php?newuser=$userid';</script>");
             } 
    }

   }else if(isset($_POST['P_tittle']))
   {
       if(!isset($_SESSION["giz_customer"])){
           echo '<div class="alert alert-soft-danger">
           <div class="d-flex flex-wrap">
               <div class="mr-8pt">
                   <i class="material-icons">user</i>
               </div>
               <div class="flex" style="min-width: 180px">
                   <small class="text-black-100">
                   <label style="color:red;"> You must first <a href="login.php">Login</a> or <a href="start.php">register</a> to the system to perfom this action</label>
                   </small>
               </div>
           </div>
       </div>';
          // echo("<script>location.href='start.php';</script>");
         
           }
           else{
            $account_key=$_SESSION["giz_customer"];
            $P_tittle=$_POST['P_tittle'];
            $P_tittle=str_replace("'", "\'", $P_tittle);
            $p_category=$_POST['p_category'];
            $p_category=str_replace("'", "\'",$p_category);

            $description=$_POST['description'];
            $description=str_replace("'", "\'",$description);
       
            //$userfile=$_POST['file'];
            $duedate=$_POST['duedate'];
            $userrequestedday=strtotime($duedate);
            // echo 'Previous Time: '.$duedate.' | New timeprep:'. $userrequestedday.' New Time ';
            
            //            print date("M d,Y - h:m A",$userrequestedday);
            $companyname=$_POST['companyname'];
            $companyname=str_replace("'", "\'",$companyname);
            $budget=$_POST['budget'];
            // $Gbday=$bday."-".$bMonth."-".$byear;
            $now=time();
             

            $sel_availables=$con->query("SELECT*from projects where p_owner='$account_key' and by_customer='1' ")or die($con->error);
            if($count_availables=$sel_availables->num_rows>0){
              echo '<div class="alert alert-soft-danger">
                      <div class="d-flex flex-wrap">
                          <div class="mr-8pt">
                              <i class="material-icons">close</i>
                          </div>
                          <div class="flex" style="min-width: 180px">
                              <small class="text-black-100">
                              <label style="color:red;">A Customer can have only one Application in Period <br />You may want to update data from <a href="user_dashboard.php">previous Project</a> instead!</label>
                              </small>
                          </div>
                      </div>
                  </div>';
              $alert="A Customer can have only one Application in Period <br />You may want to update data from previous Project instead!";
            }

            $sel_departments=$con->query("SELECT*from departments where id='$p_category' ")or die($con->error);
            $count_departments=$sel_departments->num_rows;
            $fetch_departments=$sel_departments->fetch_assoc();

            $supervisor=$fetch_departments['manager'];

            $bsns_modal=$fetch_departments['category_name'];




            if(!isset($alert)){
                $savequery=$con->query("INSERT INTO projects(p_tittle,description,due,status,p_owner,p_supervisor,created_on,by_customer,by_supervisor,business_modal,category,company_name,budget) VALUES ('$P_tittle','$description','$userrequestedday','Submited','$account_key','$supervisor','$now','1','0','$bsns_modal',$p_category,'$companyname','$budget')")or die($con->error);
                if ($savequery) {
                    $sendmsg=$con->query("INSERT INTO messages(msg_super,msg_user,msg_side,msg_date,msg_read,msg) VALUES('$supervisor','$account_key','User','$now','0','$description')")or die($con->error);

                    $approvo="Your Project has been submited!<br> ";
                    echo '<div class="alert alert-soft-success">
                    <div class="d-flex flex-wrap">
                        <div class="mr-8pt">
                            <i class="material-icons">check</i>
                        </div>
                        <div class="flex" style="min-width: 180px">
                            <small class="text-black-100">
                            <label style="color:Blue;">Success <br />Your Project has been submited <br><a href="user_dashboard.php"><u>Go to Review the Application</u></a>!</label>
                            </small>
                            <script>$("#project_form")[0].reset();</script>
                        </div>
                    </div>
                </div>';

                    // echo '<label style="color:green;">Success<br />Your '.$userid.' user account is activated</label>';
                    // $view_p=$con->query("SELECT*from customer where  password='$security' and  username='$userid' ")or die("Connection failed: ".$con->connect_error);
                    // $view=$view_p->fetch_assoc();
                    // //$id=$view['store_No'];
                    // $last_seen=time();
                    
                    //$_SESSION["access"] = $view['account_type'];
                }
            }
            
           }
  
   
  }
   else if(isset($_POST['login_mail'])){
    //Login Session 
    $login_mail=$_POST['login_mail'];
    $login_password=$_POST['login_password'];

    $username = $login_mail;
     $pass = md5($login_password);

    $query="select * from  customer  where password='".$pass."' and username='".$username."' or password='".$pass."' and email='".$username."' ";
    $result=mysqli_query($con,$query);
    if(mysqli_fetch_assoc($result))
    {
$view_p=$con->query("SELECT * from customer where  password='$pass' and  username='$username' or password='$pass' and email='$username'")or die("Connection failed: " . $con->connect_error);
      $view=$view_p->fetch_assoc();
      //$id=$view['store_No'];
      $last_seen=time();
      $_SESSION["giz_customer"] = $view['id'];
      //$_SESSION["access"] = $view['account_type'];
      $_SESSION["last_seen"] = $last_seen;

      $query=$con->query("UPDATE customer SET status='Online',last_seen='$last_seen' WHERE id ='".$view['id']."' ")or die($con->error);
      
      echo("<script>location.href='user_dashboard.php?load&user=".$view['username']."';</script>");

    echo '<div class="alert alert-soft-info">
    <div class="d-flex flex-wrap">
        <div class="mr-8pt">
            <i class="material-icons">check_circle</i>
        </div>
        <div class="flex" style="min-width: 180px">
            <small class="text-black-100">
                '.$login_mail.' Logged in a system.
            </small>
        </div>
    </div>
</div>';
              }else{
                echo '<div class="alert alert-soft-danger">
                <div class="d-flex flex-wrap">
                    <div class="mr-8pt">
                        <i class="material-icons">close</i>
                    </div>
                    <div class="flex" style="min-width: 180px">
                        <small class="text-black-100">
                        Invalid User name/email OR Password.
                        </small>
                    </div>
                </div>
            </div>';
              }     }
              
            
            
            ?>