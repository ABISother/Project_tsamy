<?php
//upload.php
include('connection.php');
if(isset($_POST["image"]))
{
 $data = $_POST["image"];
 $img_array_1 = explode(";", $data);
 $img_array_2 = explode(",", $img_array_1[1]);
 $basedecode = base64_decode($img_array_2[1]);
 $filename = time() . '_member.jpg';
 file_put_contents("assets/images/projects/$filename", $basedecode);
 //file_put_contents($filename, $basedecode);
 echo '<img src="assets/images/projects/'.$filename.'" class="img-thumbnail" />';
 echo '<input type="hidden" class="form-control" value="'.$filename.'"  name="imagename"  >';
 $now = date("Y-m-d H:i:s");
 //$sql = "INSERT INTO additions(caption, story_id, upload_date, file_name, deleted) VALUES ('$filename','40','$now','0')"; 
 //$con->query($sql); 
}else{
    echo '<div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">Select a quality Photo Please!<button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}

if(isset($_POST["blogimage"]))
{
 $data = $_POST["blogimage"];
 $img_array_1 = explode(";", $data);
 $img_array_2 = explode(",", $img_array_1[1]);
 $basedecode = base64_decode($img_array_2[1]);
 $filename = time() . '.jpg';
 file_put_contents("../img/photo/$filename", $basedecode);
 //file_put_contents($filename, $basedecode);
 echo '<img src="../img/photo/'.$filename.'" class="img-thumbnail" />';
 echo '<input type="hidden" class="form-control" value="'.$filename.'"  name="imagename"  >';
 $now = date("Y-m-d H:i:s");
 //$sql = "INSERT INTO additions(caption, story_id, upload_date, file_name, deleted) VALUES ('$filename','40','$now','0')"; 
 //$con->query($sql); 
}
?>