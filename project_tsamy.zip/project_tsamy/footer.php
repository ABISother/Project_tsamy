<div class="js-fix-footer2 bg-white border-top-2">
    <div class="container page__container page-section d-flex flex-column">
        <p class="text-70 brand mb-24pt">
            <img class="brand-icon" src="assets/images/logo/logo.png" width="30" alt="Wakanda E-Commerse Academy">  Rwanda
        </p>
        <p class="measure-lead-max text-50 small mr-8pt">We use our wide range of instruments and networks flexibly and innovatively to create value for our commissioning parties and to empower people to shape their own development processes.</p>
        <p class="mb-8pt d-flex">
            <a href="#" class="text-70 text-underline mr-8pt small">Terms</a>
            <a href="#" class="text-70 text-underline small">Privacy policy</a>
        </p>
        <p class="text-50 small mt-n1 mb-0">Copyright <?php echo date("Y"); ?> &copy; All rights reserved.</p>
    </div>
</div>



    <!-- drawer -->
    <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
        <div class="mdk-drawer__content">
            <div class="sidebar sidebar-dark-dodger-blue sidebar-left" data-perfect-scrollbar>


                <div class="d-flex align-items-center navbar-height">
                    <form action="#" class="search-form search-form--black mx-16pt pr-0 pl-16pt">
                        <input type="text" class="form-control pl-0" placeholder="Search">
                        <button class="btn" type="submit"><i class="material-icons">search</i></button>
                    </form>
                </div>



                <a href="index.php" class="sidebar-brand ">
                    <!-- <img class="sidebar-brand-icon" src="assets/images/illustration/student/128/white.svg" alt="Luma"> -->

                    <span class="avatar avatar-xl sidebar-brand-icon h-auto">

     <span class="avatar-title rounded "><img src="assets/images/logo/logo.png" alt="logo" class="img-fluid" /></span>

                    </span>

                    <span>GIZ Rwanda</span>
                </a>

                <div class="sidebar-heading">Client</div>
                <ul class="sidebar-menu">


                    <li class="sidebar-menu-item active">
                        <a class="sidebar-menu-button" href="index.php">
                            <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">home</span>
                            <span class="sidebar-menu-text">Home</span>
                        </a>
                    </li>
                    <li class="sidebar-menu-item">
                        <a class="sidebar-menu-button" href="apply.php">
                            <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">local_library</span>
                            <span class="sidebar-menu-text">Browse Programs</span>
                        </a>
                    </li>

                    
    <?php if(isset($_SESSION["giz_customer"])){?>
        <li class="sidebar-menu-item">
                        <a class="sidebar-menu-button" href="user_dashboard.php">
                        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">dashboard</span>
                            <span class="sidebar-menu-text">Dashboard</span>
                        </a>
                    </li>

                    <li class="sidebar-menu-item">
                        <a class="sidebar-menu-button" href="user_profile.php">
                        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">account_box</span>
                            <span class="sidebar-menu-text">Profile</span>
                        </a>
                    </li>

                    
                    <li class="sidebar-menu-item">
                            <a class="sidebar-menu-button"  href="messages.php">
                                <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">message</span>
                                Messaging
                                <span class="sidebar-menu-badge badge badge-accent badge-notifications ml-auto">2</span>
                                <span class="sidebar-menu-toggle-icon"></span>
                            </a>
                            
                        </li>

                    

                    <?php } ?>
                  
                </ul>


            </div>
        </div>
    </div>
    <!-- // END drawer -->
