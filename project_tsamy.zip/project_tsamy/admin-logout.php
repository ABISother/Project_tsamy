<?php
session_start();

require_once('connection.php');
if(isset($_SESSION["giz_supervisor"])){
	
	if (isset($_GET['falseuser'])) {
        $query=$con->query("UPDATE users SET status='Offline' WHERE id ='".$_SESSION["giz_supervisor"]."' ")or die($con->error);
        unset($_SESSION["giz_supervisor"]);
        unset($_SESSION["access"]);
        unset($_SESSION['p_attempt']);
		unset($_SESSION["Manager"]);
		echo("<script>location.href='admin-login.php?warning=You are Logged out due attempt to change Security, It appeals you are not AUTOLIZED';</script>");
    }
    else{

$query=$con->query("UPDATE users SET status='Offline' WHERE id ='".$_SESSION["giz_supervisor"]."' ")or die($con->error);
	 unset($_SESSION["giz_supervisor"]);
	 unset($_SESSION["access"]);
	 unset($_SESSION["Manager"]);
	 echo("<script>location.href='admin-login.php';</script>");
	}
	}else{
		echo("<script>location.href='admin-login.php';</script>");
	}
?>