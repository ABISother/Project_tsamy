<?php
session_start();
include('connection.php'); 
if(!isset($_SESSION["giz_customer"])){
    // echo("<script>location.href='start.php';</script>");
   // // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
   // //  echo("<script>location.href='lock.php';</script>");
   // echo '<label color="red">You are not Authorized</label>';
    }else{
   
$account_key=$_SESSION["giz_customer"];
$sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['username'];
$customer_names=$fetch_account['username'];
$customeremail=$fetch_account['email'];

    }
   ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Projects</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">

    <!-- Ajax reasons-->
   <script src="assets/js/jquery.min.js"></script>








</head>








<body class="layout-sticky-subnav layout-default ">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <div id="header" class="mdk-header js-mdk-header mb-0" data-fixed data-effects="">
            <div class="mdk-header__content">

                <?php

                include("header.php");
        
                ?>


            </div>
        </div>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content page-content ">






            <div class="container page__container page-section pb-0">
                <h1 class="h2 mb-0">Projects</h1>
                <ol class="breadcrumb m-0 p-0">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                 
                    <li class="breadcrumb-item active">Projects</li>
                </ol>
            </div>

            <div class="container page__container page-section">

                <div class="page-separator">
                    <div class="page-separator__text">Projects</div>
                </div>

                <div class="card dashboard-area-tabs p-relative o-hidden mb-lg-32pt">
                    <div class="card-header p-0 nav">
                        <div class="row no-gutters" role="tablist">
                            <div class="col-auto">
                                <a href="#" data-toggle="tab" data-target="#list-of-projects" id="projects-tab" role="tab" aria-selected="true" class="dashboard-area-tabs__tab card-body d-flex flex-row align-items-center justify-content-start active">
                                    <span class="h2 mb-0 mr-3"><?php echo $count_all_project; ?></span>
                                    <span class="flex d-flex flex-column">
                                        <strong class="card-title">Active</strong>
                                        <small class="card-subtitle text-50">Ongoing Projects</small>
                                    </span>
                                </a>
                            </div>
                            <div class="col-auto border-left border-right">
                                <a href="#" data-toggle="tab"  data-target="#my-new-project" id="myproject-tab" role="tab" aria-selected="false" class="dashboard-area-tabs__tab card-body d-flex flex-row align-items-center justify-content-start">
                                    <span class="h2 mb-0 mr-3">2</span>
                                    <span class="flex d-flex flex-column">
                                        <strong class="card-title">Archived</strong>
                                        <small class="card-subtitle text-50">Past Projects</small>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>

                    


                    <div  class="card-body tab-pane fade show" id="list-of-projects" role="tabpanel" aria-labelledby="myproject-tab">
                        <div>
                        <div class="card m-0">

                        <div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-employee-name" data-lists-values='["js-lists-values-employee-name", "js-lists-values-employer-name", "js-lists-values-projects", "js-lists-values-activity", "js-lists-values-earnings"]'>

                            <div class="card-header">
                                <div class="search-form">
                                    <input type="text" class="form-control search" placeholder="Search ...">
                                    <button class="btn" type="button"><i class="material-icons">search</i></button>
                                </div>
                            </div>




                            <table class="table mb-0 thead-border-top-0 table-nowrap">
                                <thead>
                                    <tr>

                                        <th>
                                            <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-employee-name">Project Name</a>
                                        </th>
                                        <th style="width: 37px;">Supervisor</th>
                                        <th style="width: 37px;">Status</th>

                                        <th style="width: 120px;">
                                            <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-activity">Due</a>
                                        </th>
                                        <th style="width: 51px;">
                                            <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-earnings">Partners</a>
                                        </th>
                                        <th style="width: 24px;" class="pl-0"></th>
                                    </tr>
                                </thead>
                                <tbody class="list" id="search">
                            <?php
                                if($count_all_project>0){ 
                                    while($fetch_giz_project=$sel_all_project->fetch_assoc()){ 
                                        $person=$fetch_giz_project['p_supervisor'];
                                        $cat_id=$fetch_giz_project['id'];
                                        $thisproject=$fetch_giz_project['id'];

                                        $sel_supervisor=$con->query("SELECT*from users where id='$person'")or die($con->error);
                                        $fetch_supervisor=$sel_supervisor->fetch_assoc();
                                        ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex flex-column">
                                                <p class="mb-0"><strong class="js-lists-values-employee-name"><?php echo $fetch_giz_project['p_tittle']; ?></strong></p>
                                                <small class="js-lists-values-employee-email text-50">In <strong><?php echo $fetch_giz_project['business_modal']; ?></strong></small>
                                            </div>
                                        </td>
                                        <td>
                                                <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                                    <div class="avatar avatar-sm mr-8pt">
                                                        <img src="assets/images/people/110/guy-1.jpg" alt="Avatar" class="avatar-img rounded-circle">
                                                    </div>
                                                    <div class="media-body">
                                                        <div class="d-flex align-items-center">
                                                            <div class="flex d-flex flex-column">
                                                                <p class="mb-0"><strong class="js-lists-values-lead"><?php echo $fetch_supervisor['user_name']; ?></strong></p>
                                                                <small class="js-lists-values-email text-50">Marketing</small>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                        </td>
                                        <td>
                                            <a href="#" class="chip chip-outline-secondary"><?php echo $fetch_giz_project['status']; ?></a>
                                        </td>
                                        <td class="text-50 js-lists-values-activity small"><?php $jointime=$fetch_giz_project['due'];
                                                print date("(D) M d, Y ",$jointime); ?></td>
                                        <td class="js-lists-values-earnings small"><?php echo $fetch_giz_project['company_name']; ?></td>
                                        <td class="text-right pl-0">
                                        <a <?php if(!isset($_SESSION["giz_customer"])){ echo 'href="login.php?alert=You must Login first!"';}else{ echo 'href="projects.php?apply='.$thisproject.'&cust='.$account_key.'"';} ?> class="chip chip-outline-secondary">Apply</a>
                                        </td>
                                    </tr>

                                    <?php } }else{ ?>


                                    <tr>

                                        <td colspan="3">


                                            <div class="d-flex flex-column">
                                                <p class="mb-0"><strong class="js-lists-values-employee-name">Currently there is no Project from GIZ staff &amp; </strong></p>
                                                <small class="js-lists-values-employee-email text-50">info@giz.com</small>
                                            </div>


                                        </td>



                                        
                                    </tr>
                                    <?php } ?>

                                    

                                </tbody>
                            </table>
                        </div>


</div>
                        </div>
                    </div>

             

                </div>

        


            </div>




        </div>
        <!-- // END Header Layout Content -->


        <?php

        include("footer.php");
        
        ?>







   


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>


    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

    <!-- Select2 -->
    <script src="assets/vendor/select2/select2.min.js"></script>
    <script src="assets/js/select2.js"></script>


    <!-- ========= -->
       <!-- jQuery -->
       <script src="assets/vendor/jquery.min.js"></script>

<!-- Bootstrap -->
<script src="assets/vendor/popper.min.js"></script>
<script src="assets/vendor/bootstrap.min.js"></script>

<!-- Perfect Scrollbar -->
<script src="assets/vendor/perfect-scrollbar.min.js"></script>

<!-- DOM Factory -->
<script src="assets/vendor/dom-factory.js"></script>

<!-- MDK -->
<script src="assets/vendor/material-design-kit.js"></script>

<!-- Fix Footer -->
<script src="assets/vendor/fix-footer.js"></script>

<!-- App JS -->
<script src="assets/js/app.js"></script>


<!-- Touchspin -->
<script src="assets/vendor/jquery.bootstrap-touchspin.js"></script>
<script src="assets/js/touchspin.js"></script>

<!-- Flatpickr -->
<script src="assets/vendor/flatpickr/flatpickr.min.js"></script>
<script src="assets/js/flatpickr.js"></script>

<!-- DateRangePicker -->
<script src="assets/vendor/moment.min.js"></script>
<script src="assets/vendor/daterangepicker.js"></script>
<script src="assets/js/daterangepicker.js"></script>


    <!-- DateRangePicker -->
    <link type="text/css" href="assets/vendor/daterangepicker.css" rel="stylesheet">

<!-- jQuery Mask Plugin -->
<script src="assets/vendor/jquery.mask.min.js"></script>

<!-- Quill -->
<script src="assets/vendor/quill.min.js"></script>
<script src="assets/js/quill.js"></script>

<!-- Select2 -->
<script src="assets/vendor/select2/select2.min.js"></script>
<script src="assets/js/select2.js"></script>
</body>



</html>