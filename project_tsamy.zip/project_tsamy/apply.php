<?php
session_start();
if(!isset($_SESSION["giz_customer"])){
    // echo("<script>location.href='start.php';</script>");
   // // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
   // //  echo("<script>location.href='lock.php';</script>");
   // echo '<label color="red">You are not Authorized</label>';
    }else{
    include('connection.php'); 
$account_key=$_SESSION["giz_customer"];
$sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['username'];
$customer_names=$fetch_account['username'];
$customeremail=$fetch_account['email'];



if(isset($_POST['apply_proj'])){
    $p_name=$_POST['projectname'];
    $project_id=$_POST['projectid'];
    $supervisor_id=$_POST['supid'];
    $now=time();
    
    $sel_availables=$con->query("SELECT*from applys where user_id='$account_key' and project_id='$project_id' ")or die($con->error);
    if($count_availables=$sel_availables->num_rows>0){
      
      $alert= '<div class="alert alert-soft-danger">
      <div class="d-flex flex-wrap">
          <div class="mr-8pt">
              <i class="material-icons">close</i>
          </div>
          <div class="flex" style="min-width: 180px">
              <small class="text-black-100">
              <label style="color:red;">Dear '.$names.' you have already Applied to Project '.$P_name.'<br />Please Select Differnt project or check Your application status! </label>
              </small>
          </div>
      </div>
  </div>';

  echo '<script>alert("You Already Applied to Project")</script>';

}


if(!isset($alert)){
    $savequery=$con->query("INSERT INTO applys(user_id,project_id,supervisor_id,status,projectname,customer_comment,user_comment,progress,applied_on) VALUES ('$account_key',' $project_id','$supervisor_id','Submited','$p_name','I am applyng to this Project!','We will look into your Application very Soon','5','$now')")or die($con->error);
    if ($savequery) {
        $approvo="Your Application is Sent!<br> ";
        $sendmsg=$con->query("INSERT INTO messages(msg_super,msg_user,msg_side,msg_date,msg_read,msg) VALUES('$supervisor_id','$account_key','User','$now','0','I Have just applied on project Tittled $p_name <br> Kindly check my Submittion!')")or die($con->error);

    }
}

    }//end Submittion
}
   ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Applications</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">

    <!-- Ajax reasons-->
   <script src="assets/js/jquery.min.js"></script>
 







</head>








<body class="layout-sticky-subnav layout-default ">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <div id="header" class="mdk-header js-mdk-header mb-0" data-fixed data-effects="">
            <div class="mdk-header__content">





 
                <?php

                include("header.php");
        
                ?>



            </div>
        </div>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content page-content ">











        <div class="container page__container page-section pb-0">
                <h1 class="h2 mb-0">Projects</h1>
                <ol class="breadcrumb m-0 p-0">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                 
                    <li class="breadcrumb-item active">Projects</li>
                </ol>
            </div>

            <div class="container page__container page-section">
            <?php if(isset($approvo)){ ?>
        <div class="alert alert-soft-success alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Success - </strong> <?php echo $approvo; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>
                      <?php if(isset($_GET['alert'])){ ?>
                        <div class="alert alert-soft-accent alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Alert - </strong> <?php echo $_GET['alert']; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>
                <div class="page-separator">
                    <div class="page-separator__text">Projects</div>
                </div>

                <div class="card dashboard-area-tabs p-relative o-hidden mb-lg-32pt">
                    <div class="card-header p-0 nav">
                        <div class="row no-gutters" role="tablist">
                            <div class="col-auto">
                                <a href="#" data-toggle="tab" data-target="#list-of-projects" id="projects-tab" role="tab" aria-selected="true" class="dashboard-area-tabs__tab card-body d-flex flex-row align-items-center justify-content-start active">
                                    <span class="h2 mb-0 mr-3"><?php echo $count_all_project; ?></span>
                                    <span class="flex d-flex flex-column">
                                        <strong class="card-title">Available Projects</strong>
                                        <small class="card-subtitle text-50">Select One of giz projects</small>
                                    </span>
                                </a>
                            </div>
                            <div class="col-auto border-left border-right">
                                <a href="#My_request"  class="dashboard-area-tabs__tab card-body d-flex flex-row align-items-center justify-content-start">
                                    <span class="h2 mb-0 mr-3">2</span>
                                    <span class="flex d-flex flex-column">
                                        <strong class="card-title">My project</strong>
                                        <small class="card-subtitle text-50">Submit Your Own Idea</small>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>

                    


                    <div  class="card-body tab-pane fade show" id="list-of-projects" role="tabpanel" aria-labelledby="myproject-tab">
                        <div>
                        <div class="card m-0">

<div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-employee-name" data-lists-values='["js-lists-values-employee-name", "js-lists-values-employer-name", "js-lists-values-projects", "js-lists-values-activity", "js-lists-values-earnings"]'>

    <div class="card-header">
        <div class="search-form">
            <input type="text" class="form-control search" placeholder="Search ...">
            <button class="btn" type="button"><i class="material-icons">search</i></button>
        </div>
    </div>




    <table class="table mb-0 thead-border-top-0 table-nowrap">
        <thead>
            <tr>

                <th>
                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-employee-name">Project Name</a>
                </th>
                <th style="width: 37px;">Supervisor</th>
                <th style="width: 37px;">Status</th>

                <th style="width: 120px;">
                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-activity">Activity</a>
                </th>
                <th style="width: 51px;">
                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-earnings">Partners</a>
                </th>
                <th style="width: 24px;" class="pl-0"></th>
            </tr>
        </thead>
        <tbody class="list" id="search">
       <?php
          if($count_all_project>0){ 
            while($fetch_giz_project=$sel_all_project->fetch_assoc()){ 
                $person=$fetch_giz_project['p_supervisor'];
                $cat_id=$fetch_giz_project['id'];
                $thisproject=$fetch_giz_project['id'];

                $sel_supervisor=$con->query("SELECT*from users where id='$person'")or die($con->error);
                $fetch_supervisor=$sel_supervisor->fetch_assoc();
                if(isset($account_key)){
                $sel_availables=$con->query("SELECT*from applys where user_id='$account_key' and project_id='$thisproject' ")or die($con->error);
                if($count_availables=$sel_availables->num_rows>0){
                    $fetch_nowstatus=$sel_availables->fetch_assoc();
                    $applyied_this=1;

                }else{
                    $applyied_this=0;
                }
            }else{
                $applyied_this=0;
            }
                  
                ?>
              
            <tr>
                <td>
                    <div class="d-flex flex-column">
                        <p class="mb-0"><strong class="js-lists-values-employee-name"><?php echo $fetch_giz_project['p_tittle']; ?></strong></p>
                        <small class="js-lists-values-employee-email text-50">In <strong><?php echo $fetch_giz_project['business_modal']; ?></strong></small>
                    </div>
                </td>
                <td>
                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                            <div class="avatar avatar-sm mr-8pt">
                                <img src="assets/images/users/<?php echo $fetch_supervisor['profile']; ?>" alt="Avatar" class="avatar-img rounded-circle">
                            </div>
                            <div class="media-body">
                                <div class="d-flex align-items-center">
                                    <div class="flex d-flex flex-column">
                                        <p class="mb-0"><strong class="js-lists-values-lead"><?php echo $fetch_supervisor['user_name']; ?></strong></p>
                                        <small class="js-lists-values-email text-50">Marketing</small>
                                    </div>
                                </div>

                            </div>
                        </div>
                </td>
                <td>
                    <?php if($applyied_this==0){ ?>
                    <a href="project_view.php?view=<?php echo $fetch_giz_project['id']; ?>" class="chip chip-outline-secondary">View</a><br>
                    <?php echo $fetch_giz_project['status']; ?>
                    <?php }else{ ?>
                     
                        <div class="d-flex flex-column" title="You Have applied on this Project">
                                            <small class="js-lists-values-status text-50 mb-4pt"><?php echo $fetch_nowstatus['status']; ?></small>
                                            <span class="indicator-line rounded bg-accent"></span>
                                        </div>
                   <?php }  ?>
                </td>
                <td class="text-50 js-lists-values-activity small"><?php $jointime=$fetch_giz_project['due'];
                        print date("(D) M d, Y ",$jointime); ?></td>
                <td class="js-lists-values-earnings small"><?php echo $fetch_giz_project['company_name']; ?></td>
                <td class="text-right pl-0">
                <form action="apply.php?sub" method="post" name="application-form<?php echo $fetch_giz_project['id']; ?>" >
                    <input type="hidden" name="projectid"  value="<?php echo $thisproject; ?>"  >
                    <input type="hidden" name="projectname"  value="<?php echo $fetch_giz_project['p_tittle']; ?>"  >
                    <input type="hidden" name="supid"  value="<?php echo $fetch_supervisor['id']; ?>"  >

                    <?php if($applyied_this==1){ ?>
                        <a href="user_dashboard.php?progress=<?php echo $fetch_nowstatus['id']; ?>"  class="chip chip-outline-accent">Progress</a>
                    <?php }else{ ?>
                    <?php if(!isset($_SESSION["giz_customer"])){?>
                <a href="login.php?alert=You must Login first!"  class="chip chip-outline-secondary">Apply</a>
                <?php }else{ ?>
                    
                    <button  type="submit" name="apply_proj" class="chip chip-outline-secondary">Apply</Buttons>
                    
                <?php } } ?>
                </form>
                </td>
            </tr>
                
            <?php } }else{?>


            <tr>

                <td colspan="3">


                    <div class="d-flex flex-column">
                        <p class="mb-0"><strong class="js-lists-values-employee-name">Currently there is no Project from GIZ staff &amp; </strong></p>
                        <small class="js-lists-values-employee-email text-50">paolo.zieme@gmail.com</small>
                    </div>


                </td>



                
            </tr>
            <?php } ?>

            

        </tbody>
    </table>
</div>


</div>
                        </div>
                    </div>

                    <div class="card-footer p-8pt">

                

                    </div>
                  

                </div>


            

               
                <div class="page-separator justify-content-center " id="My_request">
                                    <div class="page-separator__text">Submit your Project</div>
                                     </div>

                                     <?php  if(isset($_SESSION['giz_customer'])){ ?>
                <div class="row mb-32pt">
                    <div class="col-lg-4">
                        <div class="page-separator">
                            <div class="page-separator__text">Propose a project</div>
                        </div>
                        <p class="card-subtitle text-70 mb-16pt mb-lg-0">With this <code>inputs</code>, You can also Submit your Idea or Current project that you wish giz to support you with..</p>
                    </div>
                    <div class="col-lg-8 d-flex align-items-center">
                        <div class="flex" style="max-width: 100%">

                        <form id="app_form" method="post" enctype="multipart/form-data">
                            <div class="was-validated">
                                
                                    <div class="form-group">
                                        <label class="form-label" for="validationSample01">Project Tittle</label>
                                        <input type="text" class="form-control" id="validationSample01" name="P_tittle" placeholder="Your Project Tittle..."  required="">
                                        <div class="invalid-feedback">Please provide a Project Name.</div>
                                        <div class="valid-feedback">Looks good, Just make sure it meets your wishes!</div>
                                    </div>
                                   
                               
                                
                                <div class="form-group">
                                <label class="form-label" for="p_category">Project category</label>
                                <select id="p_category"  name="p_category" class="form-control" required="">
                                <option value="" selected="">
                                        Select a category related to your ideal
                                    </option>   
                                    <?php
                                    
                                         while($fetch_all_departments=$sel_all_departments->fetch_assoc()){ 
                                            

                                        ?>
                                
                                <option value="<?php echo $fetch_all_departments['id'] ?>" >
                                <?php echo $fetch_all_departments['category_name'] ?>
                                    </option>
                                    <?php } ?>
                                   
                                </select>
                                <div class="invalid-feedback">Please select, This helps to determine who should supervise your case!.</div>
                                        <div class="valid-feedback">Okay, Just make sure the category is related to your Project!</div>
                                </div>

                                <div class="form-group">
                                <label class="form-label" for="validationSample02">Explain Your Project</label>
                                        <label class="form-label" for="custom-select"></label>
                                        <textarea row="6" class="form-control"  name="description" id="description" required="" ></textarea>
                                </div>

                                

                                <div class="form-group">
                                <label class="form-label" for="dateRangePickerSample01">Pick an Estimated Due Date</label>
                                <input id="dateRangePickerSample01" name="duedate" type="date" class="form-control" placeholder="Date refered to be a Due"  required="" >
                                </div>

                               <div class="form-row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label" for="validationSample03">Company Name</label>
                                        <input type="text" class="form-control" id="validationSample03" name="companyname" placeholder="Company" <?php if(isset($customer_names)){ echo 'value="'.$customer_names.'"';} ?> required="" >
                                        <div class="invalid-feedback">Please provide a valid Campany Name,If is unavailable you can LABEL This with your Name.</div>
                                        <div class="valid-feedback">Looks good!</div>
                                    </div>
                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label" for="validationSample04">Badget Range</label>
                                        <input type="number" name="budget" class="form-control" id="validationSample04" placeholder="$0 - $12,500" >
                                        <div class="invalid-feedback">You may provide just a maximum amount.</div>
                                        <div class="valid-feedback">Provide if you are aware of how the project stands!</div>
                                    </div>
                                </div> 
                                
                            <div class="form-group m-0">
                            <label class="form-label" for="validationSample03">Attach any related file you may have</label>
                                <div class="custom-file">
                                    <input type="file" id="file" name="file1" class="custom-file-input" >
                                    <label for="file" class="custom-file-label">Choose file</label>
                                 
                                     <div class="valid-feedback">Looks good, Just make sure it meets your wishes!</div>
                                </div>
                            </div>
                            </div>
                            <br>
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" name="agrements" value="" id="invalidCheck01" required="" >
                                    <label class="custom-control-label" for="invalidCheck01">
                                        Agree to terms and conditions
                                    </label>
                                </div>
                            </div>
                            <div id="msg" ></div>
                            <button class="btn btn-primary col-md-12" type="submit">Submit</button>

                                                    <script>

                                                        $(document).ready(function(){
                                                        
                                                            $('#app_form').on('submit', function(event){
                                                          event.preventDefault();
                                                          if($('#p_tittle').val() != '' && $('#d_date').val() != '')
                                                          {
                                                           var form_data = $(this).serialize();
                                                           $.ajax({
                                                            url:"process.php",
                                                            method:"POST",
                                                            data:form_data,
                                                            success:function(data)
                                                            {
                                                             //$('#assign_form')[0].reset();
                                                             $('#msg').html(data);
                                                            }
                                                           })
                                                          }
                                                          else
                                                          {
                                                           alert("Both Fields are Required");
                                                          }
                                                         });

                                                                                                          

                                                        });

                                                    </script>
                                                    </form>
                        </div>
                    </div>
                </div>

<?php }else{ ?>
    <div class="alert alert-soft-danger">
           <div class="d-flex flex-wrap">
               <div class="mr-8pt">
                   <i class="material-icons">user</i>
               </div>
               <div class="flex" style="min-width: 180px">
                   <small class="text-black-100">
                   <label style="color:red;"> You must first <a href="login.php">Login</a> or <a href="start.php">register (if you are not)</a> to the system to perfom this action</label>
                   </small>
               </div>
           </div>
       </div>
<?php } ?>
                




                                                    </div>





        </div>
        <!-- // END Header Layout Content -->


        <?php

        include("footer.php");
        
        ?>


    </div>
    <!-- // END Header Layout -->




   


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>


    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

    <!-- Select2 -->
    <script src="assets/vendor/select2/select2.min.js"></script>
    <script src="assets/js/select2.js"></script>


    <!-- ========= -->
       <!-- jQuery -->
       <script src="assets/vendor/jquery.min.js"></script>

<!-- Bootstrap -->
<script src="assets/vendor/popper.min.js"></script>
<script src="assets/vendor/bootstrap.min.js"></script>

<!-- Perfect Scrollbar -->
<script src="assets/vendor/perfect-scrollbar.min.js"></script>

<!-- DOM Factory -->
<script src="assets/vendor/dom-factory.js"></script>

<!-- MDK -->
<script src="assets/vendor/material-design-kit.js"></script>

<!-- Fix Footer -->
<script src="assets/vendor/fix-footer.js"></script>

<!-- App JS -->
<script src="assets/js/app.js"></script>


<!-- Touchspin -->
<script src="assets/vendor/jquery.bootstrap-touchspin.js"></script>
<script src="assets/js/touchspin.js"></script>

<!-- Flatpickr -->
<script src="assets/vendor/flatpickr/flatpickr.min.js"></script>
<script src="assets/js/flatpickr.js"></script>

<!-- DateRangePicker -->
<script src="assets/vendor/moment.min.js"></script>
<script src="assets/vendor/daterangepicker.js"></script>
<script src="assets/js/daterangepicker.js"></script>


    <!-- DateRangePicker -->
    <link type="text/css" href="assets/vendor/daterangepicker.css" rel="stylesheet">

<!-- jQuery Mask Plugin -->
<script src="assets/vendor/jquery.mask.min.js"></script>

<!-- Quill -->
<script src="assets/vendor/quill.min.js"></script>
<script src="assets/js/quill.js"></script>

<!-- Select2 -->
<script src="assets/vendor/select2/select2.min.js"></script>
<script src="assets/js/select2.js"></script>
</body>



</html>