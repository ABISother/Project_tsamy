<?php
session_start();
if(!isset($_SESSION["giz_customer"])){
    // echo("<script>location.href='start.php';</script>");
   // // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
   // //  echo("<script>location.href='lock.php';</script>");
   // echo '<label color="red">You are not Authorized</label>';
    }else{
    include('connection.php'); 
$account_key=$_SESSION["giz_customer"];
$sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
$fetch_account=$sel_account->fetch_assoc();
$names=$fetch_account['username'];
$customer_names=$fetch_account['username'];
$customeremail=$fetch_account['email'];
    }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Project Preview</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">





</head>



<body class="layout-sticky-subnav layout-default ">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout" >

    <div id="header" class="mdk-header js-mdk-header mb-0" data-fixed data-effects="">
            <div class="mdk-header__content">

    <?php

include("header.php");

?>
            </div>
        </div>

        <!-- // END Header -->
        <?php
        if(isset($_GET['view'])){
            $current_project=$_GET['view'];
        }else{
            echo("<script>location.href='apply.php?alert=choose a project please';</script>");
        }
         $sel_this_project=$con->query("SELECT*from projects where id='$current_project' ")or die($con->error);
         if($count_all_project=$sel_this_project->num_rows<1){
            echo("<script>location.href='user_dashboard.php?alert=The Seleccted Event Seems to be Deleted';</script>");
         }
        
            $fetch_giz_project=$sel_this_project->fetch_assoc(); 
                $person=$fetch_giz_project['p_supervisor'];
                $cat_id=$fetch_giz_project['id'];
                $thisproject=$fetch_giz_project['id'];

                $sel_supervisor=$con->query("SELECT*from users where id='$person'")or die($con->error);
                $fetch_supervisor=$sel_supervisor->fetch_assoc();
                if(isset($account_key)){
                $sel_availables=$con->query("SELECT*from applys where user_id='$account_key' and project_id='$thisproject' ")or die($con->error);
                if($count_availables=$sel_availables->num_rows>0){
                    $fetch_nowstatus=$sel_availables->fetch_assoc();
                    $applyied_this=1;

                }else{
                    $applyied_this=0;
                }
            }else{
                $applyied_this=0;
            }
                  
                ?>
        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content page-content ">



            <div class="mdk-header mdk-header--bg-dark bg-dark js-mdk-header mb-0" data-effects="blend-background">
                <div class="mdk-box__content">
            <div class="mdk-header__bg-front" style="background-image: url(assets/images/new_imgs/2020_05_19_20_34_IMG_4454.JPG); "></div>
                    <div class="hero py-64pt text-center text-sm-left">
                        <div class="container page__container">
                            <h1 class="text-white"><?php echo $fetch_giz_project['p_tittle']; ?></h1>
                            <!-- <p class="lead text-white-50 measure-hero-lead"><?php echo $fetch_giz_project['description']; ?></p> -->
                            <div class="d-flex flex-column flex-sm-row align-items-center justify-content-start">
                            <form action="apply.php?sub" method="post" name="application-form<?php echo $fetch_giz_project['id']; ?>" >
                    <input type="hidden" name="projectid"  value="<?php echo $thisproject; ?>"  >
                    <input type="hidden" name="projectname"  value="<?php echo $fetch_giz_project['p_tittle']; ?>"  >
                    <input type="hidden" name="supid"  value="<?php echo $fetch_supervisor['id']; ?>"  >

                    <?php if($applyied_this==1){ ?>
                        <a href="user_dashboard.php?progress=<?php echo $fetch_nowstatus['id']; ?>"  class="chip chip-outline-accent">Progress</a>
                    <?php }else{ ?>
                    <?php if(!isset($_SESSION["giz_customer"])){?>
                <a href="login.php?alert=You must Login first!"  class="btn btn-outline-white mb-16pt mb-sm-0 mr-sm-16pt">Quick Apply <i class="material-icons icon--right">play_circle_outline</i></a>
                <?php }elseif($fetch_giz_project['by_customer']=='0'){ ?>
                    
                    <button  type="submit" name="apply_proj" class="chip chip-outline-secondary">Quick Apply</Buttons>
                    
                <?php } } ?>
                </form>
                                <!-- <a href="fixed-student-lesson.html" class="btn btn-outline-white mb-16pt mb-sm-0 mr-sm-16pt">Apply <i class="material-icons icon--right">play_circle_outline</i></a> -->
                                <!-- <a href="fixed-pricing.html" class="btn btn-white">Start your free trial</a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="navbar navbar-expand-sm navbar-light bg-white border-bottom-2 navbar-list p-0 m-0 align-items-center">
                <div class="container page__container">
                    <ul class="nav navbar-nav flex align-items-sm-center">
                        <li class="nav-item navbar-list__item">
                            <div class="media align-items-center">
                                <span class="media-left mr-16pt">
                                    <img src="assets/images/people/50/guy-6.jpg" width="40" alt="avatar" class="rounded-circle">
                                </span>
                                <div class="media-body">
                                    <a class="card-title m-0" href="#"><?php echo $fetch_supervisor['user_name']; ?></a>
                                    <p class="text-50 lh-1 mb-0">Supervisor</p>
                                </div>
                            </div>
                        </li>
                       
                        <li class="nav-item navbar-list__item">
                            <i class="material-icons text-muted icon--left">assessment</i>
                            <?php echo $fetch_giz_project['business_modal']; ?>
                        </li>
                        <li class="nav-item ml-sm-auto text-sm-center flex-column navbar-list__item">
                        Due
                            <p class="lh-1 mb-0"><small class="text-muted"><?php $nowtime=$fetch_giz_project['due'];
                                                         print date("M d, Y",$nowtime); ?> </small></p>
                        </li>
                    </ul>
                </div>
              
            </div>
            
            

            <div class="page-section border-bottom-2">
                <div class="container page__container">

                    <div class="page-separator">
                        <div class="page-separator__text">More to this Project</div>
                    </div>
             
                </div>
            </div>

            <div class="page-section bg-alt border-bottom-2">


                <div class="container page__container">
                    <div class="row ">
                        <div class="col-md-6">
                            <div class="page-separator">
                                <div class="page-separator__text">About this Project</div>
                            </div>
                            
                            <p class="text-70"><?php echo $fetch_giz_project['description']; ?></p>

                        </div>
                        <div class="col-md-6">
                            <div class="page-separator">
                                <div class="page-separator__text bg-alt">Your Application</div>
                            </div>

                            <?php if($applyied_this==0){ ?>
                                <div class="accordion js-accordion accordion--boxed list-group-flush" id="parent">
                        
                        <div class="accordion__item open">
                            <a href="#" class="accordion__toggle" data-toggle="collapse" data-target="#course-toc-2" data-parent="#parent">
                                <span class="flex">Act Now </span>
                                <span class="accordion__toggle-icon material-icons">keyboard_arrow_down</span>
                            </a>
                            <div class="accordion__menu collapse show" id="course-toc-2">
                               
                                <div class="card-body py-16pt text-center">
                                   
                                <form action="apply.php?sub" method="post" name="application-form<?php echo $fetch_giz_project['id']; ?>" >
                    <input type="hidden" name="projectid"  value="<?php echo $thisproject; ?>"  >
                    <input type="hidden" name="projectname"  value="<?php echo $fetch_giz_project['p_tittle']; ?>"  >
                    <input type="hidden" name="supid"  value="<?php echo $fetch_supervisor['id']; ?>"  >

                    <?php if($applyied_this==1){ ?>
                        <a href="user_dashboard.php?progress=<?php echo $fetch_nowstatus['id']; ?>"  class="chip chip-outline-accent">Progress</a>
                    <?php }else{ ?>
                    <?php if(!isset($_SESSION["giz_customer"])){?>
                <a href="login.php?alert=You must Login first!"  class="btn btn-accent mb-8pt">Apply <i class="material-icons icon--right">play_circle_outline</i></a>
                <p class="mb-0">Have an account? <a href="login.php">Login</a></p>
                <?php }elseif($fetch_giz_project['by_customer']=='0'){ ?>
                    
                    <button  type="submit" name="apply_proj" class="btn btn-accent ">Apply This</Button>
                    
                <?php }else{ ?>
                    <div class="col-lg-12 d-flex align-items-center">
                        <div class="flex" style="max-width: 100%">

                    <span>Progress</span>
                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $fetch_giz_project['progress']; ?>%;" aria-valuenow="<?php echo $fetch_giz_project['progress']; ?>" aria-valuemin="0" aria-valuemax="100"><?php echo $fetch_giz_project['progress']; ?>%</div>
                            </div>

                        </div>
                    </div>
              <?php  } } ?>
                </form>
               
                                    
                                </div>
                            </div>
                        </div>
                      
                    
                    </div>
                                <?php }else{ ?>
                            
                                         <!-- progressbar -->
                <div class="col-lg-12 d-flex align-items-center">
                        <div class="flex" style="max-width: 100%">


                            <div class="progress" style="height: 20px;">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $fetch_nowstatus['progress']; ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?php echo $fetch_nowstatus['progress']; ?>%</div>
                            </div>

                        </div>
                    </div>
                <!-- End of progressbar -->
                <?php } ?>
                        </div>
                    </div>
                </div>

            </div>

            <div class="page-section bg-alt border-bottom-2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 mb-24pt mb-md-0">
                         
                            <div class="page-separator">
                                <div class="page-separator__text bg-white"><h4>About the author</h4></div>
                            </div>
                            <p class="text-70 mb-24pt"><?php echo $fetch_supervisor['about']; ?></p>

                        
                        </div>
                        <div class="col-md-5 pt-sm-32pt pt-md-0 d-flex flex-column align-items-center justify-content-start">
                            <div class="text-center">
                                <p class="mb-16pt">
                                    <img src="assets/images/users/<?php echo $fetch_supervisor['profile']; ?>" alt="guy-6" class="rounded-circle" width="64">
                                </p>
                                <h4 class="m-0"><?php echo $fetch_supervisor['user_name']; ?></h4>
                                <p class="lh-1">
                                    <small class="text-muted"><?php echo $fetch_giz_project['business_modal']; ?></small>
                                </p>
                                <div class="d-flex flex-column flex-sm-row align-items-center justify-content-start">
                                    <!-- <a href="fixed-teacher-profile.html" class="btn btn-outline-primary mb-16pt mb-sm-0 mr-sm-16pt">Follow</a>
                                    <a href="fixed-teacher-profile.html" class="btn btn-outline-secondary">View Profile</a> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>





        </div>
       <!-- // END Header Layout Content -->




   <?php

   include("footer.php");
   
   ?>


    </div>
    <!-- // END Header Layout -->
    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>




</body>

</html>