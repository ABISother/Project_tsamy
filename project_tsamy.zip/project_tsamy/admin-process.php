<?php
session_start();
?>
<?php
//process.php
// if(!isset($_SESSION["DA_user"])){
// echo("<script>location.href='login.html';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
// echo '<label color="red">You are not Authorized</label>';
// }
// else{

//     include('connection.php'); 
// $account_key=$_SESSION["DA_user"];
// $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
// $fetch_account=$sel_account->fetch_assoc();
// $names=$fetch_account['username'];
// $myemail=$fetch_account['email'];



// if($_SESSION["access"]=='Manager'){
//     echo("<script>location.href='Manager-index.php';</script>"); 
// }

// if($fetch_account['first_login']==0){
//  echo("<script>location.href='setting.php';</script>");
// }

// }

require_once('connection.php');

$todayyear=date("Y");

 if(isset($_POST['login_mail'])){
    //Login Session 
    $login_mail=$_POST['login_mail'];
    $login_password=$_POST['login_password'];

    $username = $login_mail;
     $pass = md5($login_password);

    $query="select * from  users  where password='".$pass."' and user_name='".$username."' or password='".$pass."' and email='".$username."' ";
    $result=mysqli_query($con,$query);
    if(mysqli_fetch_assoc($result))
    {
$view_p=$con->query("SELECT * from users where  password='$pass' and user_name='$username' or password='$pass' and email='$username'")or die("Connection failed: " . $con->connect_error);
      $view=$view_p->fetch_assoc();
      //$id=$view['store_No'];
      $last_seen=time();
      $_SESSION["giz_supervisor"] = $view['id'];
      //$_SESSION["access"] = $view['account_type'];
      $_SESSION["last_seen"] = $last_seen;

      $query=$con->query("UPDATE users SET status='online',last_login='$last_seen' WHERE id ='".$view['id']."' ")or die($con->error);
      
      echo("<script>location.href='admin-dashboard.php?load&user=".$view['user_name']."';</script>");

    echo '<div class="alert alert-soft-info">
    <div class="d-flex flex-wrap">
        <div class="mr-8pt">
            <i class="material-icons">check_circle</i>
        </div>
        <div class="flex" style="min-width: 180px">
            <small class="text-black-100">
                '.$login_mail.' Logged in a system.
            </small>
        </div>
    </div>
</div>';


              }else{
               
            echo'<div class="alert alert-soft-accent alert-dismissible fade show" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
<div class="d-flex flex-wrap align-items-start">
    <div class="mr-8pt">
        <i class="material-icons">access_time</i>
    </div>
    <div class="flex" style="min-width: 180px">
        <small class="text-black-100">
            <strong>Try Again - </strong> Invalid User name/email OR Password.!
        </small>
    </div>
</div>
</div>';

              }     }else if(isset($_POST['pname'])){
                
                if(!isset($_SESSION["giz_supervisor"])){
                    echo '<div class="alert alert-soft-danger">
                    <div class="d-flex flex-wrap">
                        <div class="mr-8pt">
                            <i class="material-icons">user</i>
                        </div>
                        <div class="flex" style="min-width: 180px">
                            <small class="text-black-100">
                            <label style="color:red;"> Your session has ended <a href="admin-login.php">First Login again</a> or <a href="start.php">register</a> to the system to perfom this action</label>
                            </small>
                        </div>
                    </div>
                </div>';
                   // echo("<script>location.href='start.php';</script>");
                  
                    }else{
                        $account_key=$_SESSION["giz_supervisor"];
                        $P_tittle=$_POST['pname'];
                        $P_tittle=str_replace("'", "\'", $P_tittle);
                        $p_category=$_POST['p_category'];
                        $p_category=str_replace("'", "\'",$p_category);
                        $partnername=$_POST['partnername'];
                        $partnername=str_replace("'", "\'",$partnername);
            
                        $description=$_POST['description'];
                        $description=str_replace("'", "\'",$description);
                   
                        //$userfile=$_POST['file'];
                        $duedate=$_POST['d_date'];
                        $userrequestedday=strtotime($duedate);
                        // echo 'Previous Time: '.$duedate.' | New timeprep:'. $userrequestedday.' New Time ';
                        if(isset($_POST['file'])){
                        $icon=$_POST['file'];
                        }else{
                            $icon='default.png  ';
                        }
                        //print date("M d,Y - h:m A",$userrequestedday);
                        $companyname=$_POST['companyname'];
                        $companyname=str_replace("'", "\'",$companyname);
                        $budget=$_POST['budget'];
                        // $Gbday=$bday."-".$bMonth."-".$byear;
                        $now=time();

                        $sel_departments=$con->query("SELECT*from departments where id='$p_category' ")or die($con->error);
                        $count_departments=$sel_departments->num_rows;
                        $fetch_departments=$sel_departments->fetch_assoc();
            
                        $supervisor=$fetch_departments['manager'];
            
                        $bsns_modal=$fetch_departments['category_name'];
            
            

                        if(!isset($alert)){ 
                            $savequery=$con->query("INSERT INTO projects(p_tittle,p_icon,description,due,status,p_owner,p_supervisor,created_on,by_customer,by_supervisor,business_modal,category,company_name,budget) VALUES ('$P_tittle','$icon',' $description','$userrequestedday','Valid','$account_key','$account_key','$now','0','1','$bsns_modal','$p_category','$companyname','$budget')")or die($con->error);
                            if ($savequery) {
                                $approvo="Project Saved!<br> ";

                                $last=$con->query("SELECT * FROM projects WHERE id=(SELECT max(id) FROM projects) ")or die($con->error);
                                $fetch_last=$last->fetch_assoc();
                                $last_id=$fetch_last['id'];
                                
                                echo '<div class="alert alert-soft-success">
                                <div class="d-flex flex-wrap">
                                    <div class="mr-8pt">
                                        <i class="material-icons">check</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                        <label style="color:Blue;">Success <br />Your Project has been submited <a href="project_view.php?view='.$last_id.'"><u>Go to Review the Application</u></a>!</label>
                                        </small>
                                        <script>$("#project_form")[0].reset();</script>                                  
                                    </div>
                                </div>
                            </div>';
                            //     echo '<label style="color:green;">Success<br />Your '.$userid.' user account is activated</label>';
                            }
                        }
                    }
              }
              
            
            
            ?>