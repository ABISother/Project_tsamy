<?php if(isset($page)&&($page!='msg')){ ?>
<div class="js-fix-footer2 bg-white border-top-2">
    <div class="container page__container page-section d-flex flex-column">
        <p class="text-70 brand mb-24pt">
            <img class="brand-icon" src="assets/images/logo/logo.png" width="30" alt="giz Rwanda">  Rwanda
        </p>
        <p class="measure-lead-max text-50 small mr-8pt">We use our wide range of instruments and networks flexibly and innovatively to create value for our commissioning parties and to empower people to shape their own development processes.</p>
        <p class="mb-8pt d-flex">
            <a href="#" class="text-70 text-underline mr-8pt small">Terms</a>
            <a href="#" class="text-70 text-underline small">Privacy policy</a>
        </p>
        <p class="text-50 small mt-n1 mb-0">Copyright <?php echo date("Y"); ?> &copy; All rights reserved.</p>
    </div>
</div>


        </div>
        <?php } ?>
        <!-- // END drawer-layout__content -->




        <!-- drawer -->
        <div class="mdk-drawer js-mdk-drawer layout-compact__drawer" id="default-drawer">
            <div class="mdk-drawer__content js-sidebar-mini" data-responsive-width="992px" data-layout="compact">

                <div class="sidebar sidebar-mini sidebar-dark-dodger-blue sidebar-left d-flex flex-column">

                    <!-- Brand -->
                    <a href="" class="sidebar-brand p-0 navbar-height d-flex justify-content-center">

                        <span class="avatar avatar-sm ">

                            <span class="avatar-title rounded bg-primary"><img src="assets/images/logo/logo.png" class="img-fluid" alt="logo" /></span>

                        </span>

                    </a>

                    <div class="flex d-flex flex-column justify-content-start" data-perfect-scrollbar>
                        <ul class="nav flex-shrink-0 flex-nowrap flex-column sidebar-menu mb-0 sm-item-bordered js-sidebar-mini-tabs" role="tablist">
                  
                            <li class="sidebar-menu-item <?php if(isset($page)&&($page=='dashboard')){echo 'active';} ?>" data-title="Instructor" data-placement="right" data-container="body" data-boundary="window">
                                <a class="sidebar-menu-button" href="admin-dashboard.php"  aria-selected="true">
                                    <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">dashboard</i>
                                    <span class="sidebar-menu-text">Dashboard</span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item  <?php if(isset($page)&&($page=='profile')){echo 'active';} ?>" data-title="Apps" data-placement="right" data-container="body" data-boundary="window">
                                <a class="sidebar-menu-button" href="profile.php" >
                                    <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i>
                                    <span class="sidebar-menu-text">Profile</span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item  <?php if(isset($page)&&($page=='apps')){echo 'active';} ?>" data-title="Apps" data-placement="right" data-container="body" data-boundary="window">
                                <a class="sidebar-menu-button" href="apps.php" >
                                    <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">apps</i>
                                    <span class="sidebar-menu-text">Apps</span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item  <?php if(isset($page)&&($page=='projects')){echo 'active';} ?>" data-title="projects" data-placement="right" data-container="body" data-boundary="window">
                                <a class="sidebar-menu-button" href="giz-projects.php" >
                                    <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">tune</i>
                                    <span class="sidebar-menu-text">Projects</span>
                                </a>
                            </li>
                            <!-- <li class="sidebar-menu-item " data-title="Account" data-placement="right" data-container="body" data-boundary="window">
                                <a class="sidebar-menu-button" href="#sm_account" data-toggle="tab" role="tab" aria-controls="sm_account">
                                    <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i>
                                    <span class="sidebar-menu-text">Account</span>
                                </a>
                            </li> -->
                            <?php if(isset($itsadmin)&&($itsadmin==1)){ ?>
                            <li class="sidebar-menu-item  <?php if(isset($page)&&($page=='partner')){echo 'active';} ?>" data-title="projects" data-placement="right" data-container="body" data-boundary="window">
                                <a class="sidebar-menu-button" href="partners.php" >
                                    <!-- <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">trending_upune</i> -->
                                    <span class="avatar-title rounded navbar-avatar"><i class="material-icons">trending_up</i></span>
                                    <span class="sidebar-menu-text">Reports</span>
                                </a>
                            </li>
                            <?php } ?>
                            <li class="sidebar-menu-item " data-title="Messaging" data-placement="right" data-container="body" data-boundary="window">
                                <a class="sidebar-menu-button" href="ad-message.php" >
                                    <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">message</i>
                                    <span class="sidebar-menu-text">Messaging</span>
                                </a>
                            </li>
                      
                           
                        </ul>
                    </div>


                    <ul class="nav flex-column sidebar-menu align-items-center mb-12pt js-sidebar-mini-tabs" role="tablist">
                        <li class="sidebar-account" style="width: 40px;">
                            <a href="#sm_account_1" class="p-4pt d-flex align-items-center justify-content-center" data-toggle="tab" role="tab" aria-controls="sm_account_1" aria-selected="true">
                                <img width="32" height="32" class="rounded-circle" src="assets/images/users/<?php echo $fetch_account['profile']; ?>" alt="account" />
                            </a>
                        </li>
                    </ul>

                </div>

                <div class="sidebar sidebar-light sidebar-left flex sidebar-secondary pt-16pt" data-perfect-scrollbar>




                    <div class="tab-content">

                        <div class="tab-pane" id="sm_account_1">
                            <div class="sidebar-heading">Account</div>
                            <ul class="sidebar-menu">
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button" href="#">
                                        <span class="sidebar-menu-text">Edit Account</span>
                                    </a>
                                </li>
                            
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button" href="admin-logout.php">Logout</a>
                                </li>
                            </ul>
                        </div>

                       
            

                        <div class="tab-pane " id="sm_messaging">
                            <div class="sidebar-heading">Messaging</div>
                            <ul class="sidebar-menu">
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button" href="ad-message.php">
                                        <span class="sidebar-menu-text">Messages</span>
                                    </a>
                                </li>
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button" href="compact-email.html">
                                        <span class="sidebar-menu-text">Email</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-pane" id="sm_components">
                            <div class="sidebar-heading">UI Components</div>
                            <ul class="sidebar-menu">
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button" data-toggle="collapse" href="#components_menu">
                                        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">tune</span>
                                        Components
                                        <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                    </a>
                                    <ul class="sidebar-submenu collapse sm-indent" id="components_menu">
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-buttons.html">
                                                <span class="sidebar-menu-text">Buttons</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-avatars.html">
                                                <span class="sidebar-menu-text">Avatars</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-forms.html">
                                                <span class="sidebar-menu-text">Forms</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-loaders.html">
                                                <span class="sidebar-menu-text">Loaders</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-tables.html">
                                                <span class="sidebar-menu-text">Tables</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-cards.html">
                                                <span class="sidebar-menu-text">Cards</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-icons.html">
                                                <span class="sidebar-menu-text">Icons</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-tabs.html">
                                                <span class="sidebar-menu-text">Tabs</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-alerts.html">
                                                <span class="sidebar-menu-text">Alerts</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-badges.html">
                                                <span class="sidebar-menu-text">Badges</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-progress.html">
                                                <span class="sidebar-menu-text">Progress</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-pagination.html">
                                                <span class="sidebar-menu-text">Pagination</span>
                                            </a>
                                        </li>
                                        <!-- <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button disabled" href="compact-ui-typography.html">
                                                    <span class="sidebar-menu-text">Typography</span>
                                                </a>
                                                </li>
                                                <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button disabled" href="compact-ui-colors.html">
                                                    <span class="sidebar-menu-text">Colors</span>
                                                </a>
                                                </li>
                                                <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button disabled" href="compact-ui-breadcrumb.html">
                                                    <span class="sidebar-menu-text">Breadcrumb</span>
                                                </a>
                                                </li>
                                                <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button disabled" href="compact-ui-accordions.html">
                                                    <span class="sidebar-menu-text">Accordions</span>
                                                </a>
                                                </li>
                                                <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button disabled" href="compact-ui-modals.html">
                                                    <span class="sidebar-menu-text">Modals</span>
                                                </a>
                                                </li>
                                                <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button disabled" href="compact-ui-chips.html">
                                                    <span class="sidebar-menu-text">Chips</span>
                                                </a>
                                                </li> -->
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button disabled" href="#">
                                                <span class="sidebar-menu-text">Disabled</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button" data-toggle="collapse" href="#plugins_menu">
                                        <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">folder</span>
                                        Plugins
                                        <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                    </a>
                                    <ul class="sidebar-submenu collapse sm-indent" id="plugins_menu">
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-charts.html">
                                                <span class="sidebar-menu-text">Charts</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-flatpickr.html">
                                                <span class="sidebar-menu-text">Flatpickr</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-daterangepicker.html">
                                                <span class="sidebar-menu-text">Date Range Picker</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-dragula.html">
                                                <span class="sidebar-menu-text">Dragula</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-dropzone.html">
                                                <span class="sidebar-menu-text">Dropzone</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-range-sliders.html">
                                                <span class="sidebar-menu-text">Range Sliders</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-quill.html">
                                                <span class="sidebar-menu-text">Quill</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-select2.html">
                                                <span class="sidebar-menu-text">Select2</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-nestable.html">
                                                <span class="sidebar-menu-text">Nestable</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-fancytree.html">
                                                <span class="sidebar-menu-text">Fancy Tree</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-maps-vector.html">
                                                <span class="sidebar-menu-text">Vector Maps</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-sweet-alert.html">
                                                <span class="sidebar-menu-text">Sweet Alert</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button" href="compact-ui-plugin-toastr.html">
                                                <span class="sidebar-menu-text">Toastr</span>
                                            </a>
                                        </li>
                                        <li class="sidebar-menu-item">
                                            <a class="sidebar-menu-button disabled" href="#">
                                                <span class="sidebar-menu-text">Disabled</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                  
                    </div>
                </div>

            </div>
        </div>
        <!-- // END drawer -->


    </div>
    <!-- // END drawer-layout -->