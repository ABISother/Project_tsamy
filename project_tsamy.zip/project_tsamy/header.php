
<!-- Header -->
<?php 
require_once('connection.php');
         $sel_all_project=$con->query("SELECT*from projects where by_supervisor='1' and status!='Expired' and deleted='0' ")or die($con->error);
         $count_all_project=$sel_all_project->num_rows;

         $sel_all_departments=$con->query("SELECT*from departments  ")or die($con->error);
         $count_all_departments=$sel_all_departments->num_rows;

         
         
if(isset($active)&&$active=='index'){


?>

        <div class="navbar navbar-expand navbar-dark-dodger-blue bg-transparent will-fade-background" id="default-navbar" data-primary>

            <!-- Navbar toggler -->
            <button class="navbar-toggler w-auto mr-16pt d-block rounded-0" type="button" data-toggle="sidebar">
                <span class="material-icons">short_text</span>
            </button>

            <!-- Navbar Brand -->
            <a href="index.php" class="navbar-brand mr-16pt">
                <!-- <img class="navbar-brand-icon" src="assets/images/logo/white-100@2x.png" width="30" alt="Luma"> -->

                <span class="avatar avatar-sm navbar-brand-icon mr-0 mr-lg-8pt">

                    <span class="avatar-title rounded"><img src="assets/images/logo/logo.png" alt="logo" class="img-fluid" /></span>

                </span>

                 <span class="d-none d-lg-block">.</span>
            </a>

            <ul class="nav navbar-nav d-none d-sm-flex flex justify-content-start ml-8pt">
                <li class="nav-item active">
                    <a href="index.php" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
        <a href="apply.php" class="nav-link">Giz Projects</a>
    </li>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" data-caret="false">Teachers</a>
                   
                </li>
                <li class="nav-item dropdown" data-toggle="tooltip" data-title="Community" data-placement="bottom" data-boundary="window">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" data-caret="false">
                        <i class="material-icons">people_outline</i>
                    </a>
                   
                </li>
            </ul>



            <ul class="nav navbar-nav ml-auto mr-0">
                <li class="nav-item">
                    <a href="login.php" class="nav-link" data-toggle="tooltip" data-title="Login" data-placement="bottom" data-boundary="window"><i class="material-icons">lock_open</i>Login</a>
                </li>
                <li class="nav-item">
                    <a href="start.php" class="btn btn-outline-white">Get Started</a>
                </li>
            </ul>
        </div>

        <?php }else{ ?>
            <div class="navbar navbar-expand navbar-dark-dodger-blue navbar-shadow" id="default-navbar" data-primary>

<!-- Navbar toggler -->
<button class="navbar-toggler w-auto mr-16pt d-block rounded-0" type="button" data-toggle="sidebar">
    <span class="material-icons">short_text</span>
</button>

<!-- Navbar Brand -->
<a href="index.php" class="navbar-brand mr-16pt">
                <!-- <img class="navbar-brand-icon" src="assets/images/logo/white-100@2x.png" width="30" alt="Luma"> -->

                <span class="avatar avatar-sm navbar-brand-icon mr-0 mr-lg-8pt">

                    <span class="avatar-title rounded"><img src="assets/images/logo/logo.png" alt="logo" class="img-fluid" /></span>
                </span>
                 <span class="d-none d-lg-block">.</span>
            </a>

<ul class="nav navbar-nav d-none d-sm-flex flex justify-content-start ml-8pt">
    <li class="nav-item">
        <a href="index.php" class="nav-link">Home</a>
    </li>
    <!-- <li class="nav-item dropdown">
        <a href="index.php" class="nav-link dropdown-toggle" data-toggle="dropdown" data-caret="false">Courses</a>
         <div class="dropdown-menu">
            <a href="fixed-courses.html" class="dropdown-item">Browse Courses</a>
            <a href="fixed-student-course.html" class="dropdown-item">Preview Course</a>
            <a href="fixed-student-lesson.html" class="dropdown-item">Preview Lesson</a>
            <a href="fixed-student-take-course.html" class="dropdown-item"><span class="mr-16pt">Take Course</span> <span class="badge badge-notifications badge-accent text-uppercase ml-auto">Pro</span></a>
            <a href="fixed-student-take-lesson.html" class="dropdown-item">Take Lesson</a>
            <a href="fixed-student-take-quiz.html" class="dropdown-item">Take Quiz</a>
            <a href="fixed-student-quiz-result-details.html" class="dropdown-item">Quiz Result</a>
            <a href="fixed-student-dashboard.html" class="dropdown-item">Student Dashboard</a>
            <a href="fixed-student-my-courses.html" class="dropdown-item">My Courses</a>
            <a href="fixed-student-quiz-results.html" class="dropdown-item">My Quizzes</a>
            <a href="fixed-help-center.html" class="dropdown-item">Help Center</a>
        </div> 
    </li> -->
    <li class="nav-item">
        <a href="apply.php" class="nav-link">Giz Projects</a>
    </li>
    
    <?php if(isset($_SESSION["giz_customer"])){?>
        <li class="nav-item">
        <a href="user_dashboard.php" class="nav-link">Dashboard</a>
    </li>
    <li class="nav-item">
        <a href="user_profile.php" class="nav-link">Profile</a>
    </li>
   
    <li class="nav-item dropdown" data-toggle="tooltip" data-title="My Account" data-placement="bottom" data-boundary="window">
        <a href="user_dashboard.php" class="nav-link dropdown-toggle" data-toggle="dropdown" data-caret="false">
           <?php echo  $names  ?> <i class="material-icons">person_outline</i>
        </a>
        <div class="dropdown-menu">
            <a href="user_dashboard.php" class="dropdown-item">Dashboard</a>
            <a href="user_profile.php" class="dropdown-item">My Profile</a>
            <a href="user_dashboard.php" data-target="editp" class="dropdown-item">My projects</a>
             
           
        </div>
    </li>
    <?php } ?>
</ul>






<?php if(!isset($_SESSION["giz_customer"])){?>

<ul class="nav navbar-nav ml-auto mr-0">
    <li class="nav-item">
        <a href="login.php" class="nav-link" data-toggle="tooltip" data-title="Login" data-placement="bottom" data-boundary="window"><i class="material-icons">lock_open</i>Login</a>
    </li>
    <li class="nav-item active">
        <a href="start.php" class="btn btn-outline-white">Get Started</a>
    </li>
</ul>
<?php }else if(isset($_SESSION["giz_customer"])){?>
    <div class="nav navbar-nav flex-nowrap d-flex mr-16pt">


<!-- Notifications dropdown -->
<div class="nav-item dropdown dropdown-notifications dropdown-xs-down-full" data-toggle="tooltip" data-title="Messages" data-placement="bottom" data-boundary="window">
  <a href="messages.php" class="nav-link btn-flush dropdown-toggle" type="button" >
        <i class="material-icons icon-24pt">mail_outline</i>
    </a>
    <div class="dropdown-menu dropdown-menu-right">
        <div data-perfect-scrollbar class="position-relative">
            <div class="dropdown-header"><strong>Messages</strong></div>
    
        </div>
    </div>
</div>
<!-- // END Notifications dropdown -->





<div class="nav-item dropdown">
    <a href="#" class="nav-link d-flex align-items-center dropdown-toggle" data-toggle="dropdown" data-caret="false">

        <span class="avatar avatar-sm mr-8pt2">

            <span class="avatar-title rounded-circle bg-primary"><i class="material-icons">account_box</i></span>

        </span>

    </a>
    <div class="dropdown-menu dropdown-menu-right">
        <div class="dropdown-header"><strong><?php echo  $names  ?></strong></div>
        <a class="dropdown-item" href="start.php?edit=<?php echo $account_key; ?>&folsedback">Edit Account</a>
        <a class="dropdown-item" href="user_profile.php">Profile</a>
        <!-- <a class="dropdown-item" href="fixed-billing-history.html">Payments</a> -->
        <a class="dropdown-item" href="logout.php">Logout</a>
    </div>
</div>
</div>
<?php } ?>
</div>
      <?php  } ?>