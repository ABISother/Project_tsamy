<?php
session_start();
?>
<?php
  include('connection.php'); 
 if(!isset($_SESSION["giz_customer"])){
//     echo("<script>location.href='login.php?alert=login first!';</script>");
// echo '<label color="red">You are not Authorized</label>';
// This is Home No Need!!
 }
 else{
   include('connection.php'); 
 $account_key=$_SESSION["giz_customer"];
 $sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['username'];
 $myemail=$fetch_account['email'];

 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="icon" href="assets/images/logo/logo.png" sizes="32x32" />
<link rel="icon" href="assets/images//logo/logo.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="assets/images/logo/logo.png" />
<meta name="msapplication-TileImage" content="assets/images/logo/logo.png" />
    <title>giz Kigali</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <!---<link type="text/css" href="assets/css/preloader.css" rel="stylesheet">--->


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">






</head>





<body class="layout-sticky-subnav layout-default ">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">
    <div id="header" class="mdk-header mdk-header--bg-dark bg-dark js-mdk-header mb-0" data-effects="parallax-background waterfall" data-fixed data-condenses>
            <div class="mdk-header__bg">
                <div class="mdk-header__bg-front" style="background-image: url(assets/images/new_imgs/gizIMAGE1.JPG);"></div>
            </div>
            <div class="mdk-header__content justify-content-center">
                    <?php

                include("header.php");

                ?>

                <div class="hero container page__container text-center text-md-left py-112pt">
                 
                    <h1 class="text-white text-shadow">giz Rwanda</h1>
                    <p class="lead measure-hero-lead mx-auto mx-md-0 text-white text-shadow mb-48pt">Tailor-made, cost efficient and effective services analytic and management system</p>


                    <a href="apply.php" class="btn btn-lg btn-white btn--raised mb-16pt">Browse Programs</a>


                    <p class="mb-0"><a href="apply.php#My_request" class="text-white text-shadow"><strong>Do you have an Idea?</strong></a></p>

                </div>
            </div>
        </div>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content page-content ">



            





        </div>
   <!-- // END Header Layout Content -->


   <?php

   include("footer.php");
   
   ?>


    </div>
    <!-- // END Header Layout -->





    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>



    <script>
        (function() {
            'use strict';
            var headerNode = document.querySelector('.mdk-header')
            var layoutNode = document.querySelector('.mdk-header-layout')
            var componentNode = layoutNode ? layoutNode : headerNode

            componentNode.addEventListener('domfactory-component-upgraded', function() {
                headerNode.mdkHeader.eventTarget.addEventListener('scroll', function() {
                    var progress = headerNode.mdkHeader.getScrollState().progress
                    var navbarNode = headerNode.querySelector('#default-navbar')
                    navbarNode.classList.toggle('bg-transparent', progress <= 0.2)
                })
            })
        })()
    </script>

</body>

</html>