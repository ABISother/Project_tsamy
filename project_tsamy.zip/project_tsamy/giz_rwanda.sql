-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2022 at 09:08 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `giz_rwanda`
--

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `time_created` varchar(60) NOT NULL,
  `for_all` tinyint(1) NOT NULL,
  `for_admin` tinyint(1) NOT NULL,
  `for_user` tinyint(1) NOT NULL,
  `tittle` varchar(100) NOT NULL,
  `viewed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`id`, `owner`, `time_created`, `for_all`, `for_admin`, `for_user`, `tittle`, `viewed`) VALUES
(1, 1, '1668154290', 1, 1, 1, 'A New User (.ABI.) has been Added to the system', 0),
(2, 1, '1668155690', 1, 1, 1, 'A New User (.patrick.) has been Added to the system', 0);

-- --------------------------------------------------------

--
-- Table structure for table `applys`
--

CREATE TABLE `applys` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `supervisor_id` int(11) NOT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'Submited',
  `projectname` varchar(90) NOT NULL,
  `customer_comment` varchar(300) NOT NULL,
  `user_comment` varchar(600) NOT NULL,
  `progress` int(11) NOT NULL DEFAULT 5,
  `applied_on` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applys`
--

INSERT INTO `applys` (`id`, `user_id`, `project_id`, `supervisor_id`, `status`, `projectname`, `customer_comment`, `user_comment`, `progress`, `applied_on`) VALUES
(1, 12, 1, 2, 'Submited', 'Electronic Aqualium', 'I am applyng to this Project!', 'We will look into your Application very Soon', 5, '1668181112'),
(3, 2, 1, 2, 'Pending', 'Electronic Aqualium', 'I am applyng to this Project!', 'We will look into your Application very Soon', 45, '1668509499'),
(4, 2, 3, 2, 'Pending', 'Umushinga Wubwubatsi', 'I am applyng to this Project!', 'We will look into your Application very Soon', 45, '1668511276');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `username` varchar(60) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `address` varchar(70) NOT NULL,
  `password` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'offline',
  `last_seen` varchar(60) NOT NULL,
  `joined` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `fname`, `lname`, `email`, `username`, `phone`, `address`, `password`, `status`, `last_seen`, `joined`) VALUES
(1, 'Delphine', ' Fina', 'tsammy@gmail.com', 'Tsamy', '2343242354', 'KN 2 Ave', '202cb962ac59075b964b07152d234b70', 'Online', '1665916119', '1662632419'),
(2, 'SOTHER', ' SOTHER', 'abirihosother@gmail.com', 'ABI', '1231231243', 'KN 2 Ave', '202cb962ac59075b964b07152d234b70', 'Online', '1668779025', '1662632701'),
(3, 'Beninka', ' Gishushu', 'Beninka@gmail.com', 'Beni', '0785318962', 'NYARUGENGE', '202cb962ac59075b964b07152d234b70', 'Online', '1668504137', '1662657282'),
(4, 'Beninka', ' Gishushu', 'Beninka@gmail.com', 'Beninka', '0785318961', 'NYARUGENGE', '202cb962ac59075b964b07152d234b70', '', '', '1662657345'),
(5, 'Beninka', ' Gishushu', 'Beninka@gmail.com', 'Benink', '0785318963', 'NYARUGENGE', '202cb962ac59075b964b07152d234b70', '', '', '1662657410'),
(6, 'Beninka', ' Gishushu', 'Beninka@gmail.com', 'Benin', '0785318960', 'NYARUGENGE', '202cb962ac59075b964b07152d234b70', '', '', '1662657600'),
(7, 'SOTHER', ' SOTHER', 'abirihosother@gmail.com', 'tsammy', '0784624822', 'KN 2 Ave', '202cb962ac59075b964b07152d234b70', '', '', '1662762295'),
(8, 'mutoni', ' tsamy', 'tsamy@gmail.com', 'sera', '056788999', 'KIGALI', '202cb962ac59075b964b07152d234b70', '', '', '1664193639'),
(9, 'Kanakuze', ' Dativa', 'Dativa@gmail.com', 'Dativa', '0785318964', 'kicukiro', '202cb962ac59075b964b07152d234b70', '', '', '1666006774'),
(10, 'UMWALI', ' Ange', 'ange@gmail.com', 'ANGE', '0786193917', 'KICUKIRO', 'e7880f4be5b280cb33e4148d01e10192', 'Online', '1667473567', '1667472288'),
(11, 'umutoni', ' Delphine', 'akili@gmail.com', 'umutoni', '0782344243', 'kicukiro', 'e7275ea359800d4a8fb35c25227eeca3', 'offline', '', '1668179477'),
(12, 'maniriho', ' theophile', 'theo@gmail.com', 'umutoni', '0785318912', 'Kicukiro', '202cb962ac59075b964b07152d234b70', 'Online', '1668928028', '1668180151');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `category_name` varchar(60) NOT NULL,
  `manager` int(11) NOT NULL,
  `initial_date` varchar(60) NOT NULL DEFAULT '1662632701',
  `project_count` int(11) NOT NULL,
  `partners` varchar(60) NOT NULL DEFAULT 'Rwanda Goverment'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `category_name`, `manager`, `initial_date`, `project_count`, `partners`) VALUES
(1, 'Agriculture', 1, '1662632701', 1, 'Rwanda Goverment'),
(2, 'construction', 2, '1662632701', 0, 'Rwanda Goverment'),
(3, ' Technology (Software Development)', 3, '1662632701', 1, 'Rwanda Goverment');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `msg_super` int(11) NOT NULL,
  `msg_user` int(11) NOT NULL,
  `msg_side` varchar(50) NOT NULL DEFAULT 'User',
  `msg_date` varchar(60) NOT NULL,
  `msg_read` tinyint(1) NOT NULL,
  `msg` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `msg_super`, `msg_user`, `msg_side`, `msg_date`, `msg_read`, `msg`) VALUES
(1, 1, 12, 'User', '1668180571', 0, 'Turifuza Gukora umushinga Wo kubangurira Ibiti by\'indimu'),
(2, 2, 12, 'User', '1668181112', 0, 'I Have just applied on project Tittled Electronic Aqualium <br> Kindly check my Submittion!'),
(3, 1, 12, 'User', '1668181439', 0, 'Please revise my case!'),
(4, 1, 12, 'Admin', '1668503675', 0, 'Gusubiza'),
(5, 2, 2, 'User', '1668509328', 0, 'I Have just applied on project Tittled Electronic Aqualium <br> Kindly check my Submittion!'),
(6, 2, 2, 'User', '1668509499', 0, 'I Have just applied on project Tittled Electronic Aqualium <br> Kindly check my Submittion!'),
(7, 3, 2, 'User', '1668510967', 0, 'Uyu mushinga Kwari Ukugira ngo nkore Test KURI project'),
(8, 2, 2, 'User', '1668511276', 0, 'I Have just applied on project Tittled Umushinga Wubwubatsi <br> Kindly check my Submittion!'),
(9, 3, 2, 'User', '1668514302', 0, 'I Have just applied on project Tittled Umushinga Mushyashya wa Abi <br> Kindly check my Submittion!'),
(10, 3, 2, 'User', '1668515821', 0, 'hELLO HELLO NDSHAKA KUNKWA NA tSAMY'),
(11, 1, 12, 'Admin', '', 0, 'A status for your Project tittled:  has been changed Successfuly!'),
(12, 2, 2, 'Admin', '1668778024', 0, 'There was a change to your application Project tittled:Electronic Aqualium  has been changed Successfuly!'),
(13, 2, 2, 'Admin', '1668778112', 0, 'There was a change to your application Project tittled:Electronic Aqualium  has been changed Successfuly!'),
(14, 2, 2, 'Admin', '1668778888', 0, 'There was a change to your application Project tittled:Electronic Aqualium  has been changed Successfuly!'),
(15, 2, 2, 'Admin', '1668778974', 0, 'There was a change to your application Project tittled:Electronic Aqualium  has been changed Successfuly!'),
(16, 1, 12, 'Admin', '1668781180', 0, 'uZI UBWENGE'),
(17, 1, 12, 'Admin', '1668928763', 0, 'A status for your Project tittled:tsami farmer  has been changed Successfuly!'),
(18, 2, 2, 'Admin', '1668931393', 0, 'There was a change to your application Project tittled:Electronic Aqualium  has been changed Successfuly!'),
(19, 2, 2, 'Admin', '1668931628', 0, 'Message After changes:<br>You should Now Visit Our Office! <br>Status now :Pending');

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` int(11) NOT NULL,
  `category` varchar(60) NOT NULL DEFAULT 'Organization',
  `p_names` varchar(60) NOT NULL,
  `project_id` int(11) NOT NULL,
  `about` varchar(3000) NOT NULL,
  `amount` int(11) NOT NULL,
  `date_of_contribution` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `category`, `p_names`, `project_id`, `about`, `amount`, `date_of_contribution`) VALUES
(1, 'Organization', 'Rwanda Goverment', 1, 'We are here to help any profitable project!', 12000000, '18932823432');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `p_tittle` varchar(100) NOT NULL,
  `p_icon` varchar(60) NOT NULL DEFAULT 'logo.png',
  `description` varchar(300) NOT NULL,
  `due` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL,
  `p_owner` int(11) NOT NULL,
  `p_supervisor` int(11) NOT NULL,
  `created_on` varchar(60) NOT NULL,
  `by_customer` tinyint(1) NOT NULL,
  `by_supervisor` tinyint(1) NOT NULL,
  `business_modal` varchar(60) NOT NULL,
  `category` int(11) NOT NULL DEFAULT 1,
  `company_name` varchar(60) NOT NULL DEFAULT 'Unknown',
  `budget` varchar(60) NOT NULL DEFAULT '0',
  `progress` varchar(60) NOT NULL DEFAULT '5'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `p_tittle`, `p_icon`, `description`, `due`, `status`, `p_owner`, `p_supervisor`, `created_on`, `by_customer`, `by_supervisor`, `business_modal`, `category`, `company_name`, `budget`, `progress`) VALUES
(1, 'Electronic Aqualium', 'default.png  ', ' Hello', '1669935600', 'Valid', 2, 2, '1668030860', 0, 1, 'construction', 2, 'giz Rwanda', '733', '5'),
(2, 'tsami farmer', 'logo.png', 'Turifuza Gukora umushinga Wo kubangurira Ibiti by\'indimu', '1669158000', 'Approved', 12, 1, '1668180571', 1, 0, 'Agriculture', 1, 'UBWIZA', '1000000', '5'),
(3, 'Umushinga Wubwubatsi', 'default.png  ', ' Kuruyu mushinga Giz Rwanda Turifuza Company ifite ubushobozi bwo kubaka bigezweho', '1669244400', 'Valid', 2, 2, '1668505677', 0, 1, 'construction', 2, 'giz Rwanda', '7000000', '5'),
(5, 'Umushinga Mushyashya wa Abi', 'logo.png', 'hELLO HELLO NDSHAKA KUNKWA NA tSAMY', '1669244400', 'Submited', 2, 3, '1668515821', 1, 0, ' Technology (Software Development)', 3, 'abi', '23456789', '5');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `Join_date` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `profile` varchar(60) NOT NULL DEFAULT 'img_avatar.png',
  `contacts` varchar(13) NOT NULL,
  `country` varchar(60) NOT NULL DEFAULT 'Rwanda',
  `status` varchar(60) NOT NULL DEFAULT 'offline',
  `first_login` varchar(60) NOT NULL,
  `account_type` varchar(60) NOT NULL,
  `last_login` varchar(60) NOT NULL,
  `about` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `user_name`, `Join_date`, `email`, `password`, `profile`, `contacts`, `country`, `status`, `first_login`, `account_type`, `last_login`, `about`) VALUES
(1, 'Mutoni', 'Delphine', 'mutoni', '1649272407', 'mutonid@gmail.com', '202cb962ac59075b964b07152d234b70', 'img_avatar.png', '250786910737', 'Rwanda', 'Offline', '1', 'Admin', '1668928732', 'This is about My self'),
(2, 'Amida', 'NIKUZE', 'AMIDA', '1649272407', 'amida@giz.org.rw', '202cb962ac59075b964b07152d234b70', 'avatar-03.jpg', '250786910737', 'Rwanda', 'online', '1', 'User', '1668931351', 'Hard worker Girl,'),
(3, 'Ntwali', 'John', 'John', '1649272407', 'John@giz.org.rw', '202cb962ac59075b964b07152d234b70', 'john.jpg', '250788813796', 'Canada', 'offline', '1', 'user', '0', 'International Worker');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `applys`
--
ALTER TABLE `applys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `msg_super` (`msg_super`),
  ADD KEY `msg_user` (`msg_user`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `applys`
--
ALTER TABLE `applys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`msg_super`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
