<?php
session_start();

require_once('connection.php');
if(isset($_SESSION["giz_customer"])){
	if(isset($_GET['lockscreen'])){
		unset($_SESSION["access"]);
		unset($_SESSION["Manager"]);
		$query=$con->query("UPDATE users SET status='offline' WHERE id ='".$_SESSION["giz_customer"]."' ")or die($con->error);
		echo("<script>location.href='lock.php';</script>");

	}elseif (isset($_GET['falseuser'])) {
        $query=$con->query("UPDATE users SET status='offline' WHERE id ='".$_SESSION["giz_customer"]."' ")or die($con->error);
        unset($_SESSION["giz_customer"]);
        unset($_SESSION["access"]);
        unset($_SESSION['p_attempt']);
		unset($_SESSION["Manager"]);
		echo("<script>location.href='login.php?warning=You are Logged out due attempt to change Security, It appeals you are not AUTOLIZED';</script>");
    }
    else{

$query=$con->query("UPDATE users SET status='offline' WHERE id ='".$_SESSION["giz_customer"]."' ")or die($con->error);
	 unset($_SESSION["giz_customer"]);
	 unset($_SESSION["access"]);
	 unset($_SESSION["Manager"]);
	 echo("<script>location.href='login.php';</script>");
	}
	}else{
		echo("<script>location.href='login.php';</script>");
	}
?>