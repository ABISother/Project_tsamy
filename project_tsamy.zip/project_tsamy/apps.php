<?php
session_start();
?>
<?php

 if(!isset($_SESSION["giz_supervisor"])){
 echo("<script>location.href='admin-login.php';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
 echo '<label color="red">You are not Authorized</label>';
 }
 else{

    include('connection.php'); 
 $account_key=$_SESSION["giz_supervisor"];
 $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['user_name'];
 $myemail=$fetch_account['email'];
 if($fetch_account['account_type']=='Admin'){
    $itsadmin=1;
 }else{
    $itsadmin=0; 
 }

 if(isset($_POST['save_change'])){

    $p_title=$_POST['p_tittle'];
    $p_title=str_replace("'", "\'",   $p_title);

    $nowclient=$_POST['client'];
    $nowt=time();

    $comment=$_POST['comment'];
    $comment=str_replace("'", "\'",   $comment);
    $status=$_POST['Status'];

    if($status=='Review'){
        $nprogress=35;
    }elseif($status=='Approved'){
        $nprogress=99;
    }elseif($status=='Rejected'){
        $nprogress=89;
    }elseif($status=='Pending'){
        $nprogress=45;
    }else{
        $nprogress=48;
    }

    if(isset($_GET['view'])){
        $current_project=$_GET['view'];
    }else{
        $current_project=$_POST['current_pro'];
    }


    if(!isset($alert)){
        //$savequery=$con->query("INSERT INTO girls(fname,lname,age,phone,email,girl_unique,birthdate,about,district,supervisor,join_date) VALUES ('$fName','$otherName','$age','$pnumber','$newemail','$sku','$herday','$about','$location','$account_key','$now')")or die($con->error);
        $changequery=$con->query("UPDATE applys SET status='$status', progress='$nprogress'  WHERE id='$current_project' ")or die($con->error);
         
        if ($changequery) {
            $approvo="This Project status has been changed Successfuly!";
            $dmsg="Message After changes:<br>".$comment."! <br>Status now :".$status."";

            $sendmsg=$con->query("INSERT INTO messages(msg_super,msg_user,msg_side,msg_date,msg_read,msg) VALUES('$account_key','$nowclient','Admin','$nowt','0','$dmsg')")or die($con->error);

           
               } 
      }

}

 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Apps</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">



    <!-- Flatpickr -->
    <link type="text/css" href="assets/css/flatpickr.css" rel="stylesheet">

    <link type="text/css" href="assets/css/flatpickr-airbnb.css" rel="stylesheet">





</head>





<body class="layout-compact layout-compact">

    <!-- <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div> -->

    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">

           <!-- Header -->
           <?php
            $page='apps';
            include("admin-header.php");
            ?>
            <!-- // END Header -->



            <div class="pt-32pt">
                <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0">Applicants</h2>

                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>

                                <li class="breadcrumb-item active">

                                    Applicants

                                </li>

                            </ol>

                        </div>
                    </div>


                   

                </div>
            </div>

<?php

$sel_all_customer=$con->query("SELECT*from customer  ")or die($con->error);
$count_all_customer=$sel_all_customer->num_rows;
//$fetch_all_customer=$sel_all_customer->fetch_assoc();

if(isset($_GET['all'])){ 
$sel_user_project=$con->query("SELECT*from projects where by_customer='1' ")or die($con->error);
}else{
    $sel_user_project=$con->query("SELECT*from projects where p_supervisor='$account_key' and by_customer='1' ")or die($con->error);
}
$count_user_project=$sel_user_project->num_rows;


// //$fetch_superv=$sel_superv->fetch_assoc();
 $sel_user_applications=$con->query("SELECT*from  applys where supervisor_id='$account_key' ")or die($con->error);
    $count_user_applications=$sel_user_applications->num_rows;


?>



            <div class="container page__container page__container page-section">
            <?php if(isset($alert)){ ?>
                <div class="alert alert-soft-accent alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Alert - </strong> <?php echo $alert; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>
                      <?php if(isset($info)){ ?>
                        <div class="alert alert-soft-primary alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Info - </strong> <?php echo $info; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>

    <?php if(isset($approvo)){ ?>
        <div class="alert alert-soft-success alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Success - </strong> <?php echo $approvo; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>
                      <?php if(isset($_GET['alert'])){ ?>
                        <div class="alert alert-soft-accent alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Alert - </strong> <?php echo $_GET['alert']; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>
                <div class="page-separator">
                    <div class="page-separator__text">Overview</div>
                </div>

                <div class="row card-group-row mb-lg-8pt">
                    <div class="col-lg-4 col-md-6 card-group-row__col">
                        <div class="card card-group-row__card p-relative o-hidden">
                            <div class="card-body d-flex flex-row align-items-center">
                                <div class="flex">
                                    <p class="card-title d-flex align-items-center">
                                        <strong>All Users</strong>
                                        <span class="text-20 ml-8pt">20%</span>
                                        <i class="material-icons text-accent ml-4pt icon-16pt">keyboard_arrow_up</i>
                                    </p>
                                    <span class="h2 m-0"><?php echo $count_all_customer; ?></span>
                                </div>
                                <i class="material-icons icon-32pt text-20 ml-8pt">person</i>
                            </div>
                            <div class="progress" style="height: 3px;">
                                <div class="progress-bar bg-accent" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 card-group-row__col">
                        <div class="card card-group-row__card p-relative o-hidden">
                            <div class="card-body d-flex flex-row align-items-center">
                                <div class="flex">
                                    <p class="card-title d-flex align-items-center">
                                        <strong>Who Submited their Projects</strong>
                                        <!-- <span class="text-20 ml-8pt">2018</span> -->
                                    </p>
                                    <span class="h2 m-0"><?php echo $count_user_project ?> Clients</span>
                                </div>
                                <i class="material-icons icon-32pt text-20 ml-8pt">gps_fixed</i>
                            </div>
                            <div class="progress" style="height: 3px;">
                                <div class="progress-bar" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 card-group-row__col">
                        <div class="card card-group-row__card">
                            <div class="card-body d-flex flex-row align-items-center">
                                <div class="card-title flex">
                                    <strong>Appliyed To Giz Projects</strong>
                                    <div class="h2 m-0"><?php echo $count_user_applications; ?> Applicants</div>
                                </div>
                                <i class="material-icons icon-32pt text-20">contacts</i>
                            </div>
                        </div>
                    </div>
                </div>

                

                <div class="page-separator">
                    <div class="page-separator__text">Applicants Submited Projects Related to your Department (<?php echo $count_user_project; ?>)</div>
                </div>

                <div class="card mb-0">

                    <div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-employee-name" data-lists-values='["js-lists-values-employee-name", "js-lists-values-employer-name", "js-lists-values-projects", "js-lists-values-activity", "js-lists-values-earnings"]'>



                        <div class="card-header">
                            <form class="form-inline">
                                <label class="mr-sm-2 form-label" for="inlineFormFilterBy">Filter by:</label>
                                <input type="text" class="form-control search mb-2 mr-sm-2 mb-sm-0" id="inlineFormFilterBy" placeholder="Search ...">

                                <label class="sr-only" for="inlineFormRole">Role</label>
                                <select id="inlineFormRole" class="custom-select mb-2 mr-sm-2 mb-sm-0">
                                    <option value="All Roles">All Roles</option>
                                </select>
                                <?php if(isset($itsadmin)&&($itsadmin==1)){ ?>
                                <div class="ml-auto mb-2 mb-sm-0 custom-control-inline mr-0">
                                    <label class="form-label mb-0" for="active">All</label>
                                    <div class="custom-control custom-checkbox-toggle ml-8pt">
                                        <input  type="checkbox" id="active" class="custom-control-input">
                                        <label class="custom-control-label" for="active">Active</label>
                                    </div>
                                </div>
                                <?php } ?>
                            </form>
                        </div>


                        <table class="table mb-0 thead-border-top-0 table-nowrap">
                            <thead>
                                <tr>
                                    <th>
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-employee-name">Applicants</a>
                                    </th>

                                    <th style="width: 150px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-employer-name">Email</a>
                                    </th>


                                    <th class="text-center" style="width: 48px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-projects">Projects</a>
                                    </th>


                                    <th style="width: 30px;">Status</th>

                                    <th style="width: 90px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-activity">Activity</a>
                                    </th>
                                    <th style="width: 45px;">
                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-earnings">Estimated Budget</a>
                                    </th>
                                    <th style="width: 10px;" class="pl-0"></th>
                                </tr>
                            </thead>
                            <tbody class="list" id="search">

                            <?php  
                             $sel_all_project=$con->query("SELECT*from projects where p_supervisor='$account_key' and 	by_customer='1' ORDER BY id DESC")or die($con->error);

                            while($fetch_all_project=$sel_all_project->fetch_assoc()){
                                $ncustomer=$fetch_all_project['p_owner'];
                                
                                
                                $sel_ncustomer=$con->query("SELECT*from customer where id='$ncustomer' ORDER BY id DESC")or die($con->error);
                                $count_ncustomer=$sel_ncustomer->num_rows;
                                $fetch_ncustomer=$sel_ncustomer->fetch_assoc();

                                $event_time=$fetch_all_project['created_on'];

                                                 //date_default_timezone_set('America/New_York');  
                                            //echo facebook_time_ago('2016-03-11 04:58:00');  
                                           
                                          
                                                
                                ?>

                                <tr class="selected">
                                    <!-- <td class="pr-0">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input js-check-selected-row" checked="" id="customCheck1_staff1">
                                            <label class="custom-control-label" for="customCheck1_staff1"><span class="text-hide">Check</span></label>
                                        </div>
                                    </td> -->

                                    <td>
                                        <div class="media flex-nowrap align-items-center" style="white-space: nowrap;">
                                            <div class="avatar avatar-sm mr-8pt">
                                            <span class="avatar-title rounded-circle bg-primary"><i class="material-icons">account_box</i></span>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex flex-column">
                                                    <p class="mb-0"><strong class="js-lists-values-employee-name"><?php echo $fetch_ncustomer['username'];  ?></strong></p>
                                                    <small class="js-lists-values-employee-email text-50"><?php echo $fetch_ncustomer['fname']." ".$fetch_ncustomer['lname'];  ?></small>
                                                </div>
                                            </div>
                                        </div>

                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <!-- <a href="#" class="text-warning"><i class="material-icons mr-8pt">star</i></a> -->
                                            <a href="#" class="text-70"><span class="js-lists-values-employer-name"><?php echo $fetch_ncustomer['email'];  ?></span></a>
                                        </div>
                                    </td>
                                    <td class="text-center js-lists-values-projects small"><?php echo $fetch_all_project['p_tittle']; ?></td>

                                    <td>
                                        <a href="admin-view.php?view=<?php echo $fetch_all_project['id']; ?>" class="chip chip-outline-secondary"><?php echo $fetch_all_project['status']; ?></a>

                                    </td>

                                    <td class="text-30 js-lists-values-activity small"><?php echo print date("(D) d M, Y",$event_time); ?></td>
                                    <td class="js-lists-values-earnings small"><?php echo number_format($fetch_all_project['budget']); ?> RWF</td>
                                    <td class="text-right pl-0">
                                        
                                        <div class="dropdown">
                            <a href="#" data-toggle="dropdown" data-caret="false" class="text-muted"><i class="material-icons">more_vert</i></a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a href="admin-view.php?view=<?php echo $fetch_all_project['id']; ?>" class="dropdown-item">Review Submited Project</a>
                                <div class="dropdown-divider"></div>
                                <a href="ad-message.php?client=<?php echo $fetch_ncustomer['id'];  ?>" class="dropdown-item">Chat with <?php echo $fetch_ncustomer['username'];  ?></a>
                                <div class="dropdown-divider"></div>
                                <!-- <a href="javascript:void(0)" class="dropdown-item text-danger">Reject this request</a> -->
                            </div>
                        </div>
                                    </td>
                                </tr>
                                <?php } ?>

                                


                            </tbody>
                        </table>
                    </div>

                    <div class="card-footer p-8pt">

                

                    </div>
        

                </div>
                                            <!-- Applicants -->

                      <div class="page-separator" id="applications">
                    <div class="page-separator__text">Applicants</div>
                         </div>


                         
                               <div class="row mb-32pt">
                    <div class="col-lg-4">
                        <div class="page-separator">
                            <div class="page-separator__text">Application status</div>
                        </div>
                        <p class="card-subtitle text-70 mb-16pt mb-lg-0" id="app-view"><?php if(isset($_GET['application'])){
                            $nowapplication=$_GET['application'];

                            //$nowuser=$_GET['user'];

                            $sel_all_project=$con->query("SELECT*from applys where id='$nowapplication'  ORDER BY id DESC")or die($con->error);
                            if($count_ava=$sel_all_project->num_rows>0){
                            $fetch_all_project=$sel_all_project->fetch_assoc();
                                $ncustomer=$fetch_all_project['user_id'];
                                
                                
                                $sel_ncustomer=$con->query("SELECT*from customer where id='$ncustomer' ORDER BY id DESC")or die($con->error);
                                $count_ncustomer=$sel_ncustomer->num_rows;
                                $fetch_ncustomer=$sel_ncustomer->fetch_assoc();
                            ?>
                            <!-- //Applicant Panel -->
                            <div class="card-group-row__col">

                            <div class="card overlay--show card-lg overlay--primary-dodger-blue stack stack--1 card-group-row__card">
    
                                <div class="card-body d-flex flex-column">
                                    <div class="d-flex align-items-center">
                                        <div class="flex">
                                            <div class="d-flex align-items-center">
                                                <div class="rounded mr-12pt z-0 o-hidden">
                                                    <div class="overlay">
                                                        <img src="assets/images/paths/angular_40x40%402x.png" width="40" height="40" alt="Angular" class="rounded">
                                                        <span class="overlay__content overlay__content-transparent">
                                                            <span class="overlay__action d-flex flex-column text-center lh-1">
                                                                <small class="h6 small text-white mb-0" style="font-weight: 500;"><?php echo $fetch_all_project['progress']; ?>%</small>
                                                            </span>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="flex">
                                                    <div class="card-title"><?php echo $fetch_ncustomer['username'];  ?></div>
                                                    <p class="flex text-black-50 lh-1 mb-0"><small><?php echo $fetch_ncustomer['email'];  ?></small></p>
                                                </div>
                                            </div>
                                        </div>
    
                                        <a href="apps.php" data-toggle="tooltip" data-title="Close this" data-placement="top" data-boundary="window" class="ml-4pt material-icons text-20 card-course__icon-favorite">close</a>
    
                                    </div>
    <form action="apps.php?application=<?php echo $nowapplication; ?>" method="post" name="applicants-form">
    <input type="text" readonly class="form-control" name="p_tittle" value="<?php echo $fetch_all_project['projectname'] ?>" >
                               <input type="hidden" readonly class="form-control" name="client" value="<?php echo $fetch_ncustomer['id']; ?>" >
                               <input type="hidden" name="current_pro" readonly class="form-control" value="<?php echo $nowapplication; ?>" >
                               <input type="hidden" name="progress" readonly class="form-control" value="<?php echo $fetch_all_project['progress']; ?>" >
    
                                    <div class="card-body d-flex flex-column justify-content-center">
                                    <small class="text-muted text-uppercase mb-2 d-block font-weight-bold">Basic Informations</small>
                                    <small class="d-flex align-items-center font-weight-bold text-muted mb-1">
                                        <div class="row">
                                        <span class="flex text-body">Project Name </span>
                                        <span class="mx-3"><?php echo $fetch_all_project['projectname'] ?></span>
                                        </div>
                                    </small>
                                    <small class="d-flex align-items-center font-weight-bold text-muted mb-1">
                                    <div class="row">
                                        <span class="flex text-body">App Status</span>
                                        <span class="mx-3"><?php echo $fetch_all_project['status']; ?></span>
                                        <span class="d-flex align-items-center"><i class="material-icons text-success icon-16pt mr-1">keyboard_arrow_up</i> 50%</span>
                                        </div>
                                    </small>
                                    <small class="d-flex align-items-center font-weight-bold text-muted mb-1">
                                    <div class="row">
                                        <span class="flex text-body">Applied On</span>
                                        <span class="mx-3"><?php $nowevent_time=$fetch_all_project['applied_on']; 
                                        print date("(D) d M, Y",$nowevent_time); ?></span>
                                        </div>
                                    </small>
                                    
                                    
                                </div>
                                <div class="d-flex align-items-center mr-8pt">
                                            <p class="flex text-black-50 lh-1 mb-0"><small><label class="form-label">Share a Message to Client</label></small></p>
                                        </div>
                                <div class="d-flex align-items-center">
                                    <textarea class="form-control col-md-10" name="comment" required=""></textarea>
                                        </div>

                                        
    
                                    <div class="d-flex align-items-center mb-8pt justify-content-center">
                                        <div class="d-flex align-items-center mr-8pt">
                                            <p class="flex text-black-50 lh-1 mb-0"><small><label class="form-label">Change Status</label></small></p>
                                        </div>
                                        
                                       
                                        <div class="d-flex align-items-center">
                                            <p class="flex text-black-50 lh-1 mb-0"><small>
                                            <div class="form-group mb-0">
                                       
                                        <select id="custom-select" name="Status" class="form-control custom-select">
                                        <option selected>Open this select Case Status</option>
                                        <option value="<?php echo $fetch_all_project['status']; ?>" selected><?php echo $fetch_all_project['status']; ?></option>
                                        <option value="Pending">Pending</option>
                                        <option value="Approved">Approved</option>
                                        <option value="Rejected">Rejected</option>
                                        </select>

                                        </div>
                                            </small>
                                        </p>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex align-items-center justify-content-center">
                                        <button type="submit" name="save_change" class="btn btn-primary">Save Changes</button>
                                    </div>
    
                        </form>
                                </div>
                            </div>
    
    
                        </div>
                        <?php
                            // End Applicant Panel
                        } }else{
                            echo "If You select an Application will appear Here!";
                        } ?></p>
                    </div>
                    <div class="col-lg-8 d-flex align-items-center">
                        <div class="flex" style="max-width: 100%">


                            <div class="card m-0">

                                <div class="table-responsive" data-toggle="lists" data-lists-sort-by="js-lists-values-employee-name" data-lists-values='["js-lists-values-employee-name", "js-lists-values-employer-name", "js-lists-values-projects", "js-lists-values-activity", "js-lists-values-earnings"]'>

                                    <div class="card-header">
                                        <div class="search-form">
                                            <input type="text" class="form-control search" placeholder="Search ...">
                                            <button class="btn" type="button"><i class="material-icons">search</i></button>
                                        </div>
                                    </div>




                                    <table class="table mb-0 thead-border-top-0 table-nowrap">
                                        <thead>
                                            <tr>

                                                <th>
                                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-employee-name">Employee</a>
                                                </th>



                                                <th style="width: 37px;">Status</th>

                                                <th style="width: 120px;">
                                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-activity">Applied On</a>
                                                </th>
                                                <th style="width: 51px;">
                                                    <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-earnings">Project</a>
                                                </th>
                                                <th style="width: 24px;" class="pl-0"></th>
                                            </tr>
                                        </thead>
                                        <tbody class="list" id="search">
                                            
                           
                                        <?php  
                             $sel_all_project=$con->query("SELECT*from applys where supervisor_id='$account_key'  ORDER BY id DESC")or die($con->error);

                            while($fetch_all_project=$sel_all_project->fetch_assoc()){
                                $ncustomer=$fetch_all_project['user_id'];
                                
                                
                                $sel_ncustomer=$con->query("SELECT*from customer where id='$ncustomer' ORDER BY id DESC")or die($con->error);
                                $count_ncustomer=$sel_ncustomer->num_rows;
                                $fetch_ncustomer=$sel_ncustomer->fetch_assoc();

                                $event_time=$fetch_all_project['applied_on'];

                                

                                if($fetch_all_project['status']=='Submited'){
                                    $statuscolor='info';
                                }elseif($fetch_all_project['status']=='Pending'){
                                  $statuscolor='warning';
                                }elseif($fetch_all_project['status']=='Invalid'){
                                  $statuscolor='dark';
                                }elseif($fetch_all_project['status']=='Closed'){
                                  $statuscolor='primary';
                                }else{
                                    $color='secondary';
                                    $severity='Warning';
                                }

                                                 //date_default_timezone_set('America/New_York');  
                                            //echo facebook_time_ago('2016-03-11 04:58:00');  
                                           
                                          
                                                
                                ?>
                              
                                            <tr>

                                                <td>


                                                    <div class="d-flex flex-column">
                                                        <p class="mb-0"><strong class="js-lists-values-employee-name"><?php echo $fetch_ncustomer['username'];  ?></strong></p>
                                                        <small class="js-lists-values-employee-email text-50"><?php echo $fetch_ncustomer['email'];  ?></small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <a href="apps.php?application=<?php echo $fetch_all_project['id']; ?>&user=<?php echo $fetch_ncustomer['id'];  ?>" class="chip chip-outline-<?php echo $statuscolor; ?>"><?php echo $fetch_all_project['status'] ?></a>
                                                </td>

                                                <td class="text-50 js-lists-values-activity small"><?php echo print date("(D) d M, Y",$event_time); ?></td>
                                                <td class="js-lists-values-earnings small"><?php echo $fetch_all_project['projectname'] ?></td>
                                                <td class="text-right pl-0">
                                                      
                                                <div class="dropdown ml-auto">
                            <a href="#" data-toggle="dropdown" class="dropdown-toggle text-black-70">Act on Application</a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a href="apps.php?application=<?php echo $fetch_all_project['id']; ?>&user=<?php echo $fetch_ncustomer['id'];  ?>" class="dropdown-item active">Review Application</a>
                                <a href="ad-message.php?client=<?php echo $fetch_ncustomer['id'];  ?>" class="dropdown-item">Chat with <?php echo $fetch_ncustomer['username'];  ?></a>
                                <div class="dropdown-divider"></div>
                                <!-- <a href="#" class="dropdown-item">Reject this Application</a> -->
                            </div>
                        </div>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                           

                                        </tbody>
                                    </table>
                                </div>


                            </div>

                        </div>
                    </div>
                </div>
   
            </div>
                                         

            
            


            <?php

include("admin-footer.php");

?>


    </div>
    <!-- // END drawer-layout -->

    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>



    <!-- Flatpickr -->
    <script src="assets/vendor/flatpickr/flatpickr.min.js"></script>
    <script src="assets/js/flatpickr.js"></script>

    <!-- Global Settings -->
    <script src="assets/js/settings.js"></script>

    <!-- Chart.js -->
    <script src="assets/vendor/Chart.min.js"></script>
    <script src="assets/js/chartjs-rounded-bar.js"></script>
    <script src="assets/js/chartjs.js"></script>

    <!-- Chart.js Samples -->
    <script src="assets/js/page.staff.js"></script>

    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

    <!-- Sidebar Mini JS -->
    <script src="assets/js/sidebar-mini.js"></script>
    <script>
        (function() {
            'use strict';

            // ENABLE sidebar menu tabs
            $('.js-sidebar-mini-tabs [data-toggle="tab"]').on('click', function(e) {
                e.preventDefault()
                $(this).tab('show')
            })

            $('.js-sidebar-mini-tabs').on('show.bs.tab', function(e) {
                $('.js-sidebar-mini-tabs > .active').removeClass('active')
                $(e.target).parent().addClass('active')
            })
        })()
    </script>

</body>


<!-- Mirrored from luma.humatheme.com/compact-staff.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 16 May 2020 00:12:08 GMT -->
</html>