<?php
session_start();
?>
<?php

 if(!isset($_SESSION["giz_supervisor"])){
 echo("<script>location.href='admin-login.php';</script>");
// // }elseif (isset($_SESSION["DA_user"])&& !isset($_SESSION["access"])){
// //  echo("<script>location.href='lock.php';</script>");
 echo '<label color="red">You are not Authorized</label>';
 }
 else{

    include('connection.php'); 
 $account_key=$_SESSION["giz_supervisor"];
 $sel_account=$con->query("SELECT*from users WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['user_name'];
 $myemail=$fetch_account['email'];
 if($fetch_account['account_type']=='Admin'){
    $itsadmin=1;
 }else{
    $itsadmin=0; 
 }

 if(isset($_POST['save_account'])){
    $uname=$_POST['uname'];
    $uname=str_replace("'", "\'",   $uname);
    
    $fname=$_POST['fname'];
    $fname=str_replace("'", "\'",   $fname);
    $lname=$_POST['oname'];
    $lname=str_replace("'", "\'",   $lname);
    $contacts=$_POST['contacts'];
    $emails=$_POST['emails'];
    $pass=$_POST['pass'];
    $pass=str_replace("'", "\'",   $pass);
    $security=md5($pass);

    $about=$_POST['about'];
    $pass=str_replace("'", "\'",   $pass);

    $category_name=$_POST['category_name'];
   $about=str_replace("'", "\'",   $about);

   if(!isset($_POST['admin'])){
   $account_type='User';
   }else{
    $account_type='Admin';
   }

    $sel_availables=$con->query("SELECT*from users where user_name='$uname' ")or die($con->error);
    if($count_availables=$sel_availables->num_rows>0){
     $alert="User Name: ".$uname." Is already in system<br> Please a Unique Name!";
    }
        
   
         $now=time();
   
         if(!isset($alert)){
             $savequery=$con->query("INSERT INTO users(fname,lname,user_name,Join_date,email,password,contacts,country,account_type,about) 
             VALUES ('$fname','$lname','$uname','$now','$emails','$security','$contacts','Rwanda','$account_type','$about')")or die($con->error);
             if ($savequery){
                 $approvo="A New User (.$uname.) has been Added!<br> ";
           
                 $saveactivity=$con->query("INSERT INTO alerts(owner,time_created,for_all,for_admin,for_user,tittle,viewed) VALUES ('$account_key','$now','1','1','1','A New User (.$uname.) has been Added to the system','0')")or die($con->error);
                 $last=$con->query("SELECT * FROM users WHERE id=(SELECT max(id) FROM users) ")or die($con->error);
                    $fetch_last=$last->fetch_assoc();
                    $last_id=$fetch_last['id'];

                //SAVING NEW DEPARTMENT
                if(!empty($category_name)){
             $savedepartment=$con->query("INSERT INTO  departments(category_name,manager,initial_date,partners) VALUES ('$category_name','$last_id','$now','0')")or die($con->error);
             if ($savedepartment){
                $approvo .="<br>AND a New Department is  Added to be Managed By ".$uname." !<br> ";
                }
                    } 
           }

 }
}

 if(isset($_POST['change_account'])){
    $uname=$_POST['uname'];
    $uname=str_replace("'", "\'",   $uname);
    $fname=$_POST['fname'];
    $fname=str_replace("'", "\'",   $fname);
    $lname=$_POST['lname'];
    $lname=str_replace("'", "\'",   $lname);
    $contacts=$_POST['contacts'];
    $emails=$_POST['emails'];
    $abouts=$_POST['abouts'];
    $abouts=str_replace("'", "\'",   $abouts);

    $now=time();

    if(!isset($alert)){
        //$savequery=$con->query("INSERT INTO girls(fname,lname,age,phone,email,girl_unique,birthdate,about,district,supervisor,join_date) VALUES ('$fName','$otherName','$age','$pnumber','$newemail','$sku','$herday','$about','$location','$account_key','$now')")or die($con->error);
        $changequery=$con->query("UPDATE users SET fname='$fname', lname='$lname', user_name='$uname', email='$emails', about='$abouts', contacts='$contacts'   WHERE id ='$account_key' ")or die($con->error);
         
        if ($changequery) {
            $approvo="The Change was successfully Made to ".$uname." !<br> ";
           
           
               } 
      }
 }
 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Profile</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">






</head>


















<body class="layout-compact layout-compact">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">

           <!-- Header -->
           <?php
            $page='profile';
            include("admin-header.php");
            ?>
            <!-- // END Header -->



            <div class="pt-32pt">
                <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                    <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                        <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                            <h2 class="mb-0">Profiles</h2>

                            <ol class="breadcrumb p-0 m-0">
                                <li class="breadcrumb-item"><a href="admin-dashboard.php">Dashboard</a></li>

                                <li class="breadcrumb-item active">

                                    Applicants

                                </li>

                            </ol>

                        </div>
                    </div>


                   

                </div>
            </div>
            

            <div class="container page__container page-section">

            <?php if(isset($alert)){ ?>
                <div class="alert alert-soft-accent alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Alert - </strong> <?php echo $alert; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>
                      <?php if(isset($info)){ ?>
                        <div class="alert alert-soft-primary alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Info - </strong> <?php echo $info; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>

    <?php if(isset($approvo)){ ?>
        <div class="alert alert-soft-success alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Success - </strong> <?php echo $approvo; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>
                      <?php if(isset($_GET['alert'])){ ?>
                        <div class="alert alert-soft-accent alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <div class="d-flex flex-wrap align-items-start">
                                    <div class="mr-8pt">
                                        <i class="material-icons">access_time</i>
                                    </div>
                                    <div class="flex" style="min-width: 180px">
                                        <small class="text-black-100">
                                            <strong>Alert - </strong> <?php echo $_GET['alert']; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                      <?php } ?>

                <div class="row">
                <?php if($itsadmin==1){ ?>
                    <div class="col-md-4">
                        <div class="card-header text-center">
                            <a href="profile.php?New_user" class="btn btn-success">ADD NEW USER</a>
                            
                        </div>
                    </div>
                   
                    <!-- <div class="col-md-4">
                        <div class="card-header text-center">
                            <a href="profile.php?partner"  class="btn btn-warning">ADD A PARTNER</a>
                            
                        </div>
                    </div> -->

                 
                    <?PHP } ?>
                    <div class="col-md-4">
                        <div class="card-header text-center">
                            <a href="profile.php?update" class="btn btn-primary">Edit My Profile</a>
                            
                        </div>
                    </div>
                </div>
                        <br>
                        <?php if(isset($_GET['New_user'])){ ?>
                <div class="col-md-8 card">
                        
                    <form action="profile.php?New_user" name="user-form" method="POST">
                        <div class="page-separator">
                                <div class="page-separator__text">User Information</div>
                               
                            </div>
                            
                            
                            <label class="form-label">User Name</label>
                            <div class="form-group mb-24pt">
                                <input type="text" name="uname" class="form-control form-control-lg" placeholder="User Name" >
                                <small class="form-text text-muted">Please see our <a href="#">Name guideline</a></small>
                            </div>

                            <div class="row">
                            
                            <div class="form-group col-md-6">
                            <label class="form-label">First Name</label>
                                <input type="text" name="fname" class="form-control form-control-lg" placeholder="First Name" >
                               
                            </div>
                            
                            <div class="form-group col-md-6">
                            <label class="form-label">Other Names</label>
                                <input type="text" name="oname" class="form-control form-control-lg" placeholder="Last Names" >
                                
                              
                            </div>
                            </div>

                            <label class="form-label">Email</label>
                            <div class="form-group mb-24pt">
                                <input type="email" name="emails" class="form-control form-control-lg" placeholder="User Email" >
                                <small class="form-text text-muted">Please see our <a href="#">Name guideline</a></small>
                            </div>
                            <label class="form-label">Contacts</label>
                            <div class="form-group mb-24pt">
                                <input type="number" name="contacts" class="form-control form-control-lg" placeholder="Phone(ex:250784624822)">
                                <small class="form-text text-muted">Please see our <a href="#">Name guideline</a></small>
                            </div>

                            <div class="form-group mb-32pt">
                                <label class="form-label">About</label>
                                <!-- <textarea class="form-control" rows="3" placeholder="Course description"></textarea> -->
                                <textarea class="form-control form-control-lg" name="about"></textarea>
                                <small class="form-text text-muted">Shortly describe this Person.</small>
                            </div>

                            <div class="page-separator">
                                <div class="page-separator__text">Account Security</div>
                            </div>
                            <label class="form-label">Password</label>
                            <div class="form-group mb-24pt">
                                <input type="text" name="pass" class="form-control form-control-lg" placeholder="Reserved Password" >
                                <small class="form-text text-muted">New User will be able to change this Password <a href="#">Right away</a></small>
                            </div>
                            

                            <div class="page-separator">
                                <div class="page-separator__text">New Depertment</div>
                            </div>
                            <label class="form-label">Department Name/Category</label>
                            <div class="form-group mb-24pt">
                                <input type="text" name="category_name" class="form-control form-control-lg" placeholder="Category" >
                                <small class="form-text text-muted">Please see our <a href="#">Name guideline</a></small>
                            </div>
                            <div class="custom-control custom-checkbox-toggle custom-control-inline mr-1">
                                <input  type="checkbox" name="admin" id="subscribe" class="custom-control-input">
                                <label class="custom-control-label" for="subscribe">Yes</label>
                            </div>
                            <label class="form-label mb-0" for="subscribe">Make Admin User</label>
                            <div class="card-header text-center">
                            <a href="profile.php" name="canncer_account" class="btn btn-accent">Close</a>
                            <button type="reset"  class="btn btn-secondary">Reset</button>
                                    <button type="submit" name="save_account" class="btn btn-success">Save</button>
                                </div>
                    </form>
                    </div> <!--====End New===-->  

                <?php } ?>
                

                <?php if(isset($_GET['update'])){ ?>
                    <form action="profile.php" name="updating-form" method="POST" >
                        <div class="col-md-8">

                            <div class="page-separator">
                                <div class="page-separator__text">Updating Basic information</div>
                            </div>

                            <label class="form-label">User Name</label>
                            <div class="form-group mb-24pt">
                                <input type="text" name="uname" class="form-control form-control-lg" placeholder="Name" value="<?php echo $names; ?>">
                                <small class="form-text text-muted">Please see our <a href="#">Name guideline</a></small>
                            </div>
                            <label class="form-label">Names</label>
                            <div class="row">
                            
                            <div class="form-group col-md-4">
                                <input type="text" name="fname" class="form-control form-control-lg" placeholder="Name" value="<?php echo $fetch_account['fname']; ?>">
                                <small class="form-text text-muted">First Name </small>
                            </div>
                            <div class="form-group col-md-4">
                                <input type="text" name="lname" class="form-control form-control-lg" placeholder="Name" value="<?php echo $fetch_account['lname']; ?>">
                                <small class="form-text text-muted">Other Name </small>
                              
                            </div>
                            </div>
                            <label class="form-label">Email</label>
                            <div class="form-group mb-24pt">
                                <input type="email" name="emails" class="form-control form-control-lg" placeholder="Name" value="<?php echo $fetch_account['email']; ?>">
                                <small class="form-text text-muted">Please see our <a href="#">Name guideline</a></small>
                            </div>
                            <label class="form-label">Contacts</label>
                            <div class="form-group mb-24pt">
                                <input type="number" name="contacts" class="form-control form-control-lg" placeholder="Name" value="<?php echo $fetch_account['contacts']; ?>">
                                <small class="form-text text-muted">Please see our <a href="#">Name guideline</a></small>
                            </div>

                            <div class="form-group mb-32pt">
                                <label class="form-label">About</label>
                                <!-- <textarea class="form-control" rows="3" placeholder="Course description"></textarea> -->
                                <textarea class="form-control form-control-lg" name="abouts"><?php echo $fetch_account['about']; ?></textarea>
                                <small class="form-text text-muted">Shortly describe this course.</small>
                            </div>


                          
                            <div class="card-header text-center">
                                    <a href="profile.php" class="btn btn-secondary" >Cancer</a>
                                    <button type="submit" name="change_account" class="btn btn-accent" >Save changes</button>
                                </div>
                        </div>
                </form>
                        <?PHP  } ?>


                    


                <div class="page-separator">
                                <div class="page-separator__text">Giz Employees</div>
                            </div>

                            <div class="row card-group-row">

                            <?php                            
                            while($fetch_all_users=$sel_all_users->fetch_assoc()){
                                $nowuser=$fetch_all_users['id'];

                                $sel_all_departments=$con->query("SELECT*from departments where manager='$nowuser' ")or die($con->error);
                                $count_all_departments=$sel_all_departments->num_rows;
                                $fetch_all_departments=$sel_all_departments->fetch_assoc();
                       
                           ?>
                                <div class="col-md-6 col-xl-4 card-group-row__col">
                                    <div class="card card-group-row__card">
                                        <div class="card-header d-flex align-items-center">
                                            <a href="#" class="card-title flex mr-12pt"><?php echo $fetch_all_users['user_name'] ?></a>
                                            <?php if($nowuser==$account_key){ ?>
                                            <a href="profile.php?update" class="btn btn-light btn-sm">Me</a>
                                            <?php } ?>
                                        </div>
                                        <div class="card-body flex text-center d-flex flex-column align-items-center justify-content-center">
                                            <a href="#" class="avatar avatar-xl overlay overlay--primary rounded-circle p-relative o-hidden mb-16pt">
                                                <img src="assets/images/users/<?php echo $fetch_all_users['profile']; ?>" alt="teacher" class="avatar-img">
                                                <span class="overlay__content"><i class="overlay__action material-icons icon-40pt">face</i></span>
                                            </a>
                                            <a href="#" class="card-title flex mr-12pt"><?php echo $fetch_all_users['fname']." ".$fetch_all_users['lname'] ?>.</a>
                                            <div class="flex">
                                                <div class="d-inline-flex align-items-center mb-8pt">
                                                    <div class="rating mr-8pt">

                                                        <span class="rating__item"><?php echo $fetch_all_users['account_type']; ?></span>

                                                       


                                                    </div>
                                                    <small class="text-muted">5/5</small>
                                                </div>

                                                <p class="text-70 measure-paragraph"><?php echo $fetch_all_users['about'] ?></p>
                                                <?php if($nowuser==$account_key){ ?>
                                            <a href="profile.php?update" class="btn btn-light btn-sm">Update</a>
                                            <?php }elseif($itsadmin==1){ ?>
                                                <a href="profile.php?change=<?php echo $fetch_all_users['id']?>" data-toggle="tooltip" data-title="Change access" data-placement="bottom" class="chip chip-outline-secondary">Edit <?php echo $fetch_all_users['user_name'] ?></a>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="card-body flex-0">
                                            <div class="d-flex align-items-center">
                                           
                                                <a href="profile.php?update" class="avatar avatar-4by3 overlay overlay--primary mr-12pt">
                                                    <img src="assets/images/logo/logo.png" alt="course" class="avatar-img rounded">
                                                    <span class="overlay__content"></span>
                                                </a>
                                                
                                                <div class="flex">
                                                    <a href="#" class="card-title"><?php echo $fetch_all_departments['category_name']; ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>




                            </div>

                
                     



            </div>



        <?php

include("admin-footer.php");

?>


    </div>
    <!-- // END drawer-layout -->


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>


    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

</body>

</html>