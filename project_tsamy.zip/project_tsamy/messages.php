<?php
session_start();
?>
<?php


 if(!isset($_SESSION["giz_customer"])){
    echo("<script>location.href='login.php?alert=login first!';</script>");
echo '<label color="red">You are not Authorized</label>';
 }
 else{
   include('connection.php'); 
 $account_key=$_SESSION["giz_customer"];
 $sel_account=$con->query("SELECT*from customer WHERE id='$account_key' ")or die($con->error);
 $fetch_account=$sel_account->fetch_assoc();
 $names=$fetch_account['username'];
 $myemail=$fetch_account['email'];



$nowt=time();

if(isset($_GET['super'])){
    $nowsuper=$_GET['super'];
}

if(isset($_POST['sbmt_msg'])){
$dmsg=$_POST['rmsg'];
$dmsg=str_replace("'", "\'", $dmsg);
$sel_nmsg=$con->query("SELECT*from messages WHERE msg_user='$account_key' ")or die($con->error);
$fetch_nsup= $sel_nmsg->fetch_assoc();
$supervisor=$fetch_nsup['msg_super'];
$sendmsg=$con->query("INSERT INTO messages(msg_super,msg_user,msg_side,msg_date,msg_read,msg) VALUES('$nowsuper','$account_key','User','$nowt','0','$dmsg')")or die($con->error);

}
 }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Messages</title>

    <!-- Prevent the demo from appearing in search engines -->
    <meta name="robots" content="noindex">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&amp;display=swap" rel="stylesheet">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Fix Footer CSS -->
    <link type="text/css" href="assets/vendor/fix-footer.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">


    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">


    <!-- Preloader -->
    <link type="text/css" href="assets/css/preloader.css" rel="stylesheet">


    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">

      <!-- Ajax reasons-->
   <script src="assets/js/jquery.min.js"></script>








</head>

































<body class="layout-app app-messages">

    <!-- <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div> -->

    <div class="mdk-drawer-layout js-mdk-drawer-layout" data-push data-responsive-width="992px">
        <div class="mdk-drawer-layout__content page-content">

            <!-- Header -->





            <!-- // END Header -->










            <div data-push data-responsive-width="768px" data-has-scrollable-region data-fullbleed class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content" data-perfect-scrollbar>


                    <div class="app-messages__container d-flex flex-column h-100 pb-4">
                       

                        <div class="navbar navbar-light bg-white navbar-expand-sm navbar-shadow z-1" id="messages-navbar">
                            <div class="container-fluid flex-wrap px-sm-0">
                                <div class="nav py-2">
                                    <div class="nav-item d-flex align-items-center mr-3">
                                        <div class="mr-3">
                                            <div class="avatar avatar-online avatar-sm">
                                                <img src="assets/images/users/avatar2.png" alt="people" class="avatar-img rounded-circle">
                                            </div>
                                        </div>
                                        <div class="d-flex flex-column" style="max-width: 200px; font-size: 15px">
                                            <strong class="text-body"><?php echo $names; ?></strong>
                                            <span class="text-50 text-ellipsis">Contacting </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="py-2 flex d-flex align-items-center">
                                    <div class="flex search-form form-control-rounded navbar-search" style="min-width: 200px;">
                                        <input type="text" class="form-control" placeholder="Search messages" id="searchSample02">
                                        <button class="btn pr-3" type="button"><i class="material-icons">search</i></button>
                                    </div>
                                    <button data-target="#messages-drawer" class="navbar-toggler d-block d-md-none ml-3 p-0" data-toggle="sidebar" type="button">
                                        <i class="material-icons">people_outline</i>
                                    </button>
                                </div>
                            </div>
                        </div>
                       
                        <div class="flex pt-4" style="position: relative;" data-perfect-scrollbar>
                            <div class="container page__container page__container">
                            <?php  $sel_msg=$con->query("SELECT*from messages WHERE msg_user='$account_key'  ")or die($con->error);
$count_msg=$sel_msg->num_rows;
if($count_msg<1){
    
    if(isset($account_key)){
        $sel_availables=$con->query("SELECT*from applys where user_id='$account_key' ")or die($con->error);
        if($count_availables=$sel_availables->num_rows>0){
            
            $applyied_this=1;

        }else{
            $applyied_this=0;
        }
    }else{
        $applyied_this=0;
    }
    ?>


                                <div class="card">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="mr-3">
                                            <div class="avatar avatar-xl">
                                            <span class="avatar-title rounded "><img src="assets/images/logo/logo.png" alt="logo" class="img-fluid" /></span>
                                            </div>
                                        </div>
                                        <div class="flex">
                                            <h4 class="mb-0">Auto Message From GIZ Rwanda to <?php echo $names; ?></h4>
                                            <p class="text-50 mb-0">You are Supposed to submit any Ideal or Apply to any of giz Projects, that we could assign your chat to the One in charge of your desired Field
                                                <br>
                                                <a href="apply.php" class="chip chip-outline-secondary">Choose a Project Now</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <script>
                window.stop();
                </script>
                                <?php }?>
                                <ul class="d-flex flex-column list-styled" id="messaes">


                               

                                    <?php
                                    $count_msg=$sel_msg->num_rows;
                                    while($fetch_msg=$sel_msg->fetch_assoc()){
                                       
                                            $super=$fetch_msg['msg_super'];
                                            $event_time=$fetch_msg['msg_date'];

                                            $sel_superv=$con->query("SELECT*from users WHERE id='$super' ")or die($con->error);
                                                $fetch_superv=$sel_superv->fetch_assoc();
                                            
                                          
                                            //date_default_timezone_set('America/New_York');  
                                            //echo facebook_time_ago('2016-03-11 04:58:00');  
                                           
                                                 $time_ago = $event_time;  
                                                 $current_time = time();  
                                                 $time_difference = $current_time - $time_ago;  
                                                 $seconds = $time_difference;  
                                                 $minutes      = round($seconds / 60 );           // value 60 is seconds  
                                                 $hours           = round($seconds / 3600);           //value 3600 is 60 minutes * 60 sec  
                                                 $days          = round($seconds / 86400);          //86400 = 24 * 60 * 60;  
                                                 $weeks          = round($seconds / 604800);          // 7*24*60*60;  
                                                 $months          = round($seconds / 2629440);     //((365+365+365+365+366)/5/12)*24*60*60  
                                                 $years          = round($seconds / 31553280);     //(365+365+365+365+366)/5 * 24 * 60 * 60  
                                                 if($seconds <= 60)  
                                                 {  
                                                $howtime="Just Now";  
                                              }  
                                                 else if($minutes <=60)  
                                                 {  
                                                if($minutes==1)  
                                                      {  
                                                        $howtime="one minute ago";  
                                                }  
                                                else  
                                                      {  
                                                        $howtime="$minutes minutes ago";  
                                                }  
                                              }  
                                                 else if($hours <=24)  
                                                 {  
                                                if($hours==1)  
                                                      {  
                                                $howtime="an hour ago";  
                                                }  
                                                      else  
                                                      {  
                                                $howtime="$hours hrs ago";  
                                                }  
                                              }  
                                                 else if($days <= 7)  
                                                 {  
                                                if($days==1)  
                                                      {  
                                                        $howtime="yesterday";  
                                                }  
                                                      else  
                                                      {  
                                                  $howtime="$days days ago";  
                                                }  
                                              }  
                                                 else if($weeks <= 4.3) //4.3 == 52/12  
                                                 {  
                                                if($weeks==1)  
                                                      {  
                                                 $howtime="a week ago";  
                                                }  
                                                      else  
                                                      {  
                                                    $howtime="$weeks weeks";  
                                                }  
                                              }  
                                                  else if($months <=12)  
                                                 {  
                                                if($months==1)  
                                                      {  
                                                        $howtime="a month ago";  
                                                }  
                                                      else  
                                                      {  
                                                        $howtime="$months months ago";  
                                                }  
                                              }  
                                                 else  
                                                 {  
                                                if($years==1)  
                                                      {  
                                                        $howtime="one year ago";  
                                                }  
                                                      else  
                                                      {  
                                                   $howtime="$years years ago";  
                                                }  
                                              }  
                                           
                                              if($fetch_msg['msg_side']=='User'){

                                    
                                    ?>

                                    <li class="message d-inline-flex">
                                        <div class="message__aside">
                                            <a href="#" class="avatar avatar-sm">
                                                <img src="assets/images/users/avatar2.png" alt="people" class="avatar-img rounded-circle">
                                            </a>
                                        </div>
                                        <div class="message__body card">
                                            <div class="card-body">
                                                <div class="d-flex align-items-center">
                                                    <div class="flex mr-3">
                                                        <a href="#" class="text-body"><strong><?php echo $names; ?>(Me)</strong></a>
                                                    </div>
                                                    <div>
                                                        <small class="text-50"><?php echo $howtime; ?></small>
                                                    </div>
                                                </div>
                                                <span class="text-70"><?php echo $fetch_msg['msg'] ?></span>

                                            </div>
                                        </div>
                                    </li>

                                    <?php }else{

                                    
                                    ?>

                                    <li class="message d-inline-flex">
                                        <div class="message__aside">
                                            <a href="#" class="avatar avatar-sm">
                                                <img src="assets/images/users/<?php echo $fetch_superv['profile']; ?>" alt="people" class="avatar-img rounded-circle">
                                            </a>
                                        </div>
                                        <div class="message__body card">
                                            <div class="card-body">
                                                <div class="d-flex align-items-center">
                                                    <div class="flex mr-3">
                                                        <a href="#" class="text-body"><strong><?php echo $fetch_superv['user_name']; ?></strong></a>
                                                    </div>
                                                    <div>
                                                        <small class="text-50"><?php echo $howtime; ?></small>
                                                    </div>
                                                </div>
                                                <span class="text-70"><?php echo $fetch_msg['msg'] ?></span>

                                            </div>
                                        </div>
                                    </li>

                                    <?php } } ?>

                                   


                                </ul>
                            </div>
                        </div>
                        <div class="container page__container page__container">
                            <form action="messages.php?super=<?php echo $nowsuper; ?>" id="message" method="post">
                                <div class="input-group input-group-merge">
                                    <input type="text" class="form-control form-control-appended" id="rmsg" name="rmsg" autofocus="" required="" placeholder="Type message">
                                    <div class="input-group-append">
                                        <div class="input-group-text pr-2">
                                            <button class="btn btn-flush" type="button"><i class="material-icons">tag_faces</i></button>
                                        </div>
                                        <div class="input-group-text pl-0">
                                            <div class="custom-file custom-file-naked d-flex" style="width: 24px; overflow: hidden;">
                                                <input type="file" class="custom-file-input" id="customFile">
                                                <label class="custom-file-label" style="color: inherit;" for="customFile">
                                                    <i class="material-icons">attach_file</i>
                                                </label>
                                             
                                            </div>
                                        </div>
                                        <div class="input-group-text pr-2">
                                            <button class="btn btn-flush" name="sbmt_msg" type="submit"><i class="material-icons">send</i>Send</button>
                                        </div>
                                    </div>
                                </div>


                            </form>
                        </div>
                    </div>
                </div>



                <div class="mdk-drawer js-mdk-drawer" data-align="end" id="messages-drawer">
                    <div class="mdk-drawer__content top-0">
                        <div class="sidebar sidebar-right sidebar-light bg-white o-hidden">
                            <div class="d-flex flex-column h-100">
                                <div class="d-flex flex-column justify-content-center navbar-height">
                                    <div class="px-3 form-group mb-0">
                                        <div class="input-group input-group-merge input-group-rounded flex-nowrap">
                                            <input type="text" class="form-control form-control-prepended" placeholder="Filter members">
                                            <div class="input-group-prepend">
                                                <div class="input-group-text">
                                                    <span class="material-icons">filter_list</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>







                                <div class="flex" data-perfect-scrollbar>
                                    <div class="sidebar-heading">Supervisor is <?php echo $fetch_superv['status']; ?></div>
                                    <?php  $sel_msger=$con->query("SELECT DISTINCT msg_super from messages WHERE msg_user='$account_key' ")or die($con->error);
                                        $count_msger=$sel_msger->num_rows;
                                        if($count_msger>0){
                                            while($fetch_msger=$sel_msger->fetch_assoc()){ 
                                                $psuper=$fetch_msger['msg_super'];
                                               // $event_time=$fetch_msger['msg_date'];
    
                                                $sel_p=$con->query("SELECT*from projects WHERE p_supervisor='$psuper' ")or die($con->error);
                                                    $fetch_p=$sel_p->fetch_assoc();
                                                ?>
                                    <ul class="list-group list-group-flush mb-3">


                                        <li class="list-group-item px-3 py-12pt bg-light">
                                            <a href="messages.php?super=<?php echo $psuper; ?>" class="d-flex align-items-center position-relative">
                                                <span class="avatar avatar-xs avatar-<?php echo $fetch_superv['status']; ?> mr-3 flex-shrink-0">

                                                    <img src="assets/images/users/<?php echo $fetch_superv['profile']; ?>" alt="Avatar" class="avatar-img rounded-circle">

                                                </span>
                                                <span class="flex d-flex flex-column" style="max-width: 175px;">
                                                    <strong class="text-body"><?php echo $fetch_p['p_tittle']; ?></strong>

                                                    <span class="text-muted text-ellipsis"><?php echo $fetch_superv['email']; ?></span>

                                                </span>
                                            </a>
                                        </li>

                                    </ul>
                                  <?php } } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>





        </div>
        <!-- // END drawer-layout__content -->




        <!-- drawer -->
        <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
            <div class="mdk-drawer__content">
                <div class="sidebar sidebar-dark-dodger-blue sidebar-left" data-perfect-scrollbar>


                <div class="d-flex align-items-center navbar-height">
                    <form action="#" class="search-form search-form--black mx-16pt pr-0 pl-16pt">
                        <input type="text" class="form-control pl-0" placeholder="Search">
                        <button class="btn" type="submit"><i class="material-icons">search</i></button>
                    </form>
                </div>



                <a href="index.php" class="sidebar-brand ">
                    <!-- <img class="sidebar-brand-icon" src="assets/images/illustration/student/128/white.svg" alt="Luma"> -->

                    <span class="avatar avatar-xl sidebar-brand-icon h-auto">

     <span class="avatar-title rounded "><img src="assets/images/logo/logo.png" alt="logo" class="img-fluid" /></span>

                    </span>

                    <span>GIZ Rwanda</span>
                </a>

                <div class="sidebar-heading">Client</div>
                <ul class="sidebar-menu">

                        <li class="sidebar-menu-item active">
                            <a class="sidebar-menu-button" href="index.php">
                                <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">home</span>
                                <span class="sidebar-menu-text">Home</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item">
                            <a class="sidebar-menu-button" href="projects.php">
                                <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">local_library</span>
                                <span class="sidebar-menu-text">Browse Programs</span>
                            </a>
                        </li>
    
                        
        <?php if(isset($_SESSION["giz_customer"])){?>
            <li class="sidebar-menu-item">
                            <a class="sidebar-menu-button" href="user_dashboard.php">
                            <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">dashboard</span>
                                <span class="sidebar-menu-text">Dashboard</span>
                            </a>
                        </li>
    
                        <li class="sidebar-menu-item">
                            <a class="sidebar-menu-button" href="user_profile.php">
                            <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">account_box</span>
                                <span class="sidebar-menu-text">Profile</span>
                            </a>
                        </li>
                        <li class="sidebar-menu-item">
                                <a class="sidebar-menu-button" data-toggle="collapse" href="messages.php">
                                    <span class="material-icons sidebar-menu-icon sidebar-menu-icon--left">message</span>
                                    Messaging
                                    <span class="sidebar-menu-badge badge badge-accent badge-notifications ml-auto">2</span>
                                    <span class="sidebar-menu-toggle-icon"></span>
                                </a>
                                
                            </li>
    
                        
    
                        <?php } ?>
                    </ul>


                </div>
            </div>
        </div>
        <!-- // END drawer -->


    </div>
    <!-- // END drawer-layout -->

    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- DOM Factory -->
    <script src="assets/vendor/dom-factory.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- Fix Footer -->
    <script src="assets/vendor/fix-footer.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>


    <script id="template-message" type="text/x-jsrender">
        <li class="message d-inline-flex">
    <div class="message__aside">
      <a href="#" class="avatar avatar-sm">
        <img src="{{:avatar}}" alt="people" class="avatar-img rounded-circle">
      </a>
    </div>
    <div class="message__body card">
      <div class="card-body">
        <div class="d-flex align-items-center">
          <div class="flex mr-3">
            <a href="#" class="text-body"><strong>{{:name}}</strong></a>
          </div>
          <div>
            <small class="text-muted">{{:date}}</small>
          </div>
        </div>
        <span class="text-black-70">{{:message}}</span>
        {{if file}}
        <a href="#" class="media align-items-center mt-2 text-decoration-0 bg-white px-3">
          <span class="avatar mr-2">
            <span class="avatar-title rounded-circle">
              <i class="material-icons font-size-24pt">attach_file</i>
            </span>
          </span>
          <span class="media-body" style="line-height: 1.5">
            <span class="text-primary">{{:file.name}}</span><br>
            <span class="text-muted">{{:file.size}}</span>
          </span>
        </a>
        {{/if}}
      </div>
    </div>
  </li>
</script>

    <!-- Messages App -->
    <script src="assets/js/messages.js"></script>

</body>


<!-- Mirrored from luma.humatheme.com/messages.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 16 May 2020 00:12:24 GMT -->
</html>